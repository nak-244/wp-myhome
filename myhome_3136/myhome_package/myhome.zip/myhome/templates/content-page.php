<div id="post-<?php echo esc_attr( get_the_ID() ); ?>" class="mh-post">
    <?php the_content(); ?>
</div>
