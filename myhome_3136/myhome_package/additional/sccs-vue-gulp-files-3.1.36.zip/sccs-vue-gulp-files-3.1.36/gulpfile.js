var gulp = require('gulp');
var sass = require('gulp-sass');
var concat = require('gulp-concat');
var minifyCSS = require('gulp-minify-css');
var uglify = require('gulp-uglify');

gulp.task('default', function () {
    gulp.watch('assets/scss/**/*.scss', ['css']);
    gulp.task('css', function () {
        gulp.src('assets/scss/style.scss')
            .pipe(sass().on('error', sass.logError))
            .pipe(gulp.dest(''))
    });
});

gulp.task('admin', function () {
	gulp.watch('assets/scss/**/*.scss', ['admin']);
	gulp.task('admin', function () {
		gulp.src('assets/scss/mh-admin.scss')
			.pipe(sass().on('error', sass.logError))
			.pipe(gulp.dest('assets/css'))
	});
});

gulp.task('css', function () {
	return gulp.src([
		'assets/css/normalize.css',
		'assets/css/frontend.css',
		'assets/css/swiper.min.css',
		'assets/css/selectize.css',
		'assets/css/font-awesome-fast.min.css',
		'style.css',
		'assets/css/dropzone.css',
		'assets/css/sweetalert2.min.css',
	])
		.pipe(minifyCSS())
		.pipe(concat('style.min.css'))
		.pipe(gulp.dest('.'))
});

gulp.task('css-rtl', function () {
	return gulp.src([
		'assets/css/normalize.css',
		'assets/css/frontend.css',
		'assets/css/swiper.min.css',
		'assets/css/selectize.css',
		'assets/css/font-awesome-fast.min.css',
		'style-rtl.css',
		'assets/css/rtl/fix.css',
		'assets/css/dropzone.css',
		'assets/css/sweetalert2.min.css',
	])
		.pipe(minifyCSS())
		.pipe(concat('style-rtl.min.css'))
		.pipe(gulp.dest('.'))
});

gulp.task('js', function () {
	return gulp.src([
		'assets/js/awesomplete.min.js',
		'assets/js/bootstrap.min.js',
		'assets/js/bootstrap-select.min.js',
		'assets/js/owl.carousel.js',
		'assets/js/selectize.min.js',
		'assets/js/swiper.min.js',
		'assets/js/typeahead.min.js',
		'assets/js/material.min.js',
		'assets/js/frontend.js',
		'assets/js/jquery.magnific-popup.min.js',
		'assets/js/jquery.sticky.js',
		'assets/js/main.js',
		'assets/js/carousel.js',
		'assets/js/single-property.js'
	])
		.pipe(concat('myhome.min.js'))
		.pipe(uglify())
		.pipe(gulp.dest('assets/js'))
});

gulp.task('map-js', function () {
	return gulp.src([
		'assets/js/markerclusterer.js',
		'assets/js/richmarker.min.js',
		'assets/js/infobox.min.js',
	])
		.pipe(concat('myhome-map.min.js'))
		.pipe(uglify())
		.pipe(gulp.dest('assets/js'))
});

gulp.task('panel', function () {
	return gulp.src([
		'assets/js/panel.js'
	])
		.pipe(concat('panel.min.js'))
		.pipe(uglify())
		.pipe(gulp.dest('assets/js'))
});