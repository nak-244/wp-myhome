<template>
  <div class="mh-edit-agents" id="myhome-panel-agents">
    <div>
        <h1>{{ translations.agents }}</h1>
        <div v-if="!hasAgents" class="mh-edit-agents__no-agents">{{ translations.no_agents }}</div>

        <div v-if="hasAgents" class="mh-edit-agents__list">
            <h2>{{ translations.agents_assigned }}</h2>
            <div class="mh-edit-agents__list__element" v-for="agent in user.agents">
                <div class="mh-edit-agents__list__element__content">{{ agent.name }} ({{ agent.email }})
                    <v-icon @click="onRemoveAgent(agent.ID)">close</v-icon>
                </div>
            </div>
        </div>

        <div v-if="showInviteCode">
          <h2>{{ translations.invitation_code }}</h2>
          <p>{{ translations.agents_code }}</p>
            <p>
              <span v-if="user.invite_code" class="mh-edit-agents__inv-code">{{ user.invite_code }}</span>
              <v-btn
                @click="regenerateInviteCode"
                color="primary"
                :loading="regenerateProgress"
                :disabled="regenerateProgress"
                flat
              >
                {{ translations.re_generate }}
              </v-btn>
            </p>
        </div>

        <h2>{{ translations.invite_agent }}</h2>
        <p>{{ translations.invite_agent_type_email }}</p>
        <form @submit.prevent="onInviteAgent">
          <v-text-field
            v-model="invite"
            :label="translations.email"
            v-validate="'email|required'"
            :error-messages="errors.collect('email')"
            data-vv-name="email"
            :data-vv-as="translations.email"
            required
          ></v-text-field>
          <v-btn
            @click.stop="onInviteAgent"
            color="primary"
            :disabled="inviteProgress"
            :loading="inviteProgress"
            depressed
          >
            {{ translations.invite_agent }}
          </v-btn>
        </form>

    </div>

    <v-dialog
      v-model="showDialog"
      max-width="400"
    >
      <h3 v-html="message"></h3>
      <v-btn @click.stop="showDialog = false">{{ translations.close }}</v-btn>
    </v-dialog>
  </div>
</template>

<script>
  export default {
    name         : "agents",
    data() {
      return {
        invite            : '',
        inviteProgress    : false,
        message           : '',
        showDialog        : false,
        regenerateProgress: false,
      }
    },
    $_veeValidate: {
      validator: 'new'
    },
    computed     : {
      translations() {
        return this.$store.state.translations;
      },
      user() {
        return this.$store.state.user;
      },
      hasAgents() {
        return typeof this.user.agents !== 'undefined' && this.user.agents.length > 0;
      },
      showInviteCode() {
        return jQuery.inArray('agency', this.user.roles) !== -1 && typeof this.user.invite_code !== 'undefined';
      }
    },
    methods      : {
      regenerateInviteCode() {
        this.regenerateProgress = true;
        let data = {
          _wpnonce: this.$store.state.nonce,
          action  : 'myhome_user_panel_regenerate_invite_code'
        };
        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {
          let data = response.body;
          if (data.success) {
            this.$set(this.$store.state, 'user', data.user);
          }
          this.regenerateProgress = false;
        }, (response) => {
          this.regenerateProgress = false;
        });
      },
      onRemoveAgent(agentID) {
        let data = {
          _wpnonce: this.$store.state.nonce,
          agent_id: agentID,
          action  : 'myhome_user_panel_remove_agent'
        };
        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {
          let data = response.body;
          if (data.success) {
            this.$set(this.$store.state, 'user', data.user);
          }
        }, (response) => {

        });
      },
      onInviteAgent() {
        this.$validator.validateAll().then((result) => {
          if (result) {
            this.inviteProgress = true;
            let data = {
              _wpnonce: this.$store.state.nonce,
              email   : this.invite,
              action  : 'myhome_user_panel_invite_agent'
            };
            this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {
              let data = response.body;
              this.message = data.message;
              this.showDialog = true;
              this.$validator.pause();
              this.invite = '';
              this.$nextTick(() => {
                this.$validator.resume();
              });
              this.inviteProgress = false;
            }, (response) => {
              this.inviteProgress = false;
            });
          }
        });
      }
    }
  }
</script>
