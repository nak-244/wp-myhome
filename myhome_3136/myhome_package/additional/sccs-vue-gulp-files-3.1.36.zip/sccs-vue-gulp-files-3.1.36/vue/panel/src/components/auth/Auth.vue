<template>
  <v-app>
    <v-container grid-list-xl text-xs-center>
      <v-layout row wrap>
        <v-flex xs4 offset-xs4>
          <user-login>
          </user-login>
        </v-flex>
      </v-layout>
    </v-container>
  </v-app>

</template>

<script>
  import UserLogin from './UserLogin'
  import UserRegister from './UserRegister'

  export default {
    name      : "auth",
    components: {UserLogin, UserRegister},
    data() {
      return {
        showLogin   : true,
        showRegister: true,
        currentTab  : 'login'
      }
    },
    computed  : {
      translations() {
        return this.$store.state.translations;
      },
      showTabs() {
        return this.$store.state.registration;
      }
    },
    methods   : {
      initiateCaptcha() {
        let timer = setInterval(() => {
          if (window.grecaptcha) {
            clearInterval(timer);
            this.$store.state.captchaId = grecaptcha.render(document.getElementById('mh-' + this.currentTab + '-captcha'), {
              'sitekey': this.$store.state.captchaKey
            });
          }
        }, 100);
      }
    },
    created() {
      this.currentTab = this.$store.state.activeTab;
    },
    mounted() {
      if (this.$store.state.captchaEnabled) {
        this.initiateCaptcha();
      }
    },
    watch     : {
      currentTab() {
        if (this.$store.state.captchaEnabled) {
          this.$nextTick(() => {
            this.initiateCaptcha();
          });
        }
      }
    }
  }
</script>
