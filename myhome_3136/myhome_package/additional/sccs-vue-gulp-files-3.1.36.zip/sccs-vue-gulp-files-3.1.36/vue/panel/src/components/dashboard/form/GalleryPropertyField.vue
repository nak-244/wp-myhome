<template>
  <div class="mh-field-gallery">
    <h3>{{ translations.gallery }}<span v-if="field.required">*</span></h3>
    <div class="mh-field__instruction" v-if="field.instructions !== ''">{{ field.instructions }}</div>
    <div class="mh-field__error" v-if="errors.has('gallery')"> {{ errors.first('gallery') }}</div>
    <div class="mh-field__error" v-if="errors.has(formScope + '.images')"> {{ errors.first(formScope + '.images') }}
    </div>

    <input
      id="gallery"
      style="display:none"
      type="file"
      ref="gallery"
      accept="image/*"
      :multiple="true"
      @change="uploadFiles($event)"
      v-validate="imageRules"
      name="gallery"
      :data-vv-as="translations.gallery"
    >

    <input
      type="hidden"
      v-model="images"
      name="images"
      v-validate="galleryRules"
      :data-vv-scope="formScope"
    >

    <div class="mh-field-gallery__images-wrapper" :class="{'mh-gallery__upload-in-progress': disableButton }">

      <draggable v-model="images">
        <div class="mh-field-gallery__single" style="cursor:move;" v-for="(image, index) in images"
             :key="index + '-' + image.name">
          <div :key="index + '-' + image.name + '-element'">

            <div v-if="image.url !== ''">
              <img :src="image.url" alt="">
            </div>

            <div>
              <div v-if="image.isProcessing" class="mh-field-gallery__progress">
                <div class="mh-field-gallery__progress__inner">
                  <v-progress-circular
                    indeterminate
                    :size="48"
                    :width="1"
                    :rotate="-90"
                    v-model="image.progress"
                    color="primary"
                  >
                  </v-progress-circular>
                </div>
              </div>

              <div class="mh-field-gallery__remove">
                <v-btn
                  v-if="image.status === 4"
                  style="cursor:pointer;"
                  @click="onRemove(index)"
                  icon
                  ripple
                >
                  <v-icon>delete</v-icon>
                </v-btn>
              </div>
            </div>
          </div>
        </div>
      </draggable>

    </div>

    <v-btn
      @click="onUpload"
      :disabled="disableButton"
      color="secondary"
      class="mh-field-gallery__upload"
      depressed
    >
      <v-icon left dark>cloud_upload</v-icon>
      {{ translations.upload_images }}
    </v-btn>

  </div>
</template>

<script>
  import draggable from 'vuedraggable'

  const STATUS_WAIT = 1;
  const STATUS_PROCESS = 3;
  const STATUS_COMPLETE = 4;

  export default {
    inject: ['$validator'],
    name: "gallery-property-field",
    data() {
      return {
        disableButton: false,
        images: [],
      }
    },
    components: {
      draggable
    },
    props: {
      field: Object,
      formScope: String
    },
    computed: {
      imageRules() {
        let rules = 'image';
        let maxImageSize = parseInt(window.MyHomePanel.validation['gallery_max-size']) * 1024;
        if (maxImageSize > 0) {
          rules += '|size:' + maxImageSize;
        }

        return rules;
      },
      galleryRules() {
        let rules = '';

        if (this.field.required) {
          rules += 'gallery_required';
        }

        if (parseInt(window.MyHomePanel.validation['gallery_max-number']) > 0) {
          rules += rules !== '' ? '|gallery_limit' : 'gallery_limit';
        }

        return rules;
      },
      translations() {
        return this.$store.state.translations;
      }
    },
    methods: {
      onRemove(index) {
        this.images.splice(index, 1);
      },
      onUpload() {
        document.getElementById("gallery").value = "";
        this.$refs.gallery.click();
      },
      uploadFiles(e) {
        this.$validator.validate('gallery').then((result) => {
          if (result) {
            this.disableButton = true;
            let files = e.target.files || e.dataTransfer.files;
            if (files.length) {
              window.MyHomePanelEventBus.$emit('lockButtons', 'gallery')

              this.inProgress = true
              for (let i = 0; i < files.length; i++) {
                this.images.push({
                  id: 0,
                  name: files[i].name,
                  size: this.fileSize(files[i].size),
                  status: STATUS_WAIT,
                  url: '',
                  file: files[i],
                  isProcessing: false,
                  progress: 0
                });
              }
              this.$nextTick(() => {
                this.startUpload();
              });
            }
          }
        });
      },
      startUpload() {
        let startedUpload = false;
        jQuery.each(this.images, (index, image) => {
          if (image.status === STATUS_WAIT) {
            this.upload(index, image);
            startedUpload = true;
            return false;
          }
        });

        if (!startedUpload) {
          this.disableButton = false;
          window.MyHomePanelEventBus.$emit('lockButtons', 'gallery')
        }
      },
      upload(index, image) {
        this.$set(this.images[index], 'isProcessing', true);
        this.$set(this.images[index], 'status', STATUS_PROCESS);
        let formData = new FormData();
        formData.append('file', image.file);
        formData.append('action', 'myhome_user_panel_upload_image');

        let xhr = new XMLHttpRequest();
        xhr.upload.addEventListener('progress', (e) => {
          let total = e.total;
          let loaded = e.loaded;
          this.$set(this.images[index], 'progress', parseInt((100 / total) * loaded));
        }, false);

        xhr.upload.addEventListener('loadend', () => {
          this.$set(this.images[index], 'status', STATUS_PROCESS);
        });

        xhr.onreadystatechange = () => {
          if (xhr.readyState == XMLHttpRequest.DONE) {
            this.$set(this.images[index], 'isProcessing', false);
            this.$set(this.images[index], 'status', STATUS_COMPLETE);
            let image = JSON.parse(xhr.responseText);
            this.$set(this.images[index], 'url', image.url);
            this.$set(this.images[index], 'id', image.image_id);
            this.startUpload();
          }
        };

        xhr.open('POST', this.$store.state.requestUrl);
        xhr.send(formData);
      },
      fileSize(bytes) {
        bytes = parseInt(bytes);
        let sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        if (bytes == 0) return '0 Byte';
        let i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
      }
    },
    created() {
      if (typeof this.$store.state.draftProperty.images !== 'undefined') {
        this.images = this.$store.state.draftProperty.images;
      }
    },
    watch: {
      images() {
        this.$set(this.$store.state.draftProperty, 'images', this.images);
      }
    }
  }
</script>
