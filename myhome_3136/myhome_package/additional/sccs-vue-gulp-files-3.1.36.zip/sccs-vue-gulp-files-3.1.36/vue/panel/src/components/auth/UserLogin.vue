<template>
  <div class="mh-panel-app-spacing">
    <div class="mh-login-register-panel">
      <div class="mh-login-register-panel__inner">

        <form @submit.prevent="onLogin">

          <div>
            <div class="mh-login-register-panel__heading">
              <div>
                <h3>
                  {{ translations.login }}
                </h3>
              </div>
            </div>

            <div>

              <v-alert v-for="message in messages" v-html="message.text" :value="true" :type="message.type"></v-alert>

              <v-alert v-if="errorMessage !== ''" type="error" :value="true" v-html="errorMessage"></v-alert>

              <v-text-field
                v-model="credentials.login"
                :label="translations.login"
                :error-messages="errors.collect(translations.login)"
                v-validate="'required|min:3'"
                prepend-icon="perm_identity"
                :data-vv-name="translations.login"
                required
              >
              </v-text-field>

              <v-text-field
                v-model="credentials.password"
                :label="translations.enter_password"
                :error-messages="errors.collect(translations.password)"
                :append-icon="visiblePassword ? 'visibility' : 'visibility_off'"
                :append-icon-cb="() => (visiblePassword = !visiblePassword)"
                :type="visiblePassword ? 'text' : 'password'"
                prepend-icon="mail_outline"
                :data-vv-name="translations.password"
                v-validate="'required|min:3'"
                required
              >
              </v-text-field>

              <div class="mh-login-captcha">
                <div v-if="isCaptchaEnabled" id="mh-login-captcha"></div>
              </div>

              <div class="mh-panel-login-buttons">
                <div class="mh-panel-login-buttons__remember">
                  <v-checkbox
                    v-model="rememberMe"
                    value="1"
                    color="primary"
                    :label="translations.remember_me"
                    type="checkbox"
                  >
                  </v-checkbox>
                </div>

                <div class="mh-panel-login-buttons__right">
                  <div class="mh-panel-login-buttons__login">
                    <v-btn
                      type="submit"
                      color="primary"
                      :loading="loading"
                      :disabled="isLoginDisabled"
                      depressed
                    >
                      {{ translations.login }}
                    </v-btn>
                  </div>
                  <div v-if="showRegister" class="mh-panel-login-buttons__register">
                    <v-btn @click="onRegister" flat>{{ translations.register }}</v-btn>
                  </div>
                </div>
              </div>

              <div class="mh-panel-login-social-buttons" v-if="socialLogin.length">
                <h3 class="mh-panel-social-buttons-heading">{{ translations.connect_with }}</h3>
                <div class="mh-panel-login-social-buttons__all-buttons">
                  <div v-for="network in socialLogin">
                    <v-btn :data-name="network.key"
                           depressed @click="onSocialLogin(network.login_link)">
                      {{ network.name }}
                    </v-btn>
                  </div>
                </div>
              </div>

              <a href="#" class="mh-rest-password-link" @click.stop="resetPasswordDialog = !resetPasswordDialog">
                <v-icon>vpn_key</v-icon>
                {{ translations.retrieve_password }}
              </a>
            </div>
          </div>

        </form>

        <v-dialog v-model="resetPasswordDialog">
          <form @submit.prevent="onResetPassword">
            <v-card>
              <v-card-title>
                <span class="headline">
                  {{ translations.retrieve_password }}
                </span>
              </v-card-title>

              <v-card-media v-if="resetPasswordLoading">
                <v-progress-linear
                  :indeterminate="true"
                >
                </v-progress-linear>
              </v-card-media>

              <v-card-text>
                <v-text-field
                  data-vv-scope="reset-password-form"
                  v-model="resetPasswordEmail"
                  :label="translations.enter_your_email"
                  :error-messages="errors.collect('resetPasswordEmail')"
                  data-vv-name="resetPasswordEmail"
                  :data-vv-as="translations.email"
                  v-validate="'required|email'"
                  required
                >
                </v-text-field>

              </v-card-text>

              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn @click.stop="resetPasswordDialog = !resetPasswordDialog" flat>
                  {{ translations.cancel }}
                </v-btn>
                <v-btn color="primary" @click="onResetPassword" flat>{{ translations.reset }}</v-btn>
              </v-card-actions>
            </v-card>
          </form>
        </v-dialog>

      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name         : "login",
    data() {
      return {
        credentials         : {
          login   : '',
          password: '',
        },
        rememberMe          : false,
        visiblePassword     : false,
        loading             : false,
        errorMessage        : '',
        resetPasswordDialog : false,
        resetPasswordEmail  : '',
        resetPasswordLoading: false,
        socialLogin         : [],
        captchaChecked      : false
      }
    },
    $_veeValidate: {
      validator: 'new' // give me a new validator each time.
    },
    computed     : {
      isLoginDisabled() {
        if (this.isCaptchaEnabled && !this.captchaChecked) {
          return true;
        }

        return false;
      },
      showRegister() {
        return window.MyHomePanel.registration !== 'false'
      },
      messages() {
        return this.$store.state.messages;
      },
      translations() {
        return this.$store.state.translations;
      },
      isCaptchaEnabled() {
        return this.$store.state.captchaEnabled;
      }
    },
    methods      : {
      onSocialLogin(loginLink) {
        window.location.href = loginLink;
      },
      onResetPassword() {
        this.$validator.validateAll('reset-password-form').then((result) => {
          if (result) {
            this.resetPassword();
          }
        });
      },
      resetPassword() {
        this.resetPasswordLoading = true;
        let data = {
          action  : 'myhome_user_panel_reset_password',
          email   : this.resetPasswordEmail,
          _wpnonce: this.$store.state.nonce
        };
        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {
          this.resetPasswordLoading = false;
          if (response.body.success === true) {
            this.onResetPasswordSuccess();
          } else {
            this.onResetPasswordError();
          }
          this.resetPasswordDialog = false;
        }, (response) => {
          this.resetPasswordLoading = false;
          this.onResetPasswordError();
          this.resetPasswordDialog = false;
        });
      },
      onResetPasswordSuccess() {
        this.$store.state.messages.splice(0, this.$store.state.messages.length);
        this.$store.state.messages.push({
          type: 'success',
          text: this.translations.reset_password_success
        });
      },
      onResetPasswordError() {
        this.$store.state.messages.splice(0, this.$store.state.messages.length);
        this.$store.state.messages.push({
          type: 'error',
          text: this.translations.something_went_wrong
        });
      },
      onLogin() {
        if (this.isLoginDisabled) {
          return;
        }

        this.$store.state.messages.splice(0, this.$store.state.messages.length);
        this.errorMessage = '';
        this.$validator.validateAll().then((result) => {
          if (result) {
            this.login();
          }
        });
      },
      login() {
        this.loading = true;
        let data = {
          action     : 'myhome_user_panel_login',
          credentials: this.credentials,
          rememberMe : this.rememberMe,
          _wpnonce   : this.$store.state.nonce,
        };

        if (this.isCaptchaEnabled) {
          data['captcha'] = grecaptcha.getResponse(this.$store.state.captchaId);
        }

        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then(response => {
          this.loading = false;
          if (response.body.success) {
            this.onSuccess(response.body)
          } else {
            this.onError(response.body)
          }
        }, response => {
          this.loading = false;
          this.onError(response.body)
        })
      },
      onClear() {
        this.$set(this, 'credentials', {login: '', password: ''});
        this.errorMessage = '';
        this.rememberMe = false;
      },
      onSuccess(response) {
        if (response.user.roles.indexOf('administrator') !== -1) {
          window.location.reload();
          return;
        }

        this.$store.state.nonce = response.nonce;
        this.$store.state.user = response.user;
        window.MyHomePanelEventBus.$emit('userLogin', response.user);
        if (response.user.roles.indexOf('buyer') !== -1) {
          this.$router.push('/dashboard/favorite');
        } else {
          this.$router.push('/dashboard/properties');
        }
      },
      onError(response) {
        this.$set(this.credentials, 'password', '');

        if (typeof response.request_activation_link !== 'undefined') {
          this.$router.push('/account-activation');
          return;
        }

        if (typeof response.text !== 'undefined') {
          this.errorMessage = response.text;
        }

        if (this.isCaptchaEnabled) {
          grecaptcha.reset();
        }
      },
      initiateCaptcha() {
        let timer = setInterval(() => {
          if (grecaptcha && typeof grecaptcha !== 'undefined' && typeof document.getElementById('mh-login-captcha') !== 'undefined') {
            clearInterval(timer);
            this.captchaChecked = false;
            this.$nextTick(() => {
              this.$store.state.captchaId = grecaptcha.render(document.getElementById('mh-login-captcha'), {
                'sitekey'         : this.$store.state.captchaKey,
                'callback'        : () => {
                  this.captchaChecked = true;
                },
                'expired-callback': () => {
                  this.captchaChecked = false;
                }
              });
            })
          }
        }, 100);
      },
      onRegister() {
        this.$router.push('register');
      }
    },
    created() {
      if (typeof window.MyHome.social_login !== 'undefined') {
        this.socialLogin = window.MyHome.social_login;
      }
    },
    mounted() {
      if (this.isCaptchaEnabled) {
        this.initiateCaptcha();
      }
    }
  }
</script>
