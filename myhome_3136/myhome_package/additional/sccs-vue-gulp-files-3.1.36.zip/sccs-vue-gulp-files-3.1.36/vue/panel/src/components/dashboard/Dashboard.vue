<template>

  <div>
    <v-app>
      <div v-if="showAccountInfo" class="mh-dashboard-info">
        <div class="mh-dashboard-info__inner">
          <div class="mh-dashboard-info__properties">
            <span>{{ translations.properties_dots }}<strong>{{ user.package_properties }}</strong></span>
            <span>{{ translations.featured_properties_dots }} <strong>{{ user.package_featured }}</strong></span>
          </div>
          <div class="mh-dashboard-info__package">

            <v-btn
              :href="pricingTableUrl"
              color="primary"
              depressed
            >
              <v-icon left white>shopping_cart</v-icon>
              {{ translations.buy_package }}
            </v-btn>

          </div>
        </div>
      </div>
      <div class="mh-layout mh-panel-app-spacing">
        <div class="mh-layout__sidebar-left">
          <user-menu></user-menu>
        </div>
        <div class="mh-layout__content-right">
          <transition name="slide-x-transition" mode="out-in">
            <router-view></router-view>
          </transition>
        </div>
      </div>

    </v-app>

  </div>

</template>

<script>
  import UserMenu from './Menu'

  export default {
    name      : "dashboard",
    components: {UserMenu},
    data() {
      return {
        showBuyPackage: false,
        test: false
      }
    },
    computed  : {
      showBuy() {
        return this.showBuyPackage;
      },
      pricingTableUrl() {
        return window.MyHomePanel.pricing_table;
      },
      showAccountInfo() {
        return typeof window.MyHomePanel.payments !== 'undefined' && window.MyHomePanel.payments
          && this.user.roles.indexOf('buyer') === -1;
      },
      translations() {
          return this.$store.state.translations;
      },
      user() {
        return this.$store.state.user;
      }
    }
  }
</script>
