<template>

  <div id="app" class="mh-app-wrapper">

    <v-app>
      <transition name="slide-x-transition" mode="out-in">
        <router-view>
        </router-view>
      </transition>
    </v-app>

  </div>

</template>

<script>
  export default {
    name   : 'app',
    methods: {
      onLogout() {
        let data = {
          _wpnonce: this.$store.state.nonce,
          action  : 'myhome_user_panel_logout'
        };
        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then(() => {
          window.location.reload();
        }, () => {
        });
      }
    },
    created() {
      let path = this.$router.currentRoute.path;
      let activeTab = window.MyHomePanel.active_tab;
      let route;

      if (activeTab === 'login' || window.MyHomePanel.registration === 'false') {
        route = '/';
      } else {
        route = '/register';
      }

      if (window.MyHomePanel.user === 'false' && window.MyHomePanel.submit_registered
        && path === '/submit-property') {
        this.$store.commit('updateUser', false);
        this.$router.push(route);
      } else if (window.MyHomePanel.user === 'false') {
        this.$store.commit('updateUser', false);
        if (path.indexOf('dashboard') !== -1 || path === '/' || path === '/register') {
          this.$router.push(route);
        }
      } else {
        this.$store.commit('updateUser', window.MyHomePanel.user);
        if (path.indexOf('dashboard') === -1 && path !== '/submit-property') {
          if (this.$store.state.user.roles.indexOf('buyer') !== -1) {
            this.$router.push('/dashboard/favorite');
          } else {
            this.$router.push('/dashboard/properties');
          }
        } else if (this.$store.state.user.roles.indexOf('buyer') !== -1 && path === '/submit-property') {
          this.$router.push('/dashboard/favorite');
        }
      }

      this.$store.state.registration = window.MyHomePanel.registration === 'true';
      this.$store.state.translations = window.MyHomePanel.translations;
      this.$store.state.nonce = window.MyHomePanel.nonce;
      this.$store.state.requestUrl = window.MyHomePanel.request_url;
      this.$store.state.captchaEnabled = window.MyHomePanel.captcha_enabled === '1';
      this.$store.state.captchaKey = window.MyHomePanel.captcha_site_key;
      this.$store.state.steps = window.MyHomePanel.steps;
      this.$store.state.validationRules = window.MyHomePanel.validation;

      this.$router.beforeEach((to, from, next) => {
        if (to.path === '/submit-property' && this.$store.state.user === false && window.MyHomePanel.submit_registered) {
          next('/');
        } else if ((to.path === '/' || to.path === 'dashboard') && this.$store.state.user !== false) {
          if (this.$store.state.user.roles.indexOf('buyer') !== -1) {
            next('/dashboard/favorite')
          } else {
            next('/dashboard/properties');
          }
        } else if (to.path.indexOf('dashboard') !== -1 && this.$store.state.user === false) {
          next('/');
        } else {
          next();
        }
      });
    },
    mounted() {
      let currentPath = this.$router.currentRoute.path;
      let newClass = 'mh-panel-body__' + currentPath.replace(/^\/+|\/+$/g, '').replace(/\//g, '-');
      let body = jQuery('body');
      body.addClass(newClass);

      window.MyHomeEventBus.$emit('panelInitiated');
      window.MyHomePanelEventBus.$on('onSubmitProperty', () => {
        if (this.$store.state.user !== false) {
          this.$router.push('/submit-property');
        }
      });
      window.MyHomeEventBus.$on('MyHomePanelEventBus', (context) => {
        if (this.$store.state.user !== false) {
          this.$router.push(context);
        }
      });
      window.MyHomePanelEventBus.$on('onUserLogout', () => {
        this.onLogout();
      });
    }
  }
</script>
