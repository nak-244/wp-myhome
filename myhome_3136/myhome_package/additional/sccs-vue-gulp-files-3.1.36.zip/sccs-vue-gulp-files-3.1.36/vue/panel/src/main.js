"use strict";

import 'babel-polyfill'
import Vue from 'vue'
import VeeValidate, {Validator} from 'vee-validate'
import Vuetify from 'vuetify'
import VueRouter from 'vue-router'
import VueResource from 'vue-resource'
import App from './App.vue'
import UserLogin from './components/auth/UserLogin'
import ResetPasswordLinkExpired from './components/auth/ResetPasswordLinkExpired'
import RegisterClosed from './components/auth/RegisterClosed'
import ResetPasswordNew from './components/auth/ResetPasswordNew'
import ResetPasswordError from './components/auth/ResetPasswordError'
import LoginError from './components/auth/LoginError'
import AccountActivationLinkExpired from './components/auth/AccountActivationLinkExpired'
import AccountActivation from './components/auth/AccountActivation'
import UserRegister from './components/auth/UserRegister'
import Dashboard from './components/dashboard/Dashboard'
import Properties from './components/dashboard/Properties'
import EditProperty from './components/dashboard/EditProperty'
import SubmitProperty from './components/submit/SubmitProperty'
import Profile from './components/dashboard/Profile'
import Favorite from './components/dashboard/Favorite'
import Searches from './components/dashboard/Searches'
import Agents from './components/dashboard/Agents'
import Moderation from './components/dashboard/Moderation'
import Trash from './components/dashboard/Trash'
import {store} from './store/store'

const dictionary = {
  en: {
    messages: {
      required(e) {
        return e + " " + window.MyHomePanel.translations.validation_field_is_required
      },
      min(e, n) {
        return e + " " + window.MyHomePanel.translations.validation_field_must_be_at_least + " " + n[0] + " " + window.MyHomePanel.translations.validation_characters
      },
      confirmed(e) {
        return e + " " + window.MyHomePanel.translations.validation_confirmation_does_not_match
      },
      email(e) {
        return e + " " + window.MyHomePanel.translations.validation_field_must_be_email
      },
      size(e, n) {
        let t, i, a, r = n[0];
        return window.MyHomePanel.translations.validation_not_size_must_be_less_than + " " + (t = r, i = 1024, a = 0 == (t = Number(t) * i) ? 0 : Math.floor(Math.log(t) / Math.log(i)), 1 * (t / Math.pow(i, a)).toFixed(2) + " " + ["Byte", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"][a]) + "."
      },
      image(e) {
        return e + " " + window.MyHomePanel.translations.validation_field_must_be_image
      },
      decimal(e, n) {
        return e + " " + window.MyHomePanel.translations.validation_decimal
      },
      integer(e) {
        return e + " " + window.MyHomePanel.translations.validation_integer
      },
    }
  }
};

Validator.extend('gallery_required', {
  getMessage: field => window.MyHomePanel.translations.gallery_required,
  validate  : value => new Promise((resolve) => {
    resolve({valid: value.length > 0});
  })
});

let galleryMaxLimit = parseInt(window.MyHomePanel.validation['gallery_max-number']);
Validator.extend('gallery_limit', {
  getMessage: field => window.MyHomePanel.translations.max_number_files + " " + galleryMaxLimit,
  validate  : value => new Promise((resolve) => {
    resolve({valid: value.length <= galleryMaxLimit});
  })
});

Validator.extend('attachments_required', {
  getMessage: field => window.MyHomePanel.translations.attachments_required,
  validate  : value => new Promise((resolve) => {
    resolve({valid: value.length > 0});
  })
});

let attachmentsMaxLimit = parseInt(window.MyHomePanel.validation['attachments_max-number']);
Validator.extend('attachments_limit', {
  getMessage: field => window.MyHomePanel.translations.max_number_files + ' ' + attachmentsMaxLimit,
  validate  : value => new Promise((resolve) => {
    resolve({valid: value.length <= attachmentsMaxLimit});
  })
});

Validator.extend('plans_required', {
  getMessage: field => window.MyHomePanel.translations.plans_required,
  validate  : value => new Promise((resolve) => {
    resolve({valid: value.length > 0});
  })
});

let plansMaxLimit = parseInt(window.MyHomePanel.validation['plans_max-number']);
Validator.extend('plans_limit', {
  getMessage: field => window.MyHomePanel.translations.max_number_files + ' ' + plansMaxLimit,
  validate  : value => new Promise((resolve) => {
    resolve({valid: value.length <= plansMaxLimit});
  })
});

Validator.extend('additional_features', {
  getMessage: field => window.MyHomePanel.translations.additional_features_required,
  validate  : value => new Promise((resolve) => {
    resolve({valid: value.length > 0});
  })
});

Vue.use(VeeValidate, {inject: false, dictionary: dictionary});
Vue.use(Vuetify);
Vue.use(VueRouter);
Vue.use(VueResource);

const routes = [
  {path: '/', component: UserLogin},
  {path: '/register', component: UserRegister},
  {path: '/submit-property', component: SubmitProperty},
  {path: '/password-reset-link-expired', component: ResetPasswordLinkExpired},
  {path: '/password-reset-new', component: ResetPasswordNew},
  {path: '/password-reset-error', component: ResetPasswordError},
  {path: '/account-activation-link-expired', component: AccountActivationLinkExpired},
  {path: '/account-activation', component: AccountActivation},
  {path: '/registration-closed', component: RegisterClosed},
  {path: '/login-error', component: LoginError},
  {
    path: '/dashboard', component: Dashboard, children: [
      {path: 'properties', component: Properties},
      {path: 'properties/:id', component: EditProperty},
      {path: 'profile', component: Profile},
      {path: 'favorite', component: Favorite},
      {path: 'searches', component: Searches},
      {path: 'agents', component: Agents},
      {path: 'moderation', component: Moderation},
      {path: 'trash', component: Trash},
    ]
  },
];

const router = new VueRouter({
  routes: routes
});

router.beforeEach((to, from, next) => {
  if (to.path === '/register' && window.MyHomePanel.registration === 'false') {
    next('/');
    return;
  }


  let oldClass = 'mh-panel-body__' + from.path.replace(/^\/+|\/+$/g, '').replace(/\//g, '-');
  let newClass = 'mh-panel-body__' + to.path.replace(/^\/+|\/+$/g, '').replace(/\//g, '-');
  let body = jQuery('body');
  body.removeClass(oldClass);
  body.addClass(newClass);

  if (jQuery(window).scrollTop() > 300) {
    jQuery(window).scrollTop(0);
  }
  next();
});
router.afterEach(() => {
  window.MyHomeEventBus.$emit('routeChange');
});

window.MyHomePanelEventBus = new Vue();

new Vue({
  el    : '#app',
  router: router,
  store : store,
  render: h => h(App)
});
