<template>
  <div class="mh-field-attachment">
    <h3>{{ translations.attachments }}<span v-if="field.required">*</span></h3>
    <div class="mh-field__instruction" v-if="field.instructions !== ''">{{ field.instructions }}</div>
    <div class="mh-field__error" v-if="errors.has('attachment')">{{ errors.first('attachment') }}</div>
    <div class="mh-field__error" v-if="errors.has(formScope + '.attachments')">{{ errors.first(formScope + '.attachments') }}</div>

    <input
      id="attachments"
      style="display: none;"
      type="file"
      ref="attachments"
      :multiple="true"
      @change="uploadFiles($event)"
      v-validate="attachmentRules"
      :data-vv-as="translations.attachment"
      name="attachment"
    >

    <input
      type="hidden"
      v-model="attachments"
      name="attachments"
      v-validate="attachmentsRules"
      :data-vv-scope="formScope"
    >

    <div class="mh-field-plans__list">
      <div v-if="attachments.length" three-line subheader>

        <div v-for="(attachment, index) in attachments" :key="index">

          <div class="mh-field-plans__list__row">
            <div class="mh-field-plans__list__image">
              <v-progress-circular
                      v-if="attachment.status === 3"
                      v-model="attachment.progress"
                      indeterminate
                      :size="48"
                      :width="2"
                      :rotate="-90"
                      color="primary"
              >
              </v-progress-circular>
              <div class="mh-field-plans__list__image__icon" v-if="attachment.status === 4">
                <v-icon>attachment</v-icon>
              </div>
            </div>
            <div class="mh-field-plans__list__text">
              <v-text-field
                      v-model="attachment.name"
                      :label="translations.attachment_name"
              ></v-text-field>
            </div>
            <div class="mh-field-plans__list__remove">
              <i
                      v-if="attachment.status === 4"
                      @click="onRemoveAttachment(index)"
                      class="fa fa-times"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <v-btn
      @click="onAddAttachment"
      :disabled="disableButton"
      depressed
      color="secondary"
      class="mh-field-attachment__add"
    >
      <v-icon left dark>cloud_upload</v-icon>
      {{ translations.upload_attachments }}
    </v-btn>

  </div>
</template>

<script>
  const STATUS_WAIT = 1;
  const STATUS_UPLOAD = 2;
  const STATUS_PROCESS = 3;
  const STATUS_COMPLETE = 4;

  export default {
    name    : "attachment-property-field",
    inject  : ['$validator'],
    data() {
      return {
        disableButton: false,
        attachments  : []
      }
    },
    props   : {
      field    : Object,
      creating : Boolean,
      formScope: String
    },
    computed: {
      attachmentsRules() {
        let rules = '';

        if (this.field.required) {
          rules += 'attachments_required';
        }

        if (parseInt(window.MyHomePanel.validation['attachments_max-number']) > 0) {
          rules += rules !== '' ? '|attachments_limit' : 'attachments_limit';
        }

        return rules;
      },
      attachmentRules() {
        let rules = 'mimes:image/*,application/pdf';

        let maxAttachmentSize = parseInt(window.MyHomePanel.validation['attachments_max-size']) * 1024;
        if (maxAttachmentSize > 0) {
          rules += '|size:' + maxAttachmentSize;
        }

        return rules;
      },
      translations() {
        return this.$store.state.translations;
      }
    },
    methods : {
      onAddAttachment() {
        document.getElementById("attachments").value = "";
        this.$refs.attachments.click();
      },
      onRemoveAttachment(index) {
        this.attachments.splice(index, 1);
      },
      uploadFiles(e) {
        this.$validator.validate('attachment').then((result) => {
          if (result) {
            this.disableButton = true;
            let files = e.target.files || e.dataTransfer.files;
            if (files.length) {
              window.MyHomePanelEventBus.$emit('lockButtons', 'attachments')

              for (let i = 0; i < files.length; i++) {
                this.attachments.push({
                  id          : 0,
                  name        : files[i].name,
                  size        : this.fileSize(files[i].size),
                  status      : STATUS_WAIT,
                  url         : '',
                  file        : files[i],
                  isProcessing: false,
                  progress    : 0
                });
              }
              this.$nextTick(() => {
                this.startUpload();
              });
            }
          }
        });
      },
      startUpload() {
        let startedUpload = false;
        jQuery.each(this.attachments, (index, attachment) => {
          if (attachment.status === STATUS_WAIT) {
            this.upload(index, attachment);
            startedUpload = true;
            return false;
          }
        });

        if (!startedUpload) {
          this.disableButton = false;
          window.MyHomePanelEventBus.$emit('lockButtons', 'attachments')
        }
      },
      upload(index, attachment) {
        this.$set(this.attachments[index], 'isProcessing', true);
        this.$set(this.attachments[index], 'status', STATUS_UPLOAD);
        let formData = new FormData();
        formData.append('file', attachment.file);
        formData.append('action', 'myhome_user_panel_upload_attachment');

        let xhr = new XMLHttpRequest();
        xhr.upload.addEventListener('progress', (e) => {
          let total = e.total;
          let loaded = e.loaded;
          this.$set(this.attachments[index], 'progress', parseInt((100 / total) * loaded));
        }, false);

        xhr.upload.addEventListener('loadend', () => {
          this.$set(this.attachments[index], 'status', STATUS_PROCESS);
        });

        xhr.onreadystatechange = () => {
          if (xhr.readyState == XMLHttpRequest.DONE) {
            this.$set(this.attachments[index], 'isProcessing', false);
            this.$set(this.attachments[index], 'status', STATUS_COMPLETE);
            let attachment = JSON.parse(xhr.responseText);
            this.$set(this.attachments[index], 'url', attachment.url);
            this.$set(this.attachments[index], 'id', attachment.image_id);
            this.startUpload();
          }
        };

        xhr.open('POST', this.$store.state.requestUrl);
        xhr.send(formData);
      },
      fileSize(bytes) {
        bytes = parseInt(bytes);
        let sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        if (bytes == 0) return '0 Byte';
        let i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
      }
    },
    created() {
      if (typeof this.$store.state.draftProperty.attachments !== 'undefined') {
        this.attachments = this.$store.state.draftProperty.attachments;
      }
    },
    watch   : {
      attachments() {
        this.$set(this.$store.state.draftProperty, 'attachments', this.attachments);
      }
    }
  }
</script>
