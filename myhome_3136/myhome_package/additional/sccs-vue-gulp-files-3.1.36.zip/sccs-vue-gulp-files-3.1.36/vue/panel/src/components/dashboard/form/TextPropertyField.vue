<template>
  <div v-show="!isDisabled" class="mh-field-text-field">

    <v-text-field
      v-if="isText"
      :id="fieldID"
      :label="field.name"
      v-model.lazy="value"
      :required="field.required"
      :data-vv-scope="formScope"
      :hint="field.instructions"
      v-validate="rules"
      :error-messages="errors.collect(fieldID)"
      :data-vv-name="fieldID"
      :data-vv-as="field.name"
      browser-autocomplete="off"
      persistent-hint
      clearable
    >
    </v-text-field>

    <v-select
      v-if="!isText"
      :id="fieldID"
      v-model="value"
      :label="field.name"
      :multiple="field.multiple"
      :items="items"
      :tags="tags"
      :combobox="comboBox"
      :disabled="isSelectDisabled"
      :autocomplete="field.autocomplete"
      :required="field.required"
      :data-vv-scope="formScope"
      :hint="field.instructions"
      v-validate="rules"
      :error-messages="errors.collect(fieldID)"
      :data-vv-name="fieldID"
      :data-vv-as="field.name"
      bottom
      persistent-hint
      return-object
      clearable
      multi-line
    >
    </v-select>
  </div>
</template>

<script>
  export default {
    name: "text-property-field",
    inject: ['$validator'],
    data() {
      return {
        parentValues: ['any'],
        value: '',
        flag: true
      }
    },
    props: {
      field: Object,
      formScope: String,
    },
    computed: {
      isSelectDisabled() {
        return this.items.length === 0 && this.field.parent_type === 'manual' && !this.field.allow_new_values;
      },
      rules() {
        return this.field.required && !this.isDisabled ? 'required' : '';
      },
      fieldID() {
        return 'mh-field-' + this.field.slug;
      },
      isText() {
        return this.field.control === 'text';
      },
      tags() {
        return this.field.allow_new_values && this.field.multiple;
      },
      comboBox() {
        return this.field.allow_new_values && !this.field.multiple
      },
      isDisabled() {
        if (this.isPropertyType
          || this.field.dependencies.all
          || typeof this.$store.state.draftProperty.propertyTypes === 'undefined'
          || this.$store.state.draftProperty.propertyTypes.length === 0
          || this.field.allow_new_values
        ) {
          return false;
        }

        let disabled = true;
        jQuery.each(this.$store.state.draftProperty.propertyTypes, (index, propertyType) => {
          if (typeof this.field.dependencies[propertyType] !== 'undefined' && this.field.dependencies[propertyType]) {
            disabled = false;
            return false;
          }
        });

        if (disabled) {
          if (this.isText) {
            this.value = '';
          } else {
            this.value = null;
          }
          this.$emit('showField', false);
        } else {
          this.$emit('showField', true);
        }

        return disabled;
      },
      items() {
        let values = [];

        if (this.field.parent_type === 'manual' && this.parentValues.length > 0 && this.parentValues[0] !== 'any') {
          jQuery.each(this.field.values['any'], (index, value) => {
            if (this.parentValues.indexOf(value.options.parent_term_name) !== -1) {
              values.push(value.name);
            }
          });
        } else {
          jQuery.each(this.parentValues, (index, parentValue) => {
            jQuery.each(this.field.values[parentValue], (index, value) => {
              values.push(value.name);
            });
          });
        }

        return values;
      },
      isPropertyType() {
        return this.field.base_slug === 'property_type';
      }
    },
    methods: {
      updateValue() {
        let attributeID = parseInt(this.field.id);
        let value = this.value;

        if ((typeof value === 'undefined' || value === null || value.length === 0)
          && typeof this.$store.state.draftProperty.attributes !== 'undefined') {
          this.$delete(this.$store.state.draftProperty.attributes, attributeID);
          window.MyHomePanelEventBus.$emit('updateParent' + this.field.id, ['any']);
          return;
        }

        if (!jQuery.isArray(value)) {
          value = [value];
        }

        if (typeof this.$store.state.draftProperty.attributes === 'undefined') {
          this.$store.state.draftProperty.attributes = {};
        }

        this.$set(this.$store.state.draftProperty.attributes, attributeID, value);
        window.MyHomePanelEventBus.$emit('updateParent' + this.field.id, value);

        if (this.isPropertyType) {
          let values = [];

          if (typeof this.field.parent_type !== 'undefined' && this.field.parent_type === 'manual') {
            jQuery.each(this.field.values['any'], (index, v) => {
              if (jQuery.inArray(v.name, value) !== -1) {
                values.push(v.slug);
              }
            });
          } else {
            jQuery.each(this.parentValues, (index, parentValue) => {
              jQuery.each(this.field.values[parentValue], (index, v) => {
                if (jQuery.inArray(v.name, value) !== -1) {
                  values.push(v.slug);
                }
              });
            });
          }

          this.$set(this.$store.state.draftProperty, 'propertyTypes', values);
        }
      }
    },
    created() {
      if (!this.isText) {
        this.value = null;
      }

      let attributeID = parseInt(this.field.id);
      if (typeof this.$store.state.draftProperty.attributes !== 'undefined'
        && typeof this.$store.state.draftProperty.attributes[attributeID] !== 'undefined'
        && this.$store.state.draftProperty.attributes[attributeID].length > 0) {
        if (this.isText) {
          this.value = this.$store.state.draftProperty.attributes[attributeID][0];
        } else if (!this.field.multiple) {
          this.value = this.$store.state.draftProperty.attributes[attributeID][0];
        } else {
          this.value = [];
          jQuery.each(this.$store.state.draftProperty.attributes[attributeID], (index, value) => {
            this.value.push(value);
          });
        }
      }

      if (this.field.parent_type === 'manual' && this.field.parent_id !== 0) {
        window.MyHomePanelEventBus.$on('updateParent' + this.field.parent_id, (values) => {

          let value = this.value;

          if (!this.isText && this.value !== null) {
            if (jQuery.isArray(this.value)) {
              this.value = [];
            } else {
              this.value = null;
            }
          }

          this.$nextTick(() => {
            if (values === null || (jQuery.isArray(values) && values[0] === null)) {
              this.parentValues = ['any'];
            } else {
              this.parentValues = values;
            }

            this.$nextTick(() => {
              if (jQuery.isArray(value)) {
                jQuery.each(value, (index, v) => {
                  if (this.items.indexOf(v) !== -1) {
                    this.value.push(v)
                  }
                })
              } else {
                if (this.items.indexOf(value) !== -1) {
                  this.value = value
                }
              }
            })
          });
        });
      }
    },
    mounted() {
      if (this.field.is_location_part) {
        window.MyHomePanelEventBus.$on('myhomeSetLocationParts' + this.field.location_type, (value) => {
          if (this.value === '' || this.value === null) {
            this.value = value;
          }
        });
      }

      this.flag = false;
    },
    watch: {
      value() {
        if (this.flag) {
          return;
        }
        this.updateValue();
      }
    }
  }
</script>
