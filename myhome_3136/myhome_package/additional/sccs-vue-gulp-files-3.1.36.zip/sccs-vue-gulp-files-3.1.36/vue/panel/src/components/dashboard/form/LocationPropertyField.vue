<template>
  <div class="mh-field-map">

    <v-text-field
      :id="fieldID"
      v-model.lazy="value"
      :required="field.required"
      v-validate="rules"
      :data-vv-scope="formScope"
      data-vv-name="location"
      :data-vv-as="field.name"
      :error-messages="errors.collect('location')"
      persistent-hint
      clearable
      browser-autocomplete="off"
      :placeholder="placeholder"
    >
    </v-text-field>

    <v-checkbox
      :label="translations.change_click"
      v-model="autocompleteAddress"
      color="primary"
    ></v-checkbox>

    <div class="mh-panel-submit__instruction" v-if="field.instructions !== ''">{{ field.instructions }}</div>

    <div ref="location" class="mh-field-map__location"></div>
  </div>
</template>

<script>
  export default {
    name: "location-property-field",
    inject: ['$validator'],
    data() {
      return {
        map: false,
        position: {
          lat: 53.013790,
          lng: 18.598444
        },
        currentMarker: false,
        currentZoom: 8,
        value: '',
        autocompleteAddress: true
      }
    },
    props: {
      field: Object,
      formScope: String
    },
    computed: {
      placeholder() {
        let placeholder = this.translations.enter_location;
        if (this.field.required) {
          placeholder += '*'
        }
        return placeholder;
      },
      rules() {
        let rules = '';

        if (this.field.required) {
          rules += 'required';
        }

        return rules;
      },
      fieldID() {
        return 'mh-field-' + this.field.slug;
      },
      translations() {
        return this.$store.state.translations;
      }
    },
    methods: {
      setMarker(location) {
        if (this.currentMarker !== false) {
          this.currentMarker.setMap(null);
        }
        this.currentMarker = new google.maps.Marker({
          map: this.map,
          position: location
        });
        if (this.currentZoom < 15) {
          this.map.setZoom(15);
        }

        this.$set(this.$store.state.draftProperty, 'location', location);
      },
      initMap() {
        this.map = new google.maps.Map(this.$refs.location, {
          center: this.position,
          zoom: 8,
          streetViewControl: false,
        });

        if (this.address !== '') {
          this.setMarker(this.position);
        }

        google.maps.event.addListener(this.map, 'click', (event) => {
          this.setMarker({lat: event.latLng.lat(), lng: event.latLng.lng()});
          if (this.autocompleteAddress) {
            let geocoder = new google.maps.Geocoder();
            geocoder.geocode({
              'latLng': event.latLng
            }, function (results, status) {
              if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                  this.value = results[0].formatted_address;
                  let service = new google.maps.places.PlacesService(this.map);
                  service.getDetails({placeId: results[0].place_id}, (place, status) => {
                    let addressComponents = place.address_components;
                    jQuery.each(addressComponents, (index, addressComponent) => {
                      window.MyHomePanelEventBus.$emit('myhomeSetLocationParts' + addressComponent.types[0], addressComponent.long_name);
                    });
                  });
                }
              }
            }.bind(this));
          }
        });

        google.maps.event.addListener(this.map, 'zoom_changed', () => {
          this.currentZoom = this.map.getZoom();
        });

        let input = document.getElementById(this.fieldID);
        let settings = {};

        if (typeof window.MyHomePanel.locationCountry !== 'undefined') {
          settings['componentRestrictions'] = {country: "us"};
        }

        let autocomplete = new google.maps.places.Autocomplete(input, settings);
        autocomplete.addListener("place_changed", () => {
          let placeResult = autocomplete.getPlace();

          this.value = placeResult.formatted_address;

          let location = {
            lat: placeResult.geometry.location.lat(),
            lng: placeResult.geometry.location.lng(),
          };

          this.setMarker(location);
          this.map.setCenter(location);

          let addressComponents = placeResult.address_components;
          jQuery.each(addressComponents, (index, addressComponent) => {
            window.MyHomePanelEventBus.$emit('myhomeSetLocationParts' + addressComponent.types[0], addressComponent.long_name);
          });
        });
      }
    },
    created() {
      if (typeof this.$store.state.draftProperty.position !== 'undefined' && (this.$store.state.draftProperty.position.lat !== 0 && this.$store.state.draftProperty.position.lng !== 0)) {
        this.position = this.$store.state.draftProperty.position;
      } else if (typeof window.MyHomePanel.initial_position !== 'undefined') {
        this.position = {
          lat: parseFloat(window.MyHomePanel.initial_position.lat),
          lng: parseFloat(window.MyHomePanel.initial_position.lng)
        }
      }

      if (typeof this.$store.state.draftProperty.address !== 'undefined') {
        this.value = this.$store.state.draftProperty.address;
      }
    },
    mounted() {
      let interval = setInterval(() => {
        if (typeof google !== 'undefined') {
          clearInterval(interval);
          this.initMap();
        }
      }, 200);
    },
    watch: {
      value() {
        this.$store.state.draftProperty.address = this.value;
      }
    }
  }
</script>
