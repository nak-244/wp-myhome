<template>
  <v-container grid-list-xl text-xs-center>
    <v-layout row wrap>
      <v-flex xs4 offset-xs4>
        <v-card>
          <v-card-title>
            <span class="headline">{{ translations.reset_password_link_expired }}</span>
          </v-card-title>

          <v-card-text>
            <v-alert type="error" :value="true">
              {{ translations.reset_password_link_expired_text }}
            </v-alert>
          </v-card-text>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn @click="onBack" flat>{{ translations.back_to_login }}</v-btn>
          </v-card-actions>
        </v-card>
      </v-flex>
    </v-layout>
  </v-container>

</template>

<script>
  export default {
    name    : "reset-password-link-expired",
    computed: {
      translations() {
        return this.$store.state.translations;
      }
    },
    methods : {
      onBack() {
        this.$router.push('/');
      }
    }
  }
</script>
