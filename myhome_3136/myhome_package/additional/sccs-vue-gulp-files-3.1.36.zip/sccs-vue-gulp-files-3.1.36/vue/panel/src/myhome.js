!function (e, n) {
  "object" == typeof exports && "undefined" != typeof module ? module.exports = n() : "function" == typeof define && define.amd ? define(n) : (e.__vee_validate_locale__en = e.__vee_validate_locale__en || {}, e.__vee_validate_locale__en.js = n())
}(this, function () {
  "use strict";
  var e, n = {
    name         : "myhome", messages: {
      _default       : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_value_is_not_valid
      }, after       : function (e, n) {
        var t = n[0];
        return e + " must be after " + (n[1] ? "or equal to " : "") + t + "."
      }, alpha_dash  : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_field_contain_alpha_numeric_and_dashes_underscores
      }, alpha_num   : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_field_contain_alpha_numeric
      }, alpha_spaces: function (e) {
        return e + " " + window.MyHomePanel.translations.validation_field_contain_alpha_spaces
      }, alpha       : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_field_contain_alpha
      }, before      : function (e, n) {
        var t = n[0];
        return e + " must be before " + (n[1] ? "or equal to " : "") + t + "."
      }, between     : function (e, n) {
        return e + " field must be between " + n[0] + " and " + n[1] + "."
      }, confirmed   : function (e) {
        return e + " " + window.MyHomePanel.translations.confirmation_does_not_match
      }, credit_card : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_field_is_invalid
      }, date_between: function (e, n) {
        return e + " must be between " + n[0] + " and " + n[1] + "."
      }, date_format : function (e, n) {
        return e + " must be in the format " + n[0] + "."
      }, decimal     : function (e, n) {
        void 0 === n && (n = []);
        var t = n[0];
        return void 0 === t && (t = "*"), e + " " + window.MyHomePanel.translations.validation_field_must_be_numeric_and_may_contain + " " + (t && "*" !== t ? t : "") + " " + window.MyHomePanel.translations.validation_decimal_points
      }, digits      : function (e, n) {
        return e + " field must be numeric and exactly contain " + n[0] + " digits."
      }, dimensions  : function (e, n) {
        return e + " " + window.MyHomePanel.translations.validation_field_must_be + " " + n[0] + " " + window.MyHomePanel.translations.validation_pixels_by + " " + n[1] + " " + window.MyHomePanel.translations.validation_pixels
      }, email       : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_field_must_be_email
      }, ext         : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_field_must_be_file
      }, image       : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_field_must_be_image
      }, in          : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_field_must_be_valid_value
      }, integer     : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_field_must_be_integer
      }, ip          : function (e) {
        return e + " field must be a valid ip address."
      }, length      : function (e, n) {
        var t = n[0], i = n[1];
        return i ? e + " length be between " + t + " and " + i + "." : e + " length must be " + t + "."
      }, max         : function (e, n) {
        return e + " " + window.MyHomePanel.translations.validation_field_may_not_be_greater_than + " " + n[0] + " " + window.MyHomePanel.translations.validation_characters
      }, max_value   : function (e, n) {
        return e + " " + window.MyHomePanel.translations.validation_field_must_be + " " + n[0] + " " + window.MyHomePanel.translations.validation_or_less
      }, mimes       : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_validation_field_must_have_valid_file_type
      }, min         : function (e, n) {
        return e + " " + window.MyHomePanel.translations.validation_field_must_be_at_least + " " + n[0] + " " + window.MyHomePanel.translations.validation_characters
      }, min_value   : function (e, n) {
        return e + " " + window.MyHomePanel.translations.validation_field_must_be + " " + n[0] + " " + window.MyHomePanel.translations.validation_or_more
      }, not_in      : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_field_must_be_valid_value
      }, numeric     : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_field_may_only_contain_numeric_characters
      }, regex       : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_field_format_is_invalid
      }, required    : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_field_is_required
      }, size        : function (e, n) {
        var t, i, a, r = n[0];
        return e + " " + window.MyHomePanel.translations.validation_not_size_must_be_less_than + " " + (t = r, i = 1024, a = 0 == (t = Number(t) * i) ? 0 : Math.floor(Math.log(t) / Math.log(i)), 1 * (t / Math.pow(i, a)).toFixed(2) + " " + ["Byte", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"][a]) + "."
      }, url         : function (e) {
        return e + " " + window.MyHomePanel.translations.validation_not_valid_url
      }
    }, attributes: {}
  };
  "undefined" != typeof VeeValidate && VeeValidate.Validator.localize(((e = {})[n.name] = n, e));
  return n
});

export
