<template>
  <div class="mh-field-additional-features">
    <h3>{{ translations.additional_features }}<span v-if="field.required">*</span></h3>
    <div class="mh-field__instruction" v-if="field.instructions !== ''">{{ field.instructions }}</div>
    <div class="mh-field__error" v-if="errors.has(formScope + '.additionalFeatures')">{{ errors.first(formScope + '.additionalFeatures') }}</div>

    <input
      type="hidden"
      name="additionalFeatures"
      v-model="additionalFeatures"
      v-validate="rules"
      :data-vv-scope="formScope"
    >

    <div class="mh-grid mh-field-additional-features__content">
      <div class="mh-grid__1of2">
        <h5 class="mh-field-additional-features__add-new-heading">{{ translations.add_new }}</h5>

        <div>
          <v-text-field
            :label="translations.name_additional"
            v-model="additionalFeature.name"
            v-validate="'required'"
            :error-messages="errors.collect('additionalFeatureName')"
            data-vv-scope="additionalFeature"
            :data-vv-as="translations.name"
            data-vv-name="additionalFeatureName"
            autocomplete="off"
          >
          </v-text-field>
        </div>

        <div>
          <v-text-field
            :label="translations.value_additional"
            v-model="additionalFeature.value"
            v-validate="'required'"
            :error-messages="errors.collect('additionalFeatureValue')"
            data-vv-scope="additionalFeature"
            data-vv-name="additionalFeatureValue"
            :data-vv-as="translations.value"
            autocomplete="off"
          >
          </v-text-field>
        </div>

        <div>
          <v-btn
            @click="onAdd"
            depressed
            color="secondary"
            class="mh-field-additional-features__add-btn"
          >
            <v-icon left white>add_circle</v-icon>
            {{ translations.add }}
          </v-btn>
        </div>

      </div>
      <div class="mh-grid__1of2">
        <h5 class="mh-field-additional-features__add-new-heading">{{ translations.list }} <span v-if="additionalFeatures.length > 0">({{ additionalFeatures.length }})</span></h5>
        <div v-if="additionalFeatures.length > 0" class="mh-field-additional-features__added">
          <div v-for="(item, index) in additionalFeatures" class="mh-field-additional-features__added__row">
            <span>{{ item.name }} : {{ item.value }}</span>
            <v-icon @click="onRemove(index)">delete</v-icon>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
  export default {
    name    : "additional-features",
    inject  : ['$validator'],
    data() {
      return {
        additionalFeatures: [],
        additionalFeature : {
          name : '',
          value: ''
        }
      }
    },
    props   : {
      field    : Object,
      creating : Boolean,
      formScope: String
    },
    computed: {
      rules() {
        let rules = '';
        if (this.field.required) {
          rules += 'additional_features'
        }
        return rules;
      },
      translations() {
        return this.$store.state.translations;
      }
    },
    methods : {
      onAdd() {
        this.$validator.validateAll('additionalFeature').then((result) => {
          if (result) {
            this.additionalFeatures.push(this.additionalFeature);
            this.$validator.pause();
            this.$set(this, 'additionalFeature', {
              name : '',
              value: ''
            });
            this.$nextTick(() => {
              this.$validator.resume();
            });
          }
        });
      },
      onRemove(index) {
        this.additionalFeatures.splice(index, 1);
      }
    },
    created() {
      if (typeof this.$store.state.draftProperty.additional_features !== 'undefined') {
        this.$set(this, 'additionalFeatures', this.$store.state.draftProperty.additional_features);
      }
    },
    watch   : {
      additionalFeatures() {
        this.$set(this.$store.state.draftProperty, 'additional_features', this.additionalFeatures);
      }
    }
  }
</script>
