<template>
    <v-app>
        <v-content class="mh-submit-property-wrapper">

            <v-progress-linear
                    v-if="loading"
                    class="mh-submit-property-progress-linear"
                    :indeterminate="true"
            >
            </v-progress-linear>

            <form @submit.prevent="onSubmit">

                <v-stepper alt-labels v-if="showSteps" v-model="currentStep">
                    <v-stepper-header v-if="steps.length > 1">
                        <template v-for="(step, index) in steps" :key="step.key+'-head'">
                            <v-stepper-step :step="index+1" :complete="currentStep > (index + 1)">{{ step.name }}
                            </v-stepper-step>
                            <v-divider v-if="index + 1 < steps.length"></v-divider>
                        </template>
                    </v-stepper-header>
                    <v-stepper-items>
                        <v-stepper-content v-for="(step, index) in steps" :key="step.key+'-step'" :step="index+1">

                            <v-layout row wrap class="mh-submit-property__step-content">
                                <h1 class="mh-submit-property__main-heading">{{ step.name }}</h1>
                                <property-field
                                        v-for="field in step.fields"
                                        :field="field"
                                        :creating="true"
                                        :form-scope="'submit-property-' + (index+1)"
                                >
                                </property-field>

                                <template v-if="showCaptcha">
                                    <div class="mh-submit-captcha-submit-property">
                                        <div
                                                v-if="(index+1) === steps.length"
                                                v-show="currentStep === steps.length"
                                                id="mh-submit-captcha"
                                        ></div>
                                    </div>
                                </template>

                                <div class="mh-submit-property-buttons">

                                    <div class="mh-submit-property-buttons__back" v-if="showBackButton">
                                        <v-btn
                                                :disabled="disablePreviousButton"
                                                @click="onBack"
                                                depressed
                                                large
                                        >
                                            <v-icon left>chevron_left</v-icon>
                                            {{ translations.previous_step }}
                                        </v-btn>
                                    </div>

                                    <div class="mh-submit-property-buttons__continue">
                                        <v-btn
                                                v-if="currentStep < steps.length"
                                                color="primary"
                                                @click="onContinue"
                                                :disabled="disableContinue"
                                                depressed
                                                large
                                        >
                                            {{ translations.continue }}
                                            <v-icon right>chevron_right</v-icon>
                                        </v-btn>

                                        <div v-if="errorMessage !== '' && currentStep === steps.length">
                                            {{ errorMessage }}
                                        </div>

                                        <v-btn
                                                v-if="currentStep === steps.length"
                                                color="primary"
                                                :disabled="isSubmitDisabled"
                                                :loading="inProgress"
                                                @click="onSubmit"
                                                depressed
                                                large
                                        >
                                            {{ translations.submit_property }}
                                        </v-btn>
                                    </div>
                                </div>

                            </v-layout>

                        </v-stepper-content>
                    </v-stepper-items>
                </v-stepper>
            </form>
        </v-content>

        <v-dialog v-model="showBuyPackage" class="mh-modal-package">
            <div>
                <div class="mh-modal-package__text">
                    {{ translations.no_package_yet }}
                </div>
                <div class="mh-modal-package__buttons">
                    <v-btn class="mh-modal-package__close" flat @click.stop="onShowBuyPackageClose">{{
                        translations.buy_later }}
                    </v-btn>
                    <v-btn class="mh-modal-package__buy" color="primary" depressed :href="pricingTableUrl">{{
                        translations.choose_package }}
                    </v-btn>
                </div>
            </div>
        </v-dialog>

        <v-dialog v-model="showModeration" class="mh-modal-package">
            <div>
                <div class="mh-modal-package__text">
                    {{ moderationMessage }}
                </div>
                <div class="mh-modal-package__buttons">
                    <v-btn class="mh-modal-package__close" color="primary" depressed @click.stop="onModerationClose">{{
                        translations.ok }}
                    </v-btn>
                </div>
            </div>
        </v-dialog>

    </v-app>
</template>

<script>
    import PropertyField from '../dashboard/form/PropertyField.vue'

    export default {
        name: "submit-property",
        components: {PropertyField},
        data() {
            return {
                inProgress: false,
                currentStep: 1,
                steps: [],
                loading: true,
                hasErrors: false,
                disableSubmit: false,
                disablePrevious: false,
                showBuyPackage: false,
                showModeration: false,
                moderationMessage: '',
                captchaId: null,
                errorMessage: '',
                captchaChecked: false,
                disableNavButtons: []
            }
        },
        $_veeValidate: {
            validator: 'new'
        },
        computed: {
            disablePreviousButton() {
                return this.disablePrevious || this.disableNavButtons.length > 0
            },
            disableContinue() {
                return this.disableNavButtons.length > 0
            },
            isSubmitDisabled() {
                if (this.disableNavButtons.length > 0) {
                    return true
                }

                if (this.showCaptcha && !this.captchaChecked) {
                    return true;
                }

                return this.disableSubmit;
            },
            showCaptcha() {
                return this.captchaEnabled && (typeof this.$store.state.user === 'undefined' || this.$store.state.user === false)
            },
            translations() {
                return this.$store.state.translations;
            },
            showSteps() {
                return !this.loading && this.steps.length;
            },
            showBackButton() {
                return this.currentStep > 1;
            },
            formScope() {
                return 'submit-property-' + this.currentStep;
            },
            captchaEnabled() {
                return window.MyHome.captcha_enabled;
            },
            pricingTableUrl() {
                return window.MyHomePanel.pricing_table;
            },
        },
        methods: {
            initiateCaptcha() {
                let timer = setInterval(() => {
                    if (window.grecaptcha) {
                        clearInterval(timer);

                        if (this.captchaId !== null) {
                            return;
                        }

                        if (this.currentStep === this.steps.length) {
                            this.captchaChecked = false;
                            this.captchaId = window.grecaptcha.render(document.getElementById('mh-submit-captcha'), {
                                'sitekey': window.MyHome.captcha_site_key,
                                'callback': () => {
                                    this.captchaChecked = true;
                                },
                                'expired-callback': () => {
                                    this.captchaChecked = false;
                                }
                            });
                        }
                    }
                }, 100);
            },
            setSteps() {
                this.$http.post(window.MyHomePanel.request_url, {
                    action: 'myhome_submit_property_steps'
                }, {emulateJSON: true}).then((response) => {
                    this.$nextTick(() => {
                        jQuery(window).trigger('mhPropertyFormReady');
                    });
                    this.steps = response.body;
                    if (this.showCaptcha) {
                        this.$nextTick(() => {
                            this.initiateCaptcha();
                        });
                    }
                }, (response) => {

                });
            },
            onSubmit() {
                if (this.isSubmitDisabled) {
                    return true;
                }
                this.$validator.validateAll(this.formScope).then((result) => {
                    if (result) {
                        this.disableSubmit = true;
                        this.saveDraft();
                    } else {
                        this.onErrors();
                    }
                });
            },
            onSuccess(response) {
                this.inProgress = false;
                this.disablePrevious = false;
                this.$set(this.$store.state, 'draftProperty', {});

                if (typeof response.redirect !== 'undefined' && response.redirect !== '') {
                    window.location.href = response.redirect
                } else if (response.is_logged) {
                    this.$set(this.$store.state, 'user', response.user);
                    window.MyHomePanelEventBus.$emit('updateAgent', response.user);
                    if (response.buy_package) {
                        window.location.href = this.pricingTableUrl
                        // this.showBuyPackage = true;
                    } else if (response.pending) {
                        this.moderationMessage = response.message;
                        this.showModeration = true;
                    } else {
                        this.$router.push('/dashboard/properties');
                    }
                } else {
                    this.$store.state.messages.push({
                        type: 'info',
                        text: response.message
                    });

                    let activeTab = window.MyHomePanel.active_tab;
                    let route;
                    if (activeTab === 'login' || window.MyHomePanel.registration === 'false') {
                        route = '/';
                    } else {
                        route = '/register';
                    }
                    this.$router.push(route);
                }
            },
            onShowBuyPackageClose() {
                this.showBuyPackage = false;
            },
            onModerationClose() {
                this.showModeration = false;
            },
            onError(response) {
                this.inProgress = false;
                this.disablePrevious = false;
                this.disableSubmit = false;

                if (typeof response.text !== 'undefined' && response.text !== '') {
                    this.errorMessage = response.text;
                }
            },
            saveDraft() {
                this.disablePrevious = true;
                this.inProgress = true;

                let data = {
                    action: 'myhome_user_panel_save_draft',
                    draft: this.$store.state.draftProperty,
                    _wpnonce: this.$store.state.nonce
                };

                if (this.showCaptcha) {
                    data['captcha'] = grecaptcha.getResponse(this.captchaId);
                }

                this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {
                    if (this.showCaptcha) {
                        grecaptcha.reset();
                    }

                    if (response.body.success) {
                        this.onSuccess(response.body);
                    } else {
                        this.onError(response.body);
                    }
                }, (response) => {
                    this.onError(response.body);
                });
            },
            onContinue() {
                this.$validator.validateAll(this.formScope).then((result) => {
                    if (result) {
                        this.currentStep++;
                        if (jQuery(window).scrollTop() > 300) {
                            jQuery(window).scrollTop(0);
                        }

                        if (this.showCaptcha) {
                            if (this.currentStep === this.steps.length) {
                                this.$nextTick(() => {
                                    this.initiateCaptcha();
                                });
                            }
                        }
                    } else {
                        this.onErrors();
                    }
                });
            },
            onErrors() {
                let errors = jQuery('.mh-panel-submit__error-info');
                let errorsStandard = jQuery("[aria-invalid=true]");
                let offset = 0;
                if (errors.length > 0 && errorsStandard.length > 0) {
                    offset = errors.offset().top < errorsStandard.offset().top ? errors.offset().top : errorsStandard.offset().top;
                } else if (errors.length > 0) {
                    offset = errors.offset().top;
                } else if (errorsStandard.length > 0) {
                    offset = errorsStandard.offset().top;
                }

                jQuery('html, body').animate({
                    scrollTop: offset - 100
                }, 500);
            },
            onBack() {
                if (this.currentStep > 1) {
                    this.currentStep--;
                }
            }
        },
        created() {
            this.$set(this.$store.state, 'draftProperty', {});
            this.setSteps();
            this.loading = false;

            window.MyHomePanelEventBus.$on('lockButtons', (type) => {
                if (this.disableNavButtons.indexOf(type) !== -1) {
                    this.disableNavButtons.splice(this.disableNavButtons.indexOf(type), 1)
                } else {
                    this.disableNavButtons.push(type)
                }
            })
        },
        watch: {
            showBuyPackage(value) {
                if (value) {
                    return;
                }

                this.$nextTick(() => {
                    this.$router.push('/dashboard/properties');
                });
            },
            showModeration(value) {
                if (value) {
                    return;
                }

                this.$nextTick(() => {
                    this.moderationMessage = '';
                    this.$router.push('/dashboard/properties');
                });
            }
        }
    }
</script>
