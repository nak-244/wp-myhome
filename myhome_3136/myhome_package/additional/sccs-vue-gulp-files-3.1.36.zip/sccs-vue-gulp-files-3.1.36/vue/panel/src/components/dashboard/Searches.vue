<template>
  <v-card id="myhome-panel-searches" class="mh-save-search">
    <div class="mh-2-col-title">
      <div class="mh-2-col-title__col">
        <h1>{{ translations.saved_searches }}</h1>
      </div>
      <div class="mh-2-col-title__col">
        <v-text-field
          append-icon="search"
          :label="translations.search"
          single-line
          hide-details
          v-model="search"
        ></v-text-field>
      </div>
    </div>

    <div v-if="inProgress" class="mh-panel-save-search-progress">
      <v-progress-linear :indeterminate="true"></v-progress-linear>
    </div>

    <v-data-table
      light
      :headers="headers"
      :items="savedSearches"
      :no-data-text="translations.saved_searches_no_data"
      :no-results-text="translations.saved_searches_no_results"
      :rows-per-page-text="translations.saved_searches_per_page"
      :rows-per-page-items="rowsPerPageItems"
      :search="search"
      class="mh-my-search-table"
      @update:pagination="onPaginationUpdate"
    >
      <template slot="items" slot-scope="props">
        <td class="mh-my-search-table__name">
          <a :href="props.item.url" target="_blank">
            <span v-if="props.item.name !== ''">{{ props.item.name }}</span>
            <span v-else class="mh-my-search-table__name__empty">-</span>
          </a>
        </td>
        <td class="mh-my-search-table__url">
          <a :href="props.item.url" target="_blank">{{ props.item.url }}</a>
        </td>
        <td class="mh-my-search-table__delete">
          <v-icon @click="remove(props.item)">delete</v-icon>
        </td>
      </template>
      <template slot="pageText" slot-scope="props">
        {{ props.pageStart }} - {{ props.pageStop }} / {{ props.itemsLength }}
      </template>
    </v-data-table>

  </v-card>

</template>

<script>
  export default {
    name    : "Searches",
    data() {
      return {
        search    : '',
        initiated : false,
        inProgress: false
      }
    },
    computed: {
      headers() {
        return [
          {text: this.translations.name, value: 'name', class: 'mh-saved-searches-table__name'},
          {text: this.translations.link, value: 'link', class: 'mh-saved-searches-table__link'},
          {text: this.translations.remove, value: false, sortable: false, class: 'mh-saved-searches-table__actions'},
        ];
      },
      savedSearches() {
        return this.$store.state.user.searches;
      },
      translations() {
        return this.$store.state.translations;
      },
      rowsPerPageItems() {
        return [10, 25, 50, {"text": this.translations.all, "value": -1}];
      }
    },
    methods : {
      onPaginationUpdate() {
        if (this.initiated) {
          let viewportTop = jQuery(window).scrollTop();
          let viewportBottom = viewportTop + jQuery(window).height();
          let elementTop = jQuery('#myhome-panel-searches').offset().top;

          if (!(elementTop >= viewportTop && elementTop <= viewportBottom)) {
            jQuery(window).scrollTop(elementTop);
          }
        }
      },
      remove(search) {
        if (this.inProgress) {
          return false;
        }

        this.inProgress = true;

        let data = {
          search: search,
          action: 'myhome_remove_search'
        };
        this.$http.post(window.MyHome.requestUrl, data, {emulateJSON: true}).then(() => {
          jQuery.each(this.savedSearches, (index, s) => {
            if (s.url === search.url && s.name === search.name) {
              this.savedSearches.splice(index, 1);
              return false;
            }
          });
          this.inProgress = false;
        }, () => {
          this.inProgress = false;
        });
      }
    },
    mounted() {
      this.initiated = true;
    }
  }
</script>
