<template>
  <div class="mh-field-plans">
    <h3>{{ translations.plans }}<span v-if="field.required">*</span></h3>
    <div class="mh-field__instruction" v-if="field.instructions !== ''">{{ field.instructions }}</div>
    <div class="mh-field__error" v-if="errors.has('plan')">{{ errors.first('plan') }}</div>
    <div class="mh-field__error" v-if="errors.has(formScope + '.plans')">{{ errors.first(formScope + '.plans') }}</div>

    <input
      style="display: none;"
      type="file"
      ref="plans"
      :multiple="true"
      @change="uploadFiles($event)"
      v-validate="planRules"
      :data-vv-as="translations.plan"
      name="plan"
    >

    <input
      id="plans"
      type="hidden"
      v-model="plans"
      name="plans"
      v-validate="plansRules"
      :data-vv-scope="formScope"
    >
    <div class="mh-field-plans__list">
      <div v-if="plans.length" three-line subheader>

        <div v-for="(plan, index) in plans" :key="index">

          <div class="mh-field-plans__list__row">
            <div class="mh-field-plans__list__image">
              <v-progress-circular
                indeterminate
                :size="48"
                :width="2"
                :rotate="-90"
                color="primary"
                v-if="plan.isProcessing"
              >
              </v-progress-circular>
              <img class="mh-panel-submit__plan-image" :src="plan.url" alt="">
            </div>
            <div class="mh-field-plans__list__text">
              <v-text-field
                v-model="plan.name"
                :label="translations.name"
              >
              </v-text-field>
            </div>
            <div class="mh-field-plans__list__remove">
              <i
                v-if="plan.status === 4"
                @click="onRemovePlan(index)"
                class="fa fa-times"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <v-btn
      @click="onAddPlan"
      :disabled="disableButton"
      depressed
      color="secondary"
    >
      <v-icon left dark>cloud_upload</v-icon>
      {{ translations.upload_plans }}
    </v-btn>

  </div>
</template>

<script>
  const STATUS_WAIT = 1;
  const STATUS_UPLOAD = 2;
  const STATUS_PROCESS = 3;
  const STATUS_COMPLETE = 4;

  export default {
    name    : "plan-property-field",
    inject  : ['$validator'],
    data() {
      return {
        disableButton: false,
        plans        : []
      }
    },
    props   : {
      field    : Object,
      formScope: String
    },
    computed: {
      plansRules() {
        let rules = '';

        if (this.field.required) {
          rules += 'plans_required';
        }

        if (parseInt(window.MyHomePanel.validation['plans_max-number']) > 0) {
          rules += rules !== '' ? '|plans_limit' : 'plans_limit';
        }

        return rules;
      },
      planRules() {
        let rules = 'image';
        let maxPlanSize = parseInt(window.MyHomePanel.validation['plans_max-size']) * 1024;
        if (maxPlanSize > 0) {
          rules += '|size:' + maxPlanSize;
        }

        return rules;
      },
      translations() {
        return this.$store.state.translations;
      }
    },
    methods : {
      onAddPlan() {
        document.getElementById("plans").value = "";
        this.$refs.plans.click();
      },
      onRemovePlan(index) {
        this.plans.splice(index, 1);
      },
      uploadFiles(e) {
        this.$validator.validate('plan').then((result) => {
          if (result) {
            this.disableButton = true;
            let files = e.target.files || e.dataTransfer.files;
            if (files.length) {
              window.MyHomePanelEventBus.$emit('lockButtons', 'plans')

              for (let i = 0; i < files.length; i++) {
                this.plans.push({
                  id          : 0,
                  name        : files[i].name,
                  size        : this.fileSize(files[i].size),
                  status      : STATUS_WAIT,
                  url         : '',
                  file        : files[i],
                  isProcessing: false,
                  progress    : 0
                });
              }
              this.$nextTick(() => {
                this.startUpload();
              });
            }
          }
        });
      },
      startUpload() {
        let startedUpload = false;
        jQuery.each(this.plans, (index, plan) => {
          if (plan.status === STATUS_WAIT) {
            this.upload(index, plan);
            startedUpload = true;
            return false;
          }
        });

        if (!startedUpload) {
          this.disableButton = false;
          window.MyHomePanelEventBus.$emit('lockButtons', 'plans')
        }
      },
      upload(index, plan) {
        this.$set(this.plans[index], 'isProcessing', true);
        this.$set(this.plans[index], 'status', STATUS_UPLOAD);
        let formData = new FormData();
        formData.append('file', plan.file);
        formData.append('action', 'myhome_user_panel_upload_plan');

        let xhr = new XMLHttpRequest();
        xhr.upload.addEventListener('progress', (e) => {
          let total = e.total;
          let loaded = e.loaded;
          this.$set(this.plans[index], 'progress', parseInt((100 / total) * loaded));
        }, false);

        xhr.upload.addEventListener('loadend', () => {
          this.$set(this.plans[index], 'status', STATUS_PROCESS);
        });

        xhr.onreadystatechange = () => {
          if (xhr.readyState == XMLHttpRequest.DONE) {
            this.$set(this.plans[index], 'isProcessing', false);
            this.$set(this.plans[index], 'status', STATUS_COMPLETE);
            let plan = JSON.parse(xhr.responseText);
            this.$set(this.plans[index], 'url', plan.url);
            this.$set(this.plans[index], 'image_id', plan.image_id);
            this.startUpload();
          }
        };

        xhr.open('POST', this.$store.state.requestUrl);
        xhr.send(formData);
      },
      fileSize(bytes) {
        bytes = parseInt(bytes);
        let sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        if (bytes == 0) return '0 Byte';
        let i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
      }
    },
    created() {
      if (typeof this.$store.state.draftProperty.plans !== 'undefined') {
        this.plans = this.$store.state.draftProperty.plans;
      }
    },
    watch   : {
      plans() {
        this.$set(this.$store.state.draftProperty, 'plans', this.plans);
      }
    }
  }
</script>
