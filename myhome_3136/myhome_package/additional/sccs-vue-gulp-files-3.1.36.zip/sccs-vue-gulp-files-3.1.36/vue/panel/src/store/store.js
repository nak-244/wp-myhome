import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

export const store = new Vuex.Store({
  state    : {
    user          : false,
    translations  : false,
    registration  : false,
    captchaEnabled: false,
    captchaKey    : '',
    captchaId     : 0,
    nonce         : '',
    requestUrl    : '',
    fields        : [],
    draftProperty : {},
    messages      : []
  },
  getters  : {},
  mutations: {
    updateUser(state, user) {
      this.state.user = user;
    }
  }
});
