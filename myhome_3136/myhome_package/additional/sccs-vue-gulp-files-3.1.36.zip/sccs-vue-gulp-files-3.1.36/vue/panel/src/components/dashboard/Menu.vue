<template>
  <v-navigation-drawer class="mh-app__sidebar-nav">
    <v-toolbar flat>
      <v-list>
        <v-list-tile>

          <v-avatar
            @click="onEditProfile"
          >

            <img v-if="user.image_url !== ''" :src="user.image_url" alt="avatar">

            <div v-else class="mh-app__sidebar-nav__avatar-placeholder">
              <i class="fa fa-camera"></i>
            </div>

          </v-avatar>

          <v-list-tile-title class="title">
            {{ user.display_name }}
          </v-list-tile-title>
        </v-list-tile>
      </v-list>
    </v-toolbar>
    <v-list dense class="pt-0">
      <v-list-tile
        v-for="item in items"
        :class="{active: isActive(item.link)}"
        :key="item.title"
        @click="setPage(item.link)"
      >
        <v-list-tile-action>
          <v-icon>{{ item.icon }}</v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>{{ item.title }}</v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile>
      <v-list-tile v-if="showMyProfile" @click="onViewProfile">
        <v-list-tile-action>
          <v-icon>assignment_ind</v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>{{ translations.view_my_profile }}</v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile>
      <v-list-tile @click.stop="onLogout">
        <v-list-tile-action>
          <v-icon>exit_to_app</v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>{{ translations.logout }}</v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile>
    </v-list>
  </v-navigation-drawer>
</template>

<script>
  export default {
    name    : "panel-menu",
    data() {
      return {
        currentPath: '/dashboard'
      }
    },
    computed: {
      showMyProfile() {
        return jQuery.inArray('buyer', this.user.roles) === -1 || window.MyHome.buyer_can_submit_property;
      },
      translations() {
        return this.$store.state.translations;
      },
      user() {
        return this.$store.state.user;
      },
      items() {
        let items = [];

        if (jQuery.inArray('buyer', this.user.roles) === -1 || window.MyHome.buyer_can_submit_property) {
          items.push(
            {title: this.translations.submit_property, icon: 'add_circle', link: '/submit-property'},
            {title: this.translations.my_properties, icon: 'home', link: '/dashboard/properties'}
          );
        }

        if (jQuery.inArray('super_agent', this.user.roles) !== -1 || jQuery.inArray('administrator', this.user.roles) !== -1) {
          items.push(
            {title: this.translations.moderation, icon: 'view_list', link: '/dashboard/moderation'},
            {title: this.translations.trash, icon: 'delete', link: '/dashboard/trash'}
          );
        }

        if (jQuery.inArray('agency', this.user.roles) !== -1) {
            items.push({title: this.translations.agents, icon: 'people', link: '/dashboard/agents'});
        }

        if (window.MyHome.show_favorite) {
          items.push({title: this.translations.favorite, icon: 'favorite', link: '/dashboard/favorite'});
        }

        if (window.MyHome.show_save_search) {
          items.push({title: this.translations.saved_searches, icon: 'search', link: '/dashboard/searches'})
        }

        items.push(
          {title: this.translations.edit_profile, icon: 'account_circle', link: '/dashboard/profile'},
        );

        return items;
      }
    },
    methods : {
      onEditProfile() {
        this.$router.push('/dashboard/profile');
      },
      isActive(path) {
        return path === this.currentPath;
      },
      onViewProfile() {
        window.location.href = this.user.link;
      },
      onLogout() {
        window.MyHomePanelEventBus.$emit('onUserLogout');
      },
      setPage(link) {
        this.$router.push(link);
      }
    },
    created() {
      window.MyHomeEventBus.$on('routeChange', () => {
        this.currentPath = this.$router.currentRoute.path;
      });
    },
    mounted() {
      this.currentPath = this.$router.currentRoute.path;
    }
  }
</script>
