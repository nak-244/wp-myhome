<template>
  <div class="mh-field-virtual-tour">
    <h3>{{ translations.virtual_tour }}</h3>
    <div class="mh-field__instruction" v-if="field.instructions !== ''">{{ field.instructions }}</div>

    <v-text-field
      :label="field.name"
      v-model.lazy="value"
      :required="field.required"
      :data-vv-scope="formScope"
      v-validate="rules"
      prepend-icon="360"
      :error-messages="errors.collect(fieldID)"
      :data-vv-name="fieldID"
      :data-vv-as="field.name"
      persistent-hint
      clearable
    >
    </v-text-field>
  </div>
</template>

<script>
  export default {
    inject  : ['$validator'],
    name    : "virtual-tour-property-field",
    data() {
      return {
        value: ''
      }
    },
    computed: {
      fieldID() {
        return 'mh-unique-field-virtual-tour';
      },
      translations() {
          return this.$store.state.translations;
      },
      rules() {
        return this.field.required ? 'required' : '';
      }
    },
    props   : {
      field    : Object,
      formScope: String
    },
    created() {
      if (typeof this.$store.state.draftProperty.virtual_tour !== 'undefined') {
        this.value = this.$store.state.draftProperty.virtual_tour;
      }
    },
    watch   : {
      value() {
        this.$set(this.$store.state.draftProperty, 'virtual_tour', this.value);
      }
    }
  }
</script>
