<template>
  <div id="myhome-panel-profile" class="mh-edit-profile">
    <div>
      <h1>{{ translations.edit_profile }}</h1>

      <v-progress-linear
        v-if="showProgress"
        :indeterminate="true"
        class="mh-profile-progress-bar"
      >
      </v-progress-linear>

      <div class="mh-edit-profile__inner">
        <div class="mh-edit-profile__info">
          <form @submit.prevent="onSubmit">

            <v-text-field
              :label="translations.public_name"
              v-model="user.display_name"
              data-vv-scope="profile"
              v-validate="'required'"
              :data-vv-as="translations.public_name"
              data-vv-name="public_name"
              prepend-icon="perm_identity"
              :error-messages="errors.collect('public_name')"
            >
            </v-text-field>

            <v-select
              v-if="showAccountTypes"
              v-model="user.account_type"
              :items="accountTypes"
              item-text="name"
              item-value="value"
              single-line
              prepend-icon="supervisor_account"
            >
            </v-select>

            <v-text-field
              :label="translations.email"
              v-model="user.email"
              data-vv-scope="profile"
              v-validate="'required|email'"
              data-vv-name="email"
              :data-vv-as="translations.email"
              prepend-icon="mail_outline"
              :error-messages="errors.collect('email')"
            ></v-text-field>

            <v-text-field
              :label="translations.phone_number"
              v-model="user.phone"
              prepend-icon="phone"
            >
            </v-text-field>

            <input
              style="display:none"
              type="file"
              ref="image"
              accept="image/*"
              :multiple="false"
              @change="onBeforeUpload($event)"
              v-validate.reject="'image'"
              :data-vv-as="translations.profile_picture"
              data-vv-name="profileImage"
            >

            <div v-if="hasImage" class="mh-edit-profile__image-wrapper">
              <img :src="user.image_url" alt="">
              <v-btn
                @click="onDeleteImage"
                icon
                ripple
                class="mh-edit-profile__image-trash"
              >
                <v-icon>delete</v-icon>
              </v-btn>
            </div>
            <div class="clearfix"></div>

            <span v-if="imageError">{{ imageError }}</span>

            <span v-if="errors.has('profileImage')">{{ errors.first('profileImage') }}</span>

            <v-btn
              @click="onUpload"
              color="secondary"
              depressed
            >
              <v-icon left dark>add_a_photo</v-icon>
              {{ translations.edit_profile_upload_photo }}
            </v-btn>

            <template v-if="showAdditional">
              <h2 class="mh-edit-profile__additional-info-heading">{{ translations.edit_profile_additional_information
                }}</h2>
              <div v-for="field in user.fields" :key="field.slug">
                <v-text-field
                  :label="field.name"
                  v-model="field.value"
                ></v-text-field>
              </div>

              <div v-for="social in user.social" :key="social.key">
                <v-text-field
                  :label="social.key"
                  v-model="social.value"
                >
                </v-text-field>
              </div>
            </template>

            <v-btn
              @click="onSubmit"
              color="primary"
              depressed
              large
            >
              {{ translations.update_profile }}
            </v-btn>
          </form>
        </div>

        <div class="mh-edit-profile__password">
          <div class="mh-edit-profile__password__inner">
            <h2 class="mh-edit-profile__password__heading">{{ translations.change_password }}</h2>
            <form @submit.prevent="onChangePassword">
              <v-text-field
                :label="translations.old_password"
                type="password"
                v-model="password.old"
                v-validate="'required|min:3'"
                prepend-icon="lock_outline"
                :error-messages="errors.collect('oldPassword')"
                data-vv-scope="changePassword"
                data-vv-name="oldPassword"
                :data-vv-as="translations.old_password"
                required
              >
              </v-text-field>

              <v-text-field
                :label="translations.new_password"
                type="password"
                v-model="password.new"
                prepend-icon="lock_outline"
                v-validate="'required|min:3'"
                :error-messages="errors.collect('newPassword')"
                data-vv-scope="changePassword"
                data-vv-name="newPassword"
                :data-vv-as="translations.new_password"
                required
              >
              </v-text-field>

              <v-btn
                @click="onChangePassword"
                color="secondary"
                depressed
              >
                {{ translations.change_password }}
              </v-btn>
            </form>
          </div>

          <div class="mh-edit-profile__join-agency" v-if="showJoinAgency">
            <h2 class="mh-edit-profile__join-agency__heading">{{ translations.join_agency }}</h2>
            <form @submit.prevent="joinAgency">
              <v-text-field
                v-model="inviteCode"
                v-validate="'required'"
                :label="translations.agency_code"
                data-vv-name="agencyCode"
                data-vv-as="Agency code"
                data-vv-scope="joinAgency"
                :error-messages="errors.collect('agencyCode')"
                required
              ></v-text-field>
              <v-btn
                @click="joinAgency"
                color="secondary"
                depressed
              >
                {{ translations.join_agency }}
              </v-btn>
            </form>
            <div v-if="showInvites" class="mh-edit-profile__invitations">
              <h2>{{ translations.agency_invitation }}</h2>
              <div v-for="invite in user.invites" class="mh-edit-profile__invitations__content">
                {{ invite.name }}
                <div class="mh-edit-profile__invitations__icons">
                  <v-icon @click="acceptInvite(invite.ID)">done</v-icon>
                  <v-icon @click="declineInvite(invite.ID)">delete</v-icon>
                </div>
              </div>
            </div>
          </div>

          <div class="mh-edit-profile__has-agency-wrapper" v-if="hasAgency">
            <h2>{{ translations.account_assigned }}</h2>
            <div class="mh-edit-profile__has-agency">
              <div class="mh-edit-profile__has-agency__inner">
                <div>{{ user.agency.name }}</div>
                <v-icon @click="removeAgency">close</v-icon>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>

    <v-dialog
      v-model="showDialog"
      max-width="400"
    >
      <h3 v-html="message"></h3>
      <v-btn
        color="primary"
        depressed
        @click.stop="showDialog = false">{{ translations.close }}
      </v-btn>
    </v-dialog>
  </div>
</template>

<script>
  export default {
    name: "profile",
    data() {
      return {
        inviteCode: '',
        showProgress: false,
        showDialog: false,
        message: '',
        password: {
          old: '',
          new: ''
        },
        imageError: false,
        user: false
      }
    },
    $_veeValidate: {
      validator: 'new'
    },
    computed: {
      showAdditional() {
        return this.user.roles.indexOf('buyer') === -1;
      },
      translations() {
        return this.$store.state.translations;
      },
      showAccountTypes() {
        return window.MyHomePanel.user_select_type && this.user.roles.indexOf('administrator') === -1;
      },
      accountTypes() {
        let types = [];

        jQuery.each(window.MyHomePanel.account_types, (value, name) => {
          types.push({name: name, value: value});
        });

        return types;
      },
      showJoinAgency() {
        return (jQuery.inArray('agent', this.user.roles) !== -1 || jQuery.inArray('super_agent', this.user.roles) !== -1) && window.MyHomePanel.agent_join_agency && !this.user.has_agency;
      },
      hasAgency() {
        return (jQuery.inArray('agent', this.user.roles) !== -1 || jQuery.inArray('super_agent', this.user.roles) !== -1) && window.MyHomePanel.agent_join_agency && this.user.has_agency;
      },
      showInvites() {
        return typeof this.user.invites !== 'undefined' && this.user.invites.length > 0;
      },
      hasImage() {
        return typeof this.user.image_url !== 'undefined' && this.user.image_url !== '';
      },
    },
    methods: {
      removeAgency() {
        this.showProgress = true;
        let data = {
          _wpnonce: this.$store.state.nonce,
          agency_id: this.user.agency.id,
          action: 'myhome_user_panel_remove_agency'
        };
        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {
          let data = response.body;
          if (data.success) {
            this.$set(this.$store.state, 'user', data.user);
            this.$set(this, 'user', data.user);
          }
          this.message = data.message;
          this.showProgress = false;
        }, (response) => {
          this.showProgress = false;
        });
      },
      joinAgency() {
        this.$validator.validateAll('joinAgency').then((result) => {
          if (!result) {
            return;
          }
          this.showProgress = true;
          let data = {
            _wpnonce: this.$store.state.nonce,
            action: 'myhome_user_panel_join_agency',
            invite_code: this.inviteCode
          };
          this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {
            let data = response.body;
            if (data.success) {
              this.$set(this.$store.state, 'user', data.user);
              this.$set(this, 'user', data.user);
            }
            this.message = data.message;
            this.showProgress = false;
            this.$validator.pause();
            this.inviteCode = null;
            this.$nextTick(() => {
              this.$validator.resume();
            });
          }, (response) => {
            this.showProgress = false;
          });
        });
      },
      acceptInvite(agencyID) {
        this.showProgress = true;
        let data = {
          _wpnonce: this.$store.state.nonce,
          agency_id: agencyID,
          action: 'myhome_user_panel_accept_invite'
        };
        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {
          let data = response.body;
          if (data.success) {
            this.$set(this.$store.state, 'user', data.user);
            this.$set(this, 'user', data.user);
          }
          this.message = data.message;
          this.showProgress = false;
        }, (response) => {
          this.showProgress = false;
        });
      },
      declineInvite(agencyID) {
        this.showProgress = true;
        let data = {
          _wpnonce: this.$store.state.nonce,
          agency_id: agencyID,
          action: 'myhome_user_panel_decline_invite'
        };
        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {
          let data = response.body;
          if (data.success) {
            this.$set(this.$store.state, 'user', data.user);
            this.$set(this, 'user', data.user);
          }
          this.message = data.message;
          this.showDialog = true;
          this.showProgress = false;
        }, (response) => {
          this.showProgress = false;
        });
      },
      onDeleteImage() {
        this.$set(this.user, 'image_id', 0);
        this.$set(this.user, 'image_url', '');
      },
      onBeforeUpload(e) {
        this.$validator.validate('profileImage').then((result) => {
          if (result) {
            this.uploadProfileImage(e);
          }
        });
      },
      onUpload() {
        this.imageError = false;
        this.$refs.image.click();
      },
      uploadProfileImage(e) {
        this.showProgress = true;

        let timeout = 0;
        if (this.image) {
          this.image = false;
          timeout = 400;
        }

        setTimeout(() => {
          let files = e.target.files || e.dataTransfer.files;
          if (files.length) {
            this.isUploading = true;
            this.disableButton = true;
          } else {
            return;
          }

          for (let i = 0; i < files.length; i++) {
            const file = files.item(i);
            let formData = new FormData();
            formData.append('file', file);
            formData.append('action', 'myhome_user_panel_upload_image');
            formData.append('type', 'user');
            let xhr = new XMLHttpRequest();

            xhr.onreadystatechange = () => {
              if (xhr.readyState == XMLHttpRequest.DONE) {
                this.$nextTick(() => {
                  let response = JSON.parse(xhr.responseText);
                  if (typeof response.success !== 'undefined' && !response.success) {
                    this.imageError = response.message;
                  } else {
                    this.$set(this.user, 'image_id', response.image_id);
                    this.$set(this.user, 'image_url', response.url);
                  }
                  this.showProgress = false;
                });
              }
            };

            xhr.open('POST', this.$store.state.requestUrl);
            xhr.send(formData);
          }
        }, timeout);

      },
      onSubmit() {
        this.$validator.validateAll('profile').then((result) => {
          if (result) {
            this.submit();
          }
        });
      },
      submit() {
        jQuery(window).scrollTop($('#myhome-panel-profile').offset().top);

        this.showProgress = true;
        let data = {
          action: 'myhome_user_panel_save_user',
          user: this.user,
          _wpnonce: this.$store.state.nonce
        };

        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {
          this.$set(this.$store.state, 'user', response.body.user);
          this.submitMessage(response.body);
        }, (response) => {
          this.submitMessage(response.body);
        });
      },
      submitMessage(response) {
        this.showProgress = false;
        this.message = response.message;
        this.$set(this.$store.state, 'user', response.user);
        this.showDialog = true;
        this.$nextTick(() => {
          this.$validator.errors.clear('profile');
        });
      },
      onChangePassword() {
        this.$validator.validateAll('changePassword').then((result) => {
          if (result) {
            this.changePassword();
          }
        });
      },
      changePassword() {
        this.showProgress = true;
        let data = {
          password: this.password,
          _wpnonce: this.$store.state.nonce,
          action: 'myhome_user_panel_change_password'
        };

        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {
          this.passwordChangeMessage(response.body);
        }, (response) => {
          this.passwordChangeMessage(response.body);
        });
      },
      passwordChangeMessage(response) {
        this.showProgress = false;
        this.message = response.message;
        this.$validator.pause();
        this.$set(this, 'password', {old: '', new: ''});
        this.$nextTick(() => {
          this.$validator.resume();
        });
        this.showDialog = true;
      }
    },
    created() {
      this.user = jQuery.extend({}, this.$store.state.user);
    }
  }
</script>
