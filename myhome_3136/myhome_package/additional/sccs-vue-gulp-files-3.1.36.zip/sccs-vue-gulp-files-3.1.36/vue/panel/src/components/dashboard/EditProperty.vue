<template>
  <v-card class="mh-edit-property">
    <h1>
      {{ translations.edit_property }}
    </h1>

    <div v-if="showProgress" class="mh-edit-property-loader-top">
      <v-progress-linear :indeterminate="true"></v-progress-linear>
    </div>

    <div v-if="!showProgress">
      <div v-for="step in steps" class="mh-edit-next-step">
        <v-layout row wrap>
          <property-field
            v-for="field in step.fields"
            :field="field"
            form-scope="property"
          >
          </property-field>
        </v-layout>
      </div>

      <div class="mh-edit-property-button">

        <template v-if="showModerationButtons">
          <v-btn depressed @click="onApprove" :loading="loadingApprove">
            <i class="material-icons">done</i> {{ translations.approve }}
          </v-btn>
          <v-btn depressed @click="onDiscard" :loading="loadingDiscard">
            <i class="material-icons">close</i> {{ translations.discard }}
          </v-btn>
        </template>

        <v-btn @click="onSave" large depressed color="primary" :disabled="disableSubmit" :loading="inProgress">
          {{ translations.update_property }}
        </v-btn>
      </div>
    </div>

    <v-dialog v-model="showPropertySaved">
      <h3>{{ translations.update_property_success }}</h3>
      <v-btn color="primary" depressed @click="onSaveConfirm">{{ translations.ok }}</v-btn>
    </v-dialog>

    <v-dialog v-model="showModeration" class="mh-modal-package">
      <div>
        <div class="mh-modal-package__text">
          {{ moderationMessage }}
        </div>
        <div class="mh-modal-package__buttons">
          <v-btn class="mh-modal-package__close" color="primary" depressed @click.stop="onModerationClose">{{ translations.ok }}</v-btn>
        </div>
      </div>
    </v-dialog>
  </v-card>
</template>

<script>
  import PropertyField from './form/PropertyField'

  export default {
    name         : "edit-property",
    data() {
      return {
        showProgress     : true,
        inProgress       : false,
        disableSubmit    : false,
        showPropertySaved: false,
        showModeration   : false,
        loadingApprove   : false,
        loadingDiscard   : false,
      }
    },
    $_veeValidate: {
      validator: 'new'
    },
    components   : {PropertyField},
    computed     : {
      user() {
        return this.$store.state.user;
      },
      showModerationButtons() {
        return (this.user.roles.indexOf('super_agent') !== -1 || this.user.roles.indexOf('administrator') !== -1)
          && typeof this.$store.state.draftProperty.status !== 'undefined' && this.$store.state.draftProperty.status === 'pending';
      },
      steps() {
        return this.$store.state.steps;
      },
      translations() {
        return this.$store.state.translations;
      }
    },
    methods      : {
      onApprove() {
        this.loadingApprove = true;
        let data = {
          action     : 'myhome_user_panel_approve',
          property_id: this.$store.state.draftProperty.id,
          _wpnonce   : this.$store.state.nonce
        };
        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then(() => {
          jQuery.each(this.user.properties, (index, item) => {
            if (item.ID === this.$store.state.draftProperty.id) {
              this.$set(this.user.properties[index], 'status', this.translations.publish);
              this.$nextTick(() => {
                this.$router.push('/dashboard/moderation');
              });
              return false;
            }
          });
          this.$nextTick(() => {
            this.loadingApprove = false;
          });
        }, () => {
        });
      },
      onDiscard() {
        this.loadingDiscard = true;
        let data = {
          action     : 'myhome_user_panel_discard',
          property_id: this.$store.state.draftProperty.id,
          _wpnonce   : this.$store.state.nonce
        };
        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then(() => {
          jQuery.each(this.user.properties, (index, item) => {
            if (item.ID === this.$store.state.draftProperty.id) {
              this.$set(this.user.properties[index], 'status', this.translations.draft);
              this.$nextTick(() => {
                this.$router.push('/dashboard/moderation');
              });
              return false;
            }
          });
          this.$nextTick(() => {
            this.loadingDiscard = false;
          });
        }, () => {
        });
      },
      onSaveConfirm() {
        this.showPropertySaved = false;
        this.$router.push('/dashboard/properties');
      },
      onSave() {
        this.$validator.validateAll('property').then((result) => {
          if (result) {
            this.inProgress = true;
            this.disableSubmit = true;
            this.save();
          } else {
            jQuery('html, body').animate({
              scrollTop: jQuery("[aria-invalid=true]").offset().top - 100
            }, 500);
          }
        });
      },
      save() {
        let data = {
          action  : 'myhome_user_panel_save_draft',
          draft   : this.$store.state.draftProperty,
          _wpnonce: this.$store.state.nonce
        };

        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {
          if (response.body.success) {
            this.onSuccess(response.body);
          } else {
            this.onError(response.body);
          }
        }, (response) => {
          this.onError(response.body);
        });
      },
      onSuccess(response) {
        this.inProgress = false;
        this.$set(this.$store.state, 'draftProperty', {});

        if (response.pending) {
          this.moderationMessage = response.message;
          this.showModeration = true;
        } else {
          this.showPropertySaved = true;
        }
        this.$set(this.$store.state, 'user', response.user);
      },
      onModerationClose() {
        this.showModeration = false;
        this.$nextTick(() => {
          this.moderationMessage = '';
          this.$router.push('/dashboard/properties');
        });
      },
      onError() {
        this.inProgress = false;
        this.disableSubmit = false;
      },
    },
    mounted() {
      let data = {
        action    : 'myhome_user_panel_edit_property_form',
        _wpnonce  : this.$store.state.nonce,
        propertyID: this.$route.params.id
      };
      this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {
        let data = response.body;
        if (data.success === true) {
          this.$set(this.$store.state, 'draftProperty', data.property);
          this.$nextTick(() => {
            jQuery(window).trigger('mhPropertyFormReady');
          });
        }

        this.showProgress = false;
      });
    }
  }
</script>
