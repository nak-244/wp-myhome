<template>
  <div class="mh-field-description">

    <v-text-field
      v-model.lazy="description"
      :label="field.name"
      :multi-line="true"
      :required="field.required"
      :hint="field.instructions"
      :data-vv-scope="formScope"
      v-validate="rules"
      :error-messages="errors.collect(fieldID)"
      :data-vv-name="fieldID"
      :data-vv-as="field.name"
      persistent-hint
      clearable
    ></v-text-field>
  </div>
</template>

<script>
  export default {
    inject  : ['$validator'],
    name    : "description-property-field",
    data() {
      return {
        description: ''
      }
    },
    computed: {
      fieldID() {
        return 'mh-unique-field-description';
      },
      translations() {
          return this.$store.state.translations;
      },
      rules() {
        return this.field.required ? 'required' : '';
      }
    },
    props   : {
      field    : Object,
      formScope: String
    },
    created() {
      if (typeof this.$store.state.draftProperty.description !== 'undefined') {
        this.$set(this, 'description', this.$store.state.draftProperty.description);
      }
    },
    watch   : {
      description() {
        this.$set(this.$store.state.draftProperty, 'description', this.description);
      }
    }
  }
</script>
