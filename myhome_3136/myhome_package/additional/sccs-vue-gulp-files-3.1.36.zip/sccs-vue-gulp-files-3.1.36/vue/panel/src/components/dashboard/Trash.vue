<template>
  <v-card id="mh-trash" class="mh-page-properties">
    <div class="mh-2-col-title">
      <div class="mh-2-col-title__col">
        <h1>{{ translations.trash }}</h1>
      </div>
      <div class="mh-2-col-title__col">
        <v-text-field
          append-icon="search"
          :label="translations.search"
          single-line
          hide-details
          v-model="search"
        ></v-text-field>
      </div>
    </div>

    <div v-if="showProgress">
      <v-progress-linear :indeterminate="true"></v-progress-linear>
    </div>

    <v-data-table
      v-if="!showProgress"
      light
      :headers="headers"
      :items="properties"
      :no-data-text="translations.properties_no_data"
      :no-results-text="translations.properties_no_results"
      :rows-per-page-text="translations.properties_per_page"
      :rows-per-page-items="rowsPerPageItems"
      :search="search"
      class="mh-table-my-properties"
      :disable-initial-sort="true"
      :loading="loading"
      @update:pagination="onPaginationUpdate"
    >
      <template slot="items" slot-scope="props">
        <td class="mh-table-my-properties__td-id">{{ props.item.ID }}</td>
        <td class="mh-table-my-properties__td-image">
          <a v-if="props.item.image !== ''" :href="props.item.link" target="_blank" class="mh-table-my-properties__image">
            <img :src="props.item.image" alt="">
          </a>
        </td>
        <td class="mh-table-my-properties__td-name">
          <a :href="props.item.link" target="_blank" v-if="!props.item.name">{{ translations.draft }}</a>
          <a :href="props.item.link" target="_blank" v-if="props.item.name">{{ props.item.name }}</a>
        </td>
        <td class="mh-table-my-properties__td-created">{{ props.item.createdAt }}</td>
        <td class="mh-table-my-properties__td-restore-delete">
          <span class="mh-table-my-properties__td-mod-buttons__button mh-table-my-properties__td-mod-buttons__restore" @click="onRestore(props.item.ID)"><i class="material-icons">settings_backup_restore</i>{{ translations.restore }}</span>
          <span class="mh-table-my-properties__td-mod-buttons__button mh-table-my-properties__td-mod-buttons__delete" @click="onDeleteItem(props.item)"><i class="material-icons">delete_forever</i>{{ translations.delete }}</span>
        </td>
      </template>
      <template slot="pageText" slot-scope="props">
        {{ props.pageStart }} - {{ props.pageStop }} / {{ props.itemsLength }}
      </template>
    </v-data-table>

    <v-dialog v-model="showDeletePropertyDialog">
      <v-card class="mh-modal-delete-property-dialog">
        <v-card-title>
          <div>{{ translations.sure_remove }}</div>
          <div><strong><span>"</span>{{ this.deleteProperty.name }}<span>"</span></strong></div>
        </v-card-title>
        <v-btn depressed @click="showDeletePropertyDialog = false">{{ translations.cancel }}</v-btn>
        <v-btn
          color="primary"
          depressed
          @click="deleteItem">{{ translations.remove }}
        </v-btn>
      </v-card>
    </v-dialog>
  </v-card>
</template>

<script>
  export default {
    name    : "trash",
    data() {
      return {
        initiated               : false,
        search                  : '',
        showDeletePropertyDialog: false,
        deleteProperty          : false,
        items                   : [],
        showProgress            : true,
        loading                 : true,
      }
    },
    computed: {
      user() {
        return this.$store.state.user;
      },
      translations() {
        return this.$store.state.translations;
      },
      headers() {
        let items = [
          {text: this.translations.id, value: 'ID', class: 'mh-table-my-properties__id'},
          {text: this.translations.image, value: 'Image', sortable: false, class: 'mh-table-my-properties__image'},
          {text: this.translations.name, value: 'name', class: 'mh-table-my-properties__name'},
        ];

        items.push(
          {text: this.translations.created, value: 'createdAtValue', class: 'mh-table-my-properties__created'},
          {text: this.translations.actions, value: false, sortable: false, class: ''},
        );

        return items;
      },
      properties() {
        let items = [];
        for (let i = 0; i < this.items.length; i++) {
          items.push({
            ID            : this.items[i].ID,
            name          : this.items[i].name,
            link          : this.items[i].link,
            createdAt     : this.items[i].created_at_string,
            createdAtValue: this.items[i].created_at_value,
            image         : this.items[i].image
          });
        }
        return items;
      },
      rowsPerPageItems() {
        return [10, 25, 50, {text: this.translations.all, value: -1}];
      }
    },
    methods : {
      onPaginationUpdate() {
        if (this.initiated) {
          let viewportTop = jQuery(window).scrollTop();
          let viewportBottom = viewportTop + jQuery(window).height();
          let elementTop = jQuery('#mh-trash').offset().top;

          if (!(elementTop >= viewportTop && elementTop <= viewportBottom)) {
            jQuery(window).scrollTop(elementTop);
          }
        }
      },
      onEditItem(item) {
        this.$router.push('/dashboard/properties/' + item.ID);
      },
      onDeleteItem(item) {
        this.deleteProperty = item;
        this.showDeletePropertyDialog = true;
      },
      deleteItem() {
        this.showDeletePropertyDialog = false;
        this.loading = true;

        let data = {
          action    : 'myhome_user_panel_delete_property',
          propertyID: this.deleteProperty.ID,
          _wpnonce  : this.$store.state.nonce
        };
        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then(() => {
          jQuery.each(this.items, (index, property) => {
            if (property.ID === this.deleteProperty.ID) {
              this.items.splice(index, 1);
              return false;
            }
          });
          this.$nextTick(() => {
            this.loading = false;
          })
        }, () => {
          this.loading = false;
        });
      },
      onRestore(id) {
        this.loading = true;
        let data = {
          action     : 'myhome_user_panel_restore',
          property_id: id,
          _wpnonce   : this.$store.state.nonce
        };
        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then(() => {
          jQuery.each(this.items, (index, item) => {
            if (item.ID === id) {
              this.items[index].status = this.translations.draft;
              this.user.properties.unshift(this.items[index]);
              this.items.splice(index, 1);
              return false;
            }
          });
          this.$nextTick(() => {
            this.loading = false;
          });
        }, () => {
        });
      },
      prepareProperties() {
        let data = {
          action  : 'myhome_user_panel_trash',
          _wpnonce: this.$store.state.nonce
        };
        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {
          this.items = response.body;
          this.$nextTick(() => {
            this.loading = false;
            this.showProgress = false;
          });
        }, (response) => {

        });
      }
    },
    created() {
      this.prepareProperties();
    },
    mounted() {
      this.initiated = true;
    }
  }
</script>
