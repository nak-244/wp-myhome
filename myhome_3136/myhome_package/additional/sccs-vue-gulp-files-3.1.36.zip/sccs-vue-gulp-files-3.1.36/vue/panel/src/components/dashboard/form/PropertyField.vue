<template>
  <div v-show="showPropertyField" :class="gridClass">

    <title-property-field
      v-if="field.type === 'title'"
      :field="field"
      :form-scope="formScope"
    >
    </title-property-field>

    <video-property-field
      v-if="field.type === 'video'"
      :field="field"
      :form-scope="formScope"
    >
    </video-property-field>

    <virtual-tour-property-field
      v-if="field.type === 'virtual_tour'"
      :field="field"
      :form-scope="formScope"
    >
    </virtual-tour-property-field>

    <text-property-field
      v-if="field.type === 'text'"
      @showField="changeShow(arguments[0])"
      :field="field"
      :form-scope="formScope"
    >
    </text-property-field>

    <number-property-field
      v-if="field.type === 'number'"
      @showField="changeShow(arguments[0])"
      :field="field"
      :form-scope="formScope"
    >
    </number-property-field>

    <description-property-field
      v-if="field.type === 'description'"
      :field="field"
      :form-scope="formScope"
    >
    </description-property-field>

    <image-property-field
      v-if="field.type === 'image'"
      :field="field"
      :form-scope="formScope"
    >
    </image-property-field>

    <gallery-property-field
      v-if="field.type === 'gallery'"
      :field="field"
      :form-scope="formScope"
    >
    </gallery-property-field>

    <location-property-field
      v-if="field.type === 'location'"
      :field="field"
      :form-scope="formScope"
    >
    </location-property-field>

    <attachment-property-field
      v-if="field.type === 'attachments'"
      :field="field"
      :form-scope="formScope"
    >
    </attachment-property-field>

    <plan-property-field
      v-if="field.type === 'plans'"
      :field="field"
      :form-scope="formScope"
    >
    </plan-property-field>

    <additional-features-property-field
      v-if="field.type === 'additional_features'"
      :field="field"
      :form-scope="formScope"
    >
    </additional-features-property-field>

    <featured-property-field
      v-if="field.type === 'featured'"
      @showField="changeShow(arguments[0])"
      :field="field"
      :form-scope="formScope"
    >
    </featured-property-field>

  </div>
</template>

<script>
  import TitlePropertyField from './TitlePropertyField'
  import TextPropertyField from './TextPropertyField'
  import NumberPropertyField from './NumberPropertyField'
  import DescriptionPropertyField from './DescriptionPropertyField'
  import ImagePropertyField from './ImagePropertyField'
  import GalleryPropertyField from './GalleryPropertyField'
  import LocationPropertyField from './LocationPropertyField'
  import AttachmentPropertyField from './AttachmentPropertyField'
  import PlanPropertyField from './PlanPropertyField'
  import AdditionalFeaturesPropertyField from './AdditionalFeaturesPropertyField'
  import VideoPropertyField from './VideoPropertyField'
  import VirtualTourPropertyField from './VirtualTourPropertyField'
  import FeaturedPropertyField from './FeaturedPropertyField'

  export default {
    name      : "property-field",
    data() {
      return {
        showPropertyField: true
      }
    },
    components: {
      TitlePropertyField,
      TextPropertyField,
      NumberPropertyField,
      DescriptionPropertyField,
      ImagePropertyField,
      GalleryPropertyField,
      LocationPropertyField,
      AttachmentPropertyField,
      PlanPropertyField,
      AdditionalFeaturesPropertyField,
      VideoPropertyField,
      VirtualTourPropertyField,
      FeaturedPropertyField
    },
    props     : {
      field    : Object,
      creating : Boolean,
      formScope: String
    },
    computed  : {
      gridClass() {
        if (this.field.width === '1') {
          return 'mh-field mh-field--1of1';
        } else if (this.field.width === '2') {
          return 'mh-field mh-field--1of2';
        } else if (this.field.width === '3') {
          return 'mh-field mh-field--1of3';
        }
      }
    },
    methods   : {
      changeShow(show) {
        this.showPropertyField = show;
      }
    }
  }
</script>
