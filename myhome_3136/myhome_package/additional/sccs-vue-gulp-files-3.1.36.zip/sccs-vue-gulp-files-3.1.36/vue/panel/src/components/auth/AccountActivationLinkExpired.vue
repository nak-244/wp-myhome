<template>
  <v-container grid-list-xl text-xs-center>
    <v-layout row wrap>
      <v-flex xs4 offset-xs4>
        <v-card>
          <v-card-title>
            <span class="headline">{{ translations.account_activation_link_expired }}</span>
          </v-card-title>

          <v-card-text>
            <v-alert type="error" :value="true">
              {{ translations.account_activation_link_expired_text }}
            </v-alert>
          </v-card-text>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn @click="onBack" flat>{{ translations.back_to_login }}</v-btn>
            <v-btn color="primary" @click="onShowForm" depressed>
              {{ translations.account_send_activation_again }}
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-flex>

      <v-dialog v-model="showForm" max-width="500px">
        <form @submit.prevent="onSendActivationLink">
          <v-card>
            <v-card-title>
              <span class="headline">{{ translations.account_send_activation_link }}</span>
            </v-card-title>

            <v-card-media v-if="loading">
              <v-progress-linear
                :indeterminate="true"
              >
              </v-progress-linear>
            </v-card-media>

            <v-card-text>
              <v-text-field
                v-model="email"
                :label="translations.enter_your_email"
                :error-messages="errors.collect(translations.email)"
                v-validate="'required|email'"
                :data-vv-name="translations.email"
                required
              >
              </v-text-field>
            </v-card-text>

            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn @click="onCancel" flat>{{ translations.cancel }}</v-btn>
              <v-btn color="primary" @click="onSendActivationLink" depressed>
                {{ translations.send }}
              </v-btn>
            </v-card-actions>

          </v-card>
        </form>
      </v-dialog>
    </v-layout>
  </v-container>

</template>

<script>
  export default {
    name    : "account-activation-link-expired",
    data() {
      return {
        showForm: false,
        loading : false,
        email   : ''
      }
    },
    computed: {
      translations() {
        return this.$store.state.translations;
      }
    },
    methods : {
      onBack() {
        this.$router.push('/');
      },
      onShowForm() {
        this.showForm = true;
      },
      onSendActivationLink() {
        this.$validator.validateAll().then((result) => {
          if (result) {
            this.sendActivationLink();
          }
        });
      },
      sendActivationLink() {
        this.loading = true;
        let data = {
          action  : 'myhome_user_send_activation_link',
          email   : this.email,
          _wpnonce: this.$store.state.nonce
        };
        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {
          this.loading = false;
          if (response.body.success === true) {
            this.onSendActivationLinkSuccess(response.body);
          } else {
            this.onSendActivationLinkError(response.body);
          }
          this.resetPasswordDialog = false;
        }, (response) => {
          this.loading = false;
          this.onSendActivationLinkError(response.body);
          this.resetPasswordDialog = false;
        });
      },
      onSendActivationLinkSuccess(response) {
        this.$store.state.messages.splice(0, this.$store.state.messages.length);
        this.$store.state.messages.push({
          type: 'success',
          text: response.message
        });
        this.$router.push('/');
      },
      onSendActivationLinkError(response) {
        this.$store.state.messages.splice(0, this.$store.state.messages.length);
        this.$store.state.messages.push({
          type: 'error',
          text: response.message
        });
        this.$router.push('/');
      },
      onCancel() {
        this.showForm = false;
      }
    }
  }
</script>
