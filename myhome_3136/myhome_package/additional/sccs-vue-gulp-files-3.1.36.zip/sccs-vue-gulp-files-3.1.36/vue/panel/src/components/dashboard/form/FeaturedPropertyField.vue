<template>
  <div class="mh-field-featured-checkbox">
    <v-checkbox
      :label="field.name"
      v-model="value"
      color="primary"
    ></v-checkbox>
  </div>
</template>

<script>
  export default {
    name : "FeaturedPropertyField",
    data() {
      return {
        value: false
      }
    },
    props: {
      field    : Object,
      formScope: String,
    },
    created() {
      if (typeof this.$store.state.draftProperty.is_featured !== 'undefined') {
        this.value = this.$store.state.draftProperty.is_featured;
      }
    },
    computed: {
        translations() {
            return this.$store.state.translations;
        }
    },
    mounted() {
      if (this.$store.state.draftProperty.is_paid) {
        this.$emit('showField', false);
      }
    },
    watch: {
      value() {
        this.$set(this.$store.state.draftProperty, 'is_featured', this.value);
      }
    }
  }
</script>
