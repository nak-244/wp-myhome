<template>
  <v-card id="mh-properties" class="mh-page-properties">
    <div class="mh-2-col-title">
      <div class="mh-2-col-title__col">
        <h1>{{ translations.my_properties }}</h1>
      </div>
      <div class="mh-2-col-title__col">
        <v-text-field
          append-icon="search"
          :label="translations.search"
          single-line
          hide-details
          v-model="search"
        ></v-text-field>
      </div>
    </div>

    <v-data-table
      light
      :headers="headers"
      :items="properties"
      :no-data-text="translations.properties_no_data"
      :no-results-text="translations.properties_no_results"
      :rows-per-page-text="translations.properties_per_page"
      :rows-per-page-items="rowsPerPageItems"
      :search="search"
      class="mh-table-my-properties"
      :disable-initial-sort="true"
      @update:pagination="onPaginationUpdate"
    >
      <template slot="items" slot-scope="props">
        <td class="mh-table-my-properties__td-id">{{ props.item.ID }}</td>
        <td class="mh-table-my-properties__td-image">
          <a v-if="props.item.image !== ''" :href="props.item.link" target="_blank" class="mh-table-my-properties__image">
            <img :src="props.item.image" alt="">
          </a>
        </td>
        <td class="mh-table-my-properties__td-name">
          <a :href="props.item.link" target="_blank" v-if="!props.item.name">{{ translations.draft }}</a>
          <a :href="props.item.link" target="_blank" v-if="props.item.name">{{ props.item.name }}</a>
        </td>
        <td class="mh-table-my-properties__td-status">{{ props.item.status }}</td>
        <td class="mh-table-my-properties__td-expire" v-if="showExpire">{{ props.item.expire }}</td>
        <td class="mh-table-my-properties__td-created">{{ props.item.createdAt }}</td>
        <td class="mh-table-my-properties__td-action">
          <v-icon @click="onEditItem(props.item)">edit</v-icon>
          <v-icon @click="onDeleteItem(props.item)">delete</v-icon>
        </td>
      </template>
      <template slot="pageText" slot-scope="props">
        {{ props.pageStart }} - {{ props.pageStop }} / {{ props.itemsLength }}
      </template>
    </v-data-table>

    <v-dialog v-model="showDeletePropertyDialog">
      <v-card class="mh-modal-delete-property-dialog">
        <v-card-title>
          <div>{{ translations.sure_remove }}</div>
          <div><strong><span>"</span>{{ this.deleteProperty.name }}<span>"</span></strong></div>
        </v-card-title>
        <v-btn depressed @click="showDeletePropertyDialog = false">{{ translations.cancel }}</v-btn>
        <v-btn
                color="primary"
                depressed
                @click="deleteItem">{{ translations.remove }}</v-btn>
      </v-card>
    </v-dialog>
  </v-card>
</template>

<script>
  export default {
    name    : "properties",
    data() {
      return {
        initiated               : false,
        search                  : '',
        showDeletePropertyDialog: false,
        deleteProperty          : false
      }
    },
    computed: {
      translations() {
          return this.$store.state.translations;
      },
      showExpire() {
        return window.MyHomePanel.expire === '1';
      },
      headers() {
        let items = [
          {text: this.translations.id, value: 'ID', class: 'mh-table-my-properties__id'},
          {text: this.translations.image, value: 'Image', sortable: false, class: 'mh-table-my-properties__image'},
          {text: this.translations.name, value: 'name', class: 'mh-table-my-properties__name'},
          {text: this.translations.status, value: 'status', class: 'mh-table-my-properties__status'}
        ];

        if (this.showExpire) {
          items.push({
            text : this.translations.expire,
            value: 'expire',
            class: 'mh-table-my-properties__expire'
          });
        }

        items.push(
          {text: this.translations.created, value: 'createdAtValue', class: 'mh-table-my-properties__created'},
          {text: this.translations.actions, value: false, sortable: false, class: 'mh-table-my-properties__actions'},
        );

        return items;
      },
      user() {
        return this.$store.state.user;
      },
      properties() {
        let items = [];
        for (let i = 0; i < this.user.properties.length; i++) {
          items.push({
            ID            : this.user.properties[i].ID,
            name          : this.user.properties[i].name,
            link          : this.user.properties[i].link,
            status        : this.user.properties[i].status,
            expire        : this.user.properties[i].expire,
            createdAt     : this.user.properties[i].created_at_string,
            createdAtValue: this.user.properties[i].created_at_value,
            image         : this.user.properties[i].image
          });
        }
        return items;
      },
      rowsPerPageItems() {
        return [10, 25, 50, {text: this.translations.all, value: -1}];
      }
    },
    methods : {
      onPaginationUpdate() {
        if (this.initiated) {
          let viewportTop = jQuery(window).scrollTop();
          let viewportBottom = viewportTop + jQuery(window).height();
          let elementTop = jQuery('#mh-properties').offset().top;

          if (!(elementTop >= viewportTop && elementTop <= viewportBottom)) {
            jQuery(window).scrollTop(elementTop);
          }
        }
      },
      onAddProperty() {
        this.$router.push('/submit-property');
      },
      onEditItem(item) {
        this.$router.push('/dashboard/properties/' + item.ID);
      },
      onDeleteItem(item) {
        this.deleteProperty = item;
        this.showDeletePropertyDialog = true;
      },
      deleteItem() {
        this.showDeletePropertyDialog = false;
        jQuery.each(this.$store.state.user.properties, (index, property) => {
          if (property.ID === this.deleteProperty.ID) {
            this.$store.state.user.properties.splice(index, 1);
            return false;
          }
        });

        let data = {
          action    : 'myhome_user_panel_delete_property',
          propertyID: this.deleteProperty.ID,
          _wpnonce  : this.$store.state.nonce
        };
        this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then((response) => {

        }, (response) => {

        });
      }
    },
    mounted() {
      this.initiated = true;
    }
  }
</script>
