<template>

    <div class="mh-panel-app-spacing">
        <div class="mh-login-register-panel">
            <div class="mh-login-register-panel__inner">
                <div class="mh-login-register-panel__heading">
                    <div>
                        <h3>
                            {{ translations.register }}
                        </h3>
                    </div>
                </div>

                <form @submit.prevent="onRegister" autocomplete="off">

                    <v-alert v-for="message in messages" v-html="message.text" :value="true"
                             :type="message.type"></v-alert>

                    <v-alert v-if="errorMessage !== ''" type="error" :value="true" v-html="errorMessage"></v-alert>

                    <v-text-field
                            v-model="user.login"
                            :label="translations.login"
                            :error-messages="errors.collect(translations.login)"
                            v-validate="'required|min:3'"
                            prepend-icon="perm_identity"
                            :data-vv-name="translations.login"
                            autocomplete="off"
                            required
                    >
                    </v-text-field>

                    <v-text-field
                            v-model="user.email"
                            :label="translations.email"
                            :error-messages="errors.collect(translations.email)"
                            v-validate="'required|email'"
                            :data-vv-name="translations.email"
                            prepend-icon="mail_outline"
                            autocomplete="off"
                            required
                    >
                    </v-text-field>

                    <v-text-field
                            v-model="user.password"
                            :label="translations.enter_password"
                            :error-messages="errors.collect('password')"
                            :append-icon="visiblePassword ? 'visibility' : 'visibility_off'"
                            :append-icon-cb="() => (visiblePassword = !visiblePassword)"
                            :type="visiblePassword ? 'text' : 'password'"
                            data-vv-name="password"
                            name="password"
                            prepend-icon="lock_outline"
                            :data-vv-as="translations.password"
                            v-validate="'required|min:3'"
                            autocomplete="off"
                            required
                    >
                    </v-text-field>

                    <v-text-field
                            v-model="user.password2"
                            :label="translations.enter_password_repeat"
                            :error-messages="errors.collect('password_confirm')"
                            :append-icon="visiblePassword ? 'visibility' : 'visibility_off'"
                            :append-icon-cb="() => (visiblePassword = !visiblePassword)"
                            :type="visiblePassword ? 'text' : 'password'"
                            data-vv-name="password_confirm"
                            prepend-icon="lock_outline"
                            :data-vv-as="translations.password"
                            v-validate="'required|min:3|confirmed:password'"
                            autocomplete="off"
                            required
                    >
                    </v-text-field>

                    <v-text-field
                            v-for="field in userFields"
                            v-model="user[field.slug]"
                            :label="field.name"
                            type="text"
                            single-line
                    >
                    </v-text-field>

                    <v-select
                            v-if="showAccountTypes"
                            v-model="user.account_type"
                            :items="accountTypes"
                            item-text="name"
                            item-value="value"
                            prepend-icon="supervisor_account"
                            single-line
                    >
                    </v-select>

                    <div class="mh-register-terms" v-if="showRules">
                        <div class="mh-register-terms__box">
                            <v-checkbox v-model="acceptRules" color="primary"></v-checkbox>
                        </div>
                        <div class="mh-register-terms__text">
                            <span>{{ translations.accept }}</span>
                            <a :href="rulesLink" target="_blank">{{ translations.terms_of_service }}</a>
                        </div>
                    </div>

                    <div v-if="isCaptchaEnabled" class="mh-register-captcha">
                        <div id="mh-register-captcha"></div>
                    </div>

                    <div class="mh-panel-register-buttons">
                        <div class="mh-panel-register-buttons__back">
                            <v-btn @click="onCancel" flat>
                                {{ translations.login }}
                            </v-btn>
                        </div>
                        <div class="mh-panel-register-buttons__register">
                            <v-btn
                                    type="submit"
                                    color="primary"
                                    :loading="loading"
                                    :disabled="isRegisterDisabled"
                                    depressed
                            >
                                {{ translations.register }}
                            </v-btn>
                        </div>
                    </div>

                </form>

                <div class="mh-panel-login-social-buttons" v-if="socialLogin.length">
                    <h3 class="mh-panel-social-buttons-heading">{{ translations.connect_with }}</h3>
                    <div class="mh-panel-login-social-buttons__all-buttons">
                        <div v-for="network in socialLogin">
                            <v-btn :data-name="network.key"
                                   depressed @click="onSocialLogin(network.login_link)">
                                {{ network.name }}
                            </v-btn>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

</template>

<script>
    export default {
        name: "register",
        data() {
            return {
                acceptRules: false,
                visiblePassword: false,
                user: {
                    login: '',
                    email: '',
                    password: '',
                    password2: '',
                    account_type: ''
                },
                loading: false,
                errorMessage: '',
                socialLogin: [],
                captchaChecked: false
            }
        },
        $_veeValidate: {
            validator: 'new'
        },
        computed: {
            userFields() {
                return window.MyHome.user_fields
            },
            isRegisterDisabled() {
                if (this.showRules && !this.acceptRules) {
                    return true;
                }

                if (this.isCaptchaEnabled && !this.captchaChecked) {
                    return true;
                }

                return false;
            },
            messages() {
                return this.$store.state.messages;
            },
            translations() {
                return this.$store.state.translations;
            },
            isCaptchaEnabled() {
                return this.$store.state.captchaEnabled;
            },
            showAccountTypes() {
                return window.MyHomePanel.user_select_type;
            },
            accountTypes() {
                let types = [];

                jQuery.each(window.MyHomePanel.account_types, (value, name) => {
                    types.push({name: name, value: value});
                });

                return types;
            },
            showRules() {
                return window.MyHomePanel.show_rules
            },
            rulesLink() {
                return window.MyHomePanel.rules_link
            }
        },
        methods: {
            onSocialLogin(loginLink) {
                window.location.href = loginLink;
            },
            onRegister() {
                if (this.isRegisterDisabled) {
                    return;
                }

                this.errorMessage = '';
                this.$validator.validateAll().then((result) => {
                    if (result) {
                        this.register();
                    }
                });
            },
            register() {
                this.loading = true;
                let data = {
                    action: 'myhome_user_panel_register',
                    user: this.user,
                    _wpnonce: this.$store.state.nonce
                };

                if (this.isCaptchaEnabled) {
                    data['captcha'] = grecaptcha.getResponse(this.$store.state.captchaId);
                }

                this.$http.post(this.$store.state.requestUrl, data, {emulateJSON: true}).then(response => {
                    this.loading = false;
                    if (this.isCaptchaEnabled) {
                        grecaptcha.reset();
                    }

                    if (response.body.success) {
                        this.onSuccess(response.body);
                    } else {
                        this.onError(response.body);
                    }
                }, response => {
                    this.onError(response.body);
                })
            },
            onCancel() {
                this.$store.state.messages.splice(0, this.$store.state.messages.length);
                this.$router.push('/');
            },
            onSuccess(response) {
                let text;
                if (response.activate_link) {
                    text = this.translations.registered_text_activate;
                    this.$store.state.messages.splice(0, this.$store.state.messages.length);
                    this.$store.state.messages.push({
                        type: 'success',
                        text: text
                    });
                    this.$router.push('/');
                } else {
                    window.location.reload();
                }
            },
            onError(response) {
                if (this.isCaptchaEnabled) {
                    grecaptcha.reset();
                }

                if (typeof response.message !== 'undefined' && response.message !== '') {
                    this.errorMessage = response.message;
                }
            },
            initiateCaptcha() {
                let timer = setInterval(() => {
                    if (grecaptcha && typeof grecaptcha !== 'undefined' && typeof document.getElementById('mh-login-captcha') !== 'undefined') {
                        clearInterval(timer);
                        this.captchaChecked = false;
                        this.$nextTick(() => {
                            this.$store.state.captchaId = grecaptcha.render(document.getElementById('mh-register-captcha'), {
                                'sitekey': this.$store.state.captchaKey,
                                'callback': () => {
                                    this.captchaChecked = true;
                                },
                                'expired-callback': () => {
                                    this.captchaChecked = false;
                                }
                            });
                        })
                    }
                }, 100);
            }
        },
        created() {
            if (typeof window.MyHomePanel.account_type !== 'undefined' && window.MyHomePanel.account_type !== '') {
                this.$set(this.user, 'account_type', window.MyHomePanel.account_type);
            }

            if (typeof window.MyHome.social_login !== 'undefined') {
                this.socialLogin = window.MyHome.social_login;
            }
        },
        mounted() {
            if (this.isCaptchaEnabled) {
                this.initiateCaptcha();
            }
        }
    }
</script>
