<template>
  <div class="mh-field-title">
    <v-text-field
      :label="field.name"
      v-model.lazy="name"
      :required="field.required"
      :hint="field.instructions"
      :data-vv-scope="formScope"
      v-validate="rules"
      :error-messages="errors.collect(fieldID)"
      :data-vv-name="fieldID"
      :data-vv-as="field.name"
      persistent-hint
      clearable
    >
    </v-text-field>
  </div>
</template>

<script>
  export default {
    inject  : ['$validator'],
    name    : "title-property-field",
    data() {
      return {
        name: ''
      }
    },
    computed: {
      fieldID() {
        return 'mh-unique-field-title';
      },
      rules() {
        return this.field.required ? 'required' : '';
      }
    },
    props   : {
      field    : Object,
      formScope: String
    },
    created() {
      if (this.$store.state.draftProperty.title !== 'undefined') {
        this.name = this.$store.state.draftProperty.title;
      }
    },
    watch   : {
      name() {
        this.$set(this.$store.state.draftProperty, 'title', this.name);
      }
    }
  }
</script>
