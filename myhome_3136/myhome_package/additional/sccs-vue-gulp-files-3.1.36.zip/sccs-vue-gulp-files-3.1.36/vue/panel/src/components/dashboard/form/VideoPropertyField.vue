<template>
  <div class="mh-field-video">
    <h3>{{ translations.video }}</h3>
    <div class="mh-field__instruction" v-if="field.instructions !== ''">{{ field.instructions }}</div>

    <v-text-field
      :label="field.name"
      v-model.lazy="value"
      :required="field.required"
      :data-vv-scope="formScope"
      v-validate="rules"
      prepend-icon="videocam"
      :error-messages="errors.collect(fieldID)"
      :data-vv-name="fieldID"
      :data-vv-as="field.name"
      persistent-hint
      clearable
    >
    </v-text-field>
  </div>
</template>

<script>
  export default {
    inject  : ['$validator'],
    name    : "video-property-field",
    data() {
      return {
        value: ''
      }
    },
    computed: {
      fieldID() {
        return 'mh-unique-field-video';
      },
      translations() {
          return this.$store.state.translations;
      },
      rules() {
        return this.field.required ? 'required' : '';
      }
    },
    props   : {
      field    : Object,
      formScope: String
    },
    created() {
      if (typeof this.$store.state.draftProperty.video !== 'undefined') {
        this.value = this.$store.state.draftProperty.video;
      }
    },
    watch   : {
      value() {
        this.$set(this.$store.state.draftProperty, 'video', this.value);
      }
    }
  }
</script>
