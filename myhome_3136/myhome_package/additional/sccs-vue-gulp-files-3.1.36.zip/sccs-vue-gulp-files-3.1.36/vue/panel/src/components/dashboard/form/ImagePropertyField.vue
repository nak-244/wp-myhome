<template>
  <div class="mh-field-featured-image">
    <h3>{{ translations.featured_image }}<span v-if="field.required">*</span></h3>
    <div class="mh-field__instruction" v-if="field.instructions !== ''">{{ field.instructions }}</div>
    <div class="mh-field__error" v-if="errors.has('featured_image')">{{ errors.first('featured_image') }}</div>
    <div class="mh-field__error" v-if="errors.has(fieldKey)">{{ errors.first(fieldKey) }}</div>

    <div class="mh-field-featured-image__content">

      <input
        v-if="imageInputReady"
        id="image"
        style="display:none"
        type="file"
        ref="image"
        accept="image/*"
        :multiple="false"
        @change="onBeforeUpload($event)"
        v-validate.reject="rules"
        :data-vv-as="translations.featured_image"
        data-vv-name="featured_image"
      >

      <input
        type="hidden"
        v-model="image"
        name="image"
        v-validate="imageRules"
        data-vv-name="image"
        :data-vv-scope="formScope"
      >
      <div class="mh-field-gallery__single">
        <div>
          <div v-if="!isProcessing && (!image || image === '')" class="mh-panel__upload-gallery__icon-placeholder">
            <i class="fa fa-photo"></i>
          </div>

          <div v-if="isProcessing">
            <div class="mh-field-gallery__progress">
              <div class="mh-field-gallery__progress__inner">
                <div>
                  <v-progress-circular
                    indeterminate
                    :size="48"
                    :width="1"
                    :rotate="-90"
                    color="primary"
                  >
                  </v-progress-circular>
                </div>
              </div>
            </div>
          </div>

          <div v-if="image && image !== ''">
            <img :src="image.url" alt="" class="mh-field-featured-image__image">
          </div>

          <div v-if="image && image !== ''" class="mh-field-gallery__remove">
            <v-btn
              @click="onRemoveImage"
              icon
              ripple
            >
              <v-icon>delete</v-icon>
            </v-btn>
          </div>

        </div>
      </div>

    </div>
    <div class="clearfix"></div>

    <v-btn
      @click="onUpload"
      :disabled="disableButton"
      color="secondary"
      class="mh-field-featured-image__upload"
      depressed
    >
      <v-icon left dark>cloud_upload</v-icon>
      {{ translations.upload_image }}
    </v-btn>
  </div>
</template>

<script>
  export default {
    inject  : ['$validator'],
    name    : "image-property-field",
    data() {
      return {
        imageInputReady: true,
        isProcessing   : false,
        disableButton  : false,
        progress       : 0,
        image          : ''
      }
    },
    props   : {
      field    : Object,
      formScope: String
    },
    computed: {
      fieldKey() {
        return this.formScope + '.image';
      },
      imageRules() {
        if (this.field.required) {
          return 'required';
        } else {
          return '';
        }
      },
      rules() {
        let rules = 'image';
        let maxImageSize = parseInt(window.MyHomePanel.validation['gallery_max-size']) * 1024;
        if (maxImageSize > 0) {
          rules += '|size:' + maxImageSize;
        }

        return rules;
      },
      translations() {
        return this.$store.state.translations;
      }
    },
    methods : {
      onUpload() {
        document.getElementById("image").value = "";
        this.$refs.image.click();
      },
      onRemoveImage() {
        this.image = false;
        this.imageInputReady = false;
        this.$nextTick(() => {
          this.imageInputReady = true;
        });
      },
      onBeforeUpload(e) {
        this.$validator.validate('featured_image').then((result) => {
          if (result) {
            window.MyHomePanelEventBus.$emit('lockButtons', 'image')
            this.uploadFile(e);
          }
        });
      },
      uploadFile(e) {
        let timeout = 0;
        if (this.image) {
          this.image = false;
          this.imageInputReady = false;
          this.$nextTick(() => {
            this.imageInputReady = true;
          });
          timeout = 400;
        }

        setTimeout(() => {
          let files = e.target.files || e.dataTransfer.files;
          if (files.length) {
            this.isProcessing = true;
            this.disableButton = true;
          } else {
            return;
          }

          for (let i = 0; i < files.length; i++) {
            const file = files.item(i);
            let formData = new FormData();
            formData.append('file', file);
            formData.append('action', 'myhome_user_panel_upload_image');
            let xhr = new XMLHttpRequest();

            xhr.upload.addEventListener('progress', (e) => {
              let total = e.total;
              let loaded = e.loaded;
              this.progress = parseInt((100 / total) * loaded);
            }, false);

            xhr.upload.addEventListener('loadend', () => {
              this.$nextTick(() => {
                this.progress = 0;
              });
            });

            xhr.onreadystatechange = () => {
              if (xhr.readyState == XMLHttpRequest.DONE) {
                setTimeout(() => {
                  this.image = JSON.parse(xhr.responseText);
                  this.isProcessing = false;
                  this.disableButton = false;
                  window.MyHomePanelEventBus.$emit('lockButtons', 'image')
                }, 400);
              }
            };

            xhr.open('POST', this.$store.state.requestUrl);
            xhr.send(formData);
          }
        }, timeout);
      }
    },
    created() {
      if (typeof this.$store.state.draftProperty.image !== 'undefined') {
        this.image = this.$store.state.draftProperty.image;
      }
    },
    watch   : {
      image() {
        this.$set(this.$store.state.draftProperty, 'image', this.image);
      }
    }
  }
</script>
