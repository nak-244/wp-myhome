<template>
  <div v-show="!isDisabled" class="mh-field-number-field">
    <v-text-field
      :label="name"
      v-model="value"
      :required="field.required"
      :hint="field.instructions"
      :data-vv-scope="formScope"
      v-validate="rules"
      :error-messages="errors.collect(fieldID)"
      :data-vv-name="fieldID"
      :data-vv-as="field.name"
      persistent-hint
      clearable
    >
    </v-text-field>
  </div>
</template>

<script>
  export default {
    inject  : ['$validator'],
    name    : "number-property-field",
    data() {
      return {
        value: ''
      }
    },
    props   : {
      field    : Object,
      formScope: String
    },
    computed: {
      name() {
        let name = this.field.name;
        //
        // if (this.isPrice && typeof this.field.display_after !== 'undefined' && this.field.display_after !== '') {
        //   name = this.field.display_after + ' ' + name;
        // }

        if (typeof this.field.display_before !== 'undefined' && this.field.display_before !== '') {
          name = this.field.display_before + ' ' + name;
        }

        if (this.field.display_after !== 'undefined' && this.field.display_after !== '') {
          name = name + ' (' + this.field.display_after + ')';
        }

        return name;
      },
      fieldID() {
        return 'mh-field-' + this.field.slug;
      },
      isPrice() {
        return this.field.base_slug === 'price';
      },
      prefix() {
        return this.isPrice ? this.field.display_after : this.field.display_before;
      },
      suffix() {
        return this.isPrice ? '' : this.field.display_after;
      },
      rules() {
        let rules = '';

        if (this.field.required && !this.isDisabled) {
          rules += 'required';
        }

        if (this.isPrice) {
          if (rules !== '') {
            rules += '|'
          }
          rules += 'integer|min_value:0'
        } else if (window.MyHomePanel.validate_number_field) {
          if (rules !== '') {
            rules += '|'
          }
          rules += 'decimal'
        }

        return rules;
      },
      isDisabled() {
        if (this.field.dependencies.all || typeof this.$store.state.draftProperty.propertyTypes === 'undefined'
          || !this.$store.state.draftProperty.propertyTypes.length) {
          return false;
        }

        let disabled = true;
        jQuery.each(this.$store.state.draftProperty.propertyTypes, (index, propertyType) => {
          if (typeof this.field.dependencies[propertyType] !== 'undefined' && this.field.dependencies[propertyType]) {
            disabled = false;
            return false;
          }
        });

        if (disabled) {
          this.value = '';
          this.$emit('showField', false);
        } else {
          this.$emit('showField', true);
        }

        return disabled;
      }
      ,
    },
    created() {
      if (typeof this.$store.state.draftProperty.attributes !== 'undefined'
        && typeof this.$store.state.draftProperty.attributes[this.field.slug] !== 'undefined'
      ) {
        this.value = this.$store.state.draftProperty.attributes[this.field.slug];
      }
    }
    ,
    watch   : {
      value() {
        if (typeof this.$store.state.draftProperty.attributes === 'undefined') {
          this.$store.state.draftProperty.attributes = {};
        }

        this.$store.state.draftProperty.attributes[this.field.slug] = this.value;
      }
    }
  }
</script>
