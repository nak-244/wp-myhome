<template>
  <v-card id="myhome-panel-favorite" class="mh-favorite">
    <div class="mh-2-col-title">
      <div class="mh-2-col-title__col">
        <h1>{{ translations.favorite_properties }}</h1>
      </div>
      <div class="mh-2-col-title__col">
        <v-text-field
          append-icon="search"
          :label="translations.search"
          single-line
          hide-details
          v-model="search"
        ></v-text-field>
      </div>
    </div>

    <div v-if="inProgress">
      <v-progress-linear :indeterminate="true"></v-progress-linear>
    </div>

    <v-data-table
      light
      :headers="headers"
      :items="properties"
      :no-data-text="translations.favorite_no_data"
      :no-results-text="translations.favorite_no_results"
      :rows-per-page-text="translations.favorite_per_page"
      :rows-per-page-items="rowsPerPageItems"
      :search="search"
      class="mh-table-my-favorite"
      @update:pagination="onPaginationUpdate"
    >
      <template slot="items" slot-scope="props">
        <td>
          <a :href="props.item.link" target="_blank" v-if="props.item.name">
            <img
              v-if="props.item.image !== ''"
              :src="props.item.image"
              data-parent-fit="contain"
              data-sizes="auto"
              alt=""
              class="lazyload"
            >
          </a>
        </td>
        <td>
          <a :href="props.item.link" target="_blank" v-if="!props.item.name">{{ translations.draft }}</a>
          <a :href="props.item.link" target="_blank" v-if="props.item.name">{{ props.item.name }}</a>
        </td>
        <td>
          <v-icon @click="remove(props.item.id)">delete</v-icon>
        </td>
      </template>
      <template slot="pageText" slot-scope="props">
        {{ props.pageStart }} - {{ props.pageStop }} / {{ props.itemsLength }}
      </template>
    </v-data-table>

  </v-card>

</template>

<script>
  export default {
    name    : "favorite",
    data() {
      return {
        search    : '',
        initiated : false,
        inProgress: false
      }
    },
    computed: {
      headers() {
        return [
          {
            text    : this.translations.image,
            value   : 'Image',
            sortable: false,
            class   : 'mh-favorite-properties-table__image'
          },
          {
            text : this.translations.name,
            value: 'name',
            class: 'mh-favorite-properties-table__name'
          },
          {
            text    : this.translations.remove,
            value   : false,
            sortable: false,
            class   : 'mh-favorite-properties-table__actions'
          },
        ]
      },
      properties() {
        return this.$store.state.user.favorite;
      },
      translations() {
        return this.$store.state.translations;
      },
      rowsPerPageItems() {
        return [10, 25, 50, {"text": this.translations.all, "value": -1}];
      }
    },
    methods : {
      onPaginationUpdate() {
        if (this.initiated) {
          let viewportTop = jQuery(window).scrollTop();
          let viewportBottom = viewportTop + jQuery(window).height();
          let elementTop = jQuery('#myhome-panel-favorite').offset().top;

          if (!(elementTop >= viewportTop && elementTop <= viewportBottom)) {
            jQuery(window).scrollTop(elementTop);
          }
        }
      },
      remove(propertyID) {
        if (this.inProgress) {
          return false;
        }

        this.inProgress = true;
        let data = {
          propertyID: propertyID,
          isFavorite: false,
          action    : 'myhome_add_to_favorite'
        };
        this.$http.post(window.MyHome.requestUrl, data, {emulateJSON: true}).then(() => {
          jQuery.each(this.properties, (index, property) => {
            if (property.id === propertyID) {
              this.initiated = false;
              this.properties.splice(index, 1);
              this.$nextTick(() => {
                this.initiated = true;
              });
              return false;
            }
          });
          this.inProgress = false;
        }, () => {
          this.inProgress = false;
        });
      }
    },
    mounted() {
      this.initiated = true;
    }
  }
</script>
