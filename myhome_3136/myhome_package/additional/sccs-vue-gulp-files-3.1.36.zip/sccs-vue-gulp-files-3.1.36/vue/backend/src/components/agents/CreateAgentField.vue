<template>
	<div>

		<div class="mh-new-field mh-new-field--agent">
			<form @submit.prevent>

				<div class="mh-new-field__input-wrapper">
					<label for="name">{{ getString('field_name') }}</label>
					<input id="name" type="text" v-model="field.name">
				</div>

				<div class="mh-admin-checkbox">
					<div>
						<input id="is_link" type="checkbox" v-model="field.is_link">
					</div>
					<div>
						<label for="is_required">{{ getString('field_is_link') }}</label>
					</div>
				</div>

				<button
					@click="onCreate"
					class="mdl-button mdl-js-button mdl-button--accent"
				>
					{{ getString('create') }}
				</button>
			</form>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				field: {
					name       : '',
					is_link    : false,
					is_required: false
				}
			}
		},
		methods: {
			getString(key) {
				if (typeof window.MyHomePanelSettings.translations[key] !== 'undefined') {
					return window.MyHomePanelSettings.translations[key];
				}

				return '';
			},
			onCreate() {
				Swal({
					title              : this.getString('saving_changes'),
					showLoaderOnConfirm: true,
					showConfirmButton  : false,
					showCloseButton    : false,
					showCancelButton   : false,
					allowEscapeKey     : false,
					allowOutsideClick  : false,
					type               : 'info'
				}).catch(Swal.noop);
				Swal.showLoading();

				this.$http.post(window.MyHomePanelSettings.requestUrl, {
					action  : 'myhome_agent_fields_create',
					field   : this.field,
					_wpnonce: window.MyHomePanelSettings.nonce
				}, {emulateJSON: true}).then((response) => {
					this.field.slug = response.body.field.slug;
					window.MyHomeAdminEventBus.$emit('agentFieldCreate', this.field);
					this.field = {
						name       : '',
						is_link    : false,
						is_required: false
					};
					Swal({
						title            : this.getString('success'),
						type             : 'success',
						showConfirmButton: false,
						timer            : 1000
					}).catch(Swal.noop);
				}, () => {
					Swal({
						title: this.getString('error'),
						text : this.getString('something_went_wrong'),
						type : 'error'
					}).catch(Swal.noop);
				});
			}
		}
	}
</script>