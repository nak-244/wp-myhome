<template>
	<div class="mh-small-card">
		<div class="mh-small-card__title">
			{{ field.name }}
		</div>
	</div>
</template>

<script>
	export default {
		props: {
			field: Object
		},
		created() {

		}
	}
</script>