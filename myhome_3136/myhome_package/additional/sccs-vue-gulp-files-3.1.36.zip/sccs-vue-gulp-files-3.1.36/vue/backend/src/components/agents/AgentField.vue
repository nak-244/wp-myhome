<template>
	<div>

		<div class="mh-small-card__title">
			{{ field.name }}
			<span class="mh-small-card__title__icon">
					<button
						class="mdl-button mdl-js-button"
						@click="onEdit"
					>
						<i v-if="!editMode" class="material-icons">settings</i>
						<i v-if="editMode" class="material-icons">close</i>
					</button>
			</span>
		</div>

		<div class="mh-small-card__content" v-show="editMode">

			<p>
				<label for="name">{{ getString('field_name') }}</label>
				<input type="text" id="name" v-model="fieldData.name">
			</p>

			<div class="mh-admin-checkbox">
				<div>
					<input id="is_link" type="checkbox" v-model="fieldData.is_link">
				</div>
				<div>
					<label for="is_link">{{ getString('field_is_link') }}</label>
				</div>
			</div>

			<div class="mh-admin-checkbox">
				<div>
					<input id="use_for_registration" type="checkbox" v-model="fieldData.use_for_registration">
				</div>
				<div>
					<label for="use_for_registration">{{ getString('use_for_registration') }}</label>
				</div>
			</div>

			<button class="mdl-button mdl-js-button mdl-button--accent" @click="onSave">
				{{ getString('save') }}
			</button>

			<button class="mdl-button mdl-js-button mdl-button--accent" @click="onDelete">
				{{ getString('remove') }}
			</button>

		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				fieldData: Object,
				editMode : false
			}
		},
		props   : {
			field: Object,
			index: Number
		},
		methods : {
			onEdit() {
				this.editMode = !this.editMode;

				if (!this.editMode) {
					this.fieldData = $.extend({}, this.field);
				}
			},
			onSave() {
				window.MyHomeAdminEventBus.$emit('agentFieldUpdate', this.fieldData);
				this.editMode = false;
			},
			onDelete() {
				Swal({
					title            : 'Are you sure?',
					type             : 'warning',
					confirmButtonText: 'yes',
					cancelButtonText : 'cancel',
					showCancelButton : true,
					allowEscapeKey   : false,
					allowOutsideClick: false
				}).then(() => {
					window.MyHomeAdminEventBus.$emit('agentFieldDelete', this.fieldData);
				}).catch(Swal.noop);
			},
			getString(key) {
				if (typeof window.MyHomePanelSettings.translations[key] !== 'undefined') {
					return window.MyHomePanelSettings.translations[key];
				}

				return '';
			}
		},
		created() {
			this.fieldData = jQuery.extend({}, this.field);
			this.fieldData.is_required = this.field.is_required === true || this.field.is_required === 'true';
			this.fieldData.is_link = this.field.is_link === true || this.field.is_link === 'true';
		}
	}
</script>