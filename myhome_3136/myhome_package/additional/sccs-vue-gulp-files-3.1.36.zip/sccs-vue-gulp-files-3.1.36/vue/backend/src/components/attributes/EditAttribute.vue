<template>
	<div>
		<form @submit.prevent>

			<div class="mdl-card__input-wrapper" v-if="isCore">

				<div class="mh-single-attribute__edit-open__content">

					<template v-if="isKeyword">
						<div class="mdl-card__input-wrapper">
							<label for="name">{{ translations.field_name }}</label>
							<input id="name" class="form-control" type="text" v-model="attribute.name">
						</div>
					</template>

					<template v-if="isPropertyID">
						<div class="mdl-card__input-wrapper">
							<label for="name">{{ translations.field_name }}</label>
							<input id="name" class="form-control" type="text" v-model="attribute.name">
						</div>
					</template>

					<div class="mdl-card__input-wrapper">
						<label for="placeholder">{{ getString('placeholder') }}</label>
						<input id="placeholder" type="text" v-model="attribute.placeholder">
					</div>

					<template v-if="isPropertyID">

						<div class="mh-admin-checkbox">
							<div>
								<input id="card_show" type="checkbox" v-model="attribute.card_show">
							</div>
							<div>
								<label for="card_show">{{ translations.display_on_card }}
									<span class="mh-tooltip">
										<span class="dashicons dashicons-info"></span>
										<span class="mh-tooltip__text">{{ translations.display_on_card_description }}</span>
									</span>
								</label>
							</div>
						</div>
					</template>

					<template v-if="isKeyword">

						<div class="mh-admin-checkbox">
							<div>
								<input id="full_width" type="checkbox" v-model="attribute.full_width">
							</div>
							<div>
								<label for="full_width">{{ translations.searchform_horizontal_width }}</label>
							</div>
						</div>

						<div class="mh-admin-checkbox">
							<div>
								<input id="suggestions_enabled" type="checkbox" v-model="attribute.suggestions_enabled">
							</div>
							<div>
								<label for="suggestions_enabled">{{ translations.suggestions_enabled }}</label>
							</div>
						</div>

						<div v-if="attribute.suggestions_enabled">

							<div class="mdl-card__input-wrapper">
								<label for="suggest_init">{{ translations.suggest_init }}</label>
								<select id="suggest_init" v-model="attribute.suggest_init">
									<option value="">{{ translations.nothing }}</option>
									<option
										v-for="attr in attribute.suggest_attributes"
										:value="attr.id"
									>
										{{ attr.name }}
									</option>
								</select>
							</div>

							<div class="mh-admin-checkbox">
								<div>
									<input id="redirect" type="checkbox" v-model="attribute.redirect">
								</div>
								<div>
									<label for="redirect">{{ translations.redirect_on_select }}</label>
								</div>
							</div>

							<div v-if="attribute.redirect" class="mh-admin-checkbox">
								<div>
									<input id="redirect_new_tab" type="checkbox" v-model="attribute.redirect_new_tab">
								</div>
								<div>
									<label for="redirect_new_tab">{{ translations.redirect_new_tab }}</label>
								</div>
							</div>

							<h3>{{ translations.suggest_attributes }}</h3>

							<div v-for="attr in attribute.suggest_attributes" class="mh-admin-checkbox">
								<div>
									<input id="attribute-suggest" type="checkbox" v-model="attr.suggest">
								</div>
								<div>
									<label for="attribute-suggest">{{ attr.name }}</label>
								</div>
							</div>

						</div>
					</template>

					<button
						class="mdl-button mdl-js-button mdl-button--accent mdl-button--end"
						@click="onSave"
					>
						{{ translations.save }}
					</button>

					<div class="mh-backend-id-number">
						<div>{{ translations.id }}: {{ attribute.id }}</div>
					</div>

				</div>
			</div>

			<main class="mh-single-attribute__edit-open__content" v-if="!isCore">

				<h3 class="mh-single-attribute__heading">
					<i class="glyph-icon flaticon-settings-2"></i> {{ translations.basic_settings }}
				</h3>

				<div v-if="isPrice">

					<div class="mh-admin-checkbox">
						<div>
							<input type="checkbox" id="hide_price" v-model="attribute.currency_settings.hide_price">
						</div>
						<div>
							<label for="hide_price">{{ translations.hide_price_globally }}</label>
						</div>
					</div>

					<div class="mh-admin-checkbox">
						<div>
							<input type="checkbox" id="price_range" v-model="attribute.range">
						</div>
						<div>
							<label for="price_range">{{ translations.price_range }}</label>
						</div>
					</div>

					<div class="mh-admin-checkbox">
						<div>
							<input type="checkbox" id="assign_offer_type" v-model="attribute.assign_offer_type">
						</div>
						<div>
							<label for="assign_offer_type">{{ translations.assign_offer_type }}</label>
						</div>
					</div>

				</div>

				<div v-if="!(isPrice && !showPriceSettings)" class="mdl-card__input-wrapper">
					<label for="name">{{ translations.field_name }}</label>
					<input id="name" class="form-control" type="text" v-model="attribute.name">
				</div>

				<div v-if="!isPrice" class="mdl-card__input-wrapper">
					<label for="icon">{{ translations.set_icon }} <i v-if="hasIcon" :class="icon"></i>
						<span class="mh-tooltip">
							<span class="dashicons dashicons-info"></span>
							<span class="mh-tooltip__text">
								{{ translations.set_icon_description }}
							</span>
						</span>
					</label>
					<input
						id="icon"
						class="form-control icp icp-auto iconpicker-element iconpicker-input mh-attribute__icon-picker"
						data-input-search="true"
						:placeholder="translations.start_typing"
						type="text"
						autocomplete="off"
						v-model="attribute.icon"
					>
				</div>

				<div v-if="isNumber" class="mdl-card__input-wrapper">
					<label for="units">{{ translations.unit_of_measure }}
						<span class="mh-tooltip">
							<span class="dashicons dashicons-info"></span>
							<span class="mh-tooltip__text">
								{{ translations.unit_of_measure_description }}
							</span>
						</span>
					</label>
					<input id="units" class="form-control" type="text" v-model="attribute.display_after">
				</div>

				<template v-if="showPriceSettings">

					<div class="mdl-card__input-wrapper">
						<label for="default_value">{{ translations.text_when_price_not_set }}</label>
						<input type="text" id="default_value" class="form-control" v-model="attribute.currency_settings.default_value">
					</div>

					<div>

						<h3 class="mh-single-attribute__heading">{{ translations.currency }}</h3>

						<draggable
							v-model="attribute.currency_settings.currencies"
							:options="{animation: 150}"
						>

							<div
								class="mh-single-attribute__currency"
								v-for="(currency, currencyKey) in attribute.currency_settings.currencies"
								:index="currencyKey"
								:key="currencyKey"
							>

								<div class="mh-single-attribute__currency__name">
									{{ currency.name }}
								</div>

								<div class="mh-single-attribute__currency__content">
									<div class="mdl-card__input-wrapper">
										<label for="currency_name">{{ translations.name }}</label>
										<input type="text" id="currency_name" v-model="currency.name">
									</div>

									<div class="mdl-card__input-wrapper">
										<label for="currency_sign">{{ translations.currency_sign }}</label>
										<input type="text" id="currency_sign" v-model="currency.sign">
									</div>

									<div class="mdl-card__input-wrapper">
										<label for="currency_location">{{ translations.currency_sign_location }}</label>
										<select id="currency_location" v-model="currency.location">
											<option value="before_price">{{ translations.before_price }}</option>
											<option value="after_price">{{ translations.after_price }}</option>
										</select>
									</div>

									<div class="mdl-card__input-wrapper">
										<label for="currency_thousands_sep">{{ translations.thousands_separator }}</label>
										<input type="text" id="currency_thousands_sep" v-model="currency.thousands_sep">
									</div>

									<div class="mdl-card__input-wrapper">
										<label for="currency_decimal_sep">{{ translations.decimal_separator }}</label>
										<input type="text" id="currency_decimal_sep" v-model="currency.decimal_sep">
									</div>

									<div class="mdl-card__input-wrapper">
										<label for="currency_decimal">{{ translations.decimal }}
											<span class="mh-tooltip">
											<span class="dashicons dashicons-info"></span>
											<span class="mh-tooltip__text">{{ translations.sets_the_number_of_decimal_points }}</span>
										</span>
										</label>
										<input type="text" id="currency_decimal" v-model="currency.decimal">
									</div>

									<button
										v-if="currencyKey"
										class="mdl-button mdl-js-button mdl-button--accent"
										@click="onADeleteCurrency(currencyKey)"
									>
										{{ translations.delete }} "{{ currency.name }}" {{ translations.currency }}
									</button>

								</div>

							</div>

						</draggable>

					</div>

					<button class="mdl-button mdl-js-button mdl-button--new-currency" @click="onAddCurrency">
						<span class="dashicons dashicons-plus"></span> {{ translations.add_new_currency }}
					</button>

				</template>

				<div v-if="isTaxonomy" class="mdl-card__input-wrapper">
					<label for="slug">{{ getString('slug') }}
						<span class="mh-tooltip">
								<span class="dashicons dashicons-info"></span>
								<span class="mh-tooltip__text">{{ translations.slug_is_piece_of_url }}</span>
							</span>
					</label>
					<input id="slug" class="form-control" type="text" v-model="attribute.slug">
				</div>

				<div class="mh-admin-checkbox-all">
					<div class="mh-admin-checkbox" v-if="!isPrice">
						<div>
							<input id="property_show" type="checkbox" v-model="attribute.property_show">
						</div>
						<div>
							<label for="property_show">{{ translations.display_on_single_property_page }}</label>
						</div>
					</div>

					<div class="mh-admin-checkbox" v-if="showDisplayAsLink">
						<div>
							<input id="has_archive" type="checkbox" v-model="attribute.has_archive">
						</div>
						<div>
							<label for="has_archive">{{ translations.show_as_link }}</label>
						</div>
					</div>

					<div class="mh-admin-checkbox" v-if="!isPrice">
						<div>
							<input id="card_show" type="checkbox" v-model="attribute.card_show">
						</div>
						<div>
							<label for="card_show">{{ translations.display_on_card }}
								<span class="mh-tooltip">
										<span class="dashicons dashicons-info"></span>
										<span class="mh-tooltip__text">{{ translations.display_on_card_description }}</span>
									</span>
							</label>
						</div>
					</div>

					<div class="mh-admin-checkbox" v-if="showNewBox">
						<div>
							<input id="new_box" type="checkbox" v-model="attribute.new_box">
						</div>
						<div>
							<label for="new_box">{{ getString('new_box_label') }}</label>
						</div>
					</div>

					<div class="mh-admin-checkbox" v-if="!showNewBox && isTaxonomy">
						<div>
							<input id="new_box" type="checkbox" v-model="attribute.new_box_independent">
						</div>
						<div>
							<label for="new_box">{{ getString('new_box_label') }}</label>
						</div>
					</div>

				</div>


				<template v-if="!(isPrice && !showPriceSettings)">

					<h3 class="mh-single-attribute__heading">
						<span class="dashicons dashicons-search"></span> {{ translations.searchform }}
					</h3>

					<div class="mh-single-attribute__subheading">
						{{ translations.searchform_field_type }}
						<span class="mh-tooltip">
								<span class="dashicons dashicons-info"></span>
								<span class="mh-tooltip__text">{{ translations.parent_field_description }}</span>
							</span>
					</div>

					<div v-if="isPropertyType">
						{{ translations.property_field_type }}
						<a href="https://myhometheme.zendesk.com/hc/en-us/articles/115001342133-How-To-Make-Unnecessary-Search-Form-Filters-Disappear-After-Changing-Property-Type" target="_blank">{{ translations.link }}</a>
						<br><br>
					</div>

					<div class="mdl-card__input-wrapper">
						<select class="form-control" id="search_form_control" v-model="attribute.search_form_control">
							<option v-for="(name, key) in searchFormControls" :value="key">
								{{ name }}
							</option>
						</select>
					</div>

					<div v-if="attribute.search_form_control === 'checkbox'" class="mh-admin-checkbox">
						<div>
							<div>
								<input id="checkbox_move" type="checkbox" v-model="attribute.checkbox_move">
							</div>
							<div>
								<label for="checkbox_move">{{ translations.checkbox_move }}</label>
							</div>
						</div>
					</div>

					<div v-if="isTaxonomy && attribute.search_form_control !== 'text'">
						{{ translations.order_by }}
						<select v-model="attribute.order_by">
							<option value="name">{{ translations.name }}</option>
							<option value="count">{{ translations.count }}</option>
						</select>
					</div>

					<div v-if="!isNumber" class="mh-admin-checkbox">
						<div>
							<input id="full_width" type="checkbox" v-model="attribute.full_width">
						</div>
						<div>
							<label for="full_width">{{ translations.searchform_horizontal_width }}</label>
						</div>
					</div>

					<div v-if="isTaxonomy" class="mdl-card__input-wrapper">
						<label for="parent_id">{{ translations.parent_field }}
							<span class="mh-tooltip">
								<span class="dashicons dashicons-info"></span>
								<span class="mh-tooltip__text">{{ translations.parent_field_description }}</span>
							</span>
						</label>
						<select id="parent_id" v-model="attribute.parent_id">
							<option v-for="attr in parentAttributes" :value="attr.id">{{ attr.name }}</option>
						</select>
					</div>

					<div v-if="isTaxonomy && attribute.parent_id !== 0">
						<label for="parent_type">{{ translations.parent_type }}
							<span class="mh-tooltip">
								<span class="dashicons dashicons-info"></span>
								<span class="mh-tooltip__text"><a href="https://myhometheme.zendesk.com/hc/en-us/articles/360000000913" target="_blank">{{ translations.parent_type_description }}</a></span>
							</span>
						</label>
						<select id="parent_type" v-model="attribute.parent_type">
							<option value="values">{{ translations.parent_values }}</option>
							<option value="manual">{{ translations.parent_manual }}</option>
						</select>
					</div>

					<template v-if="showPlaceholder">

						<div class="mh-single-attribute__subheading">{{ translations.placeholder }}
							<span class="mh-tooltip">
								<span class="dashicons dashicons-info"></span>
								<span class="mh-tooltip__text">{{ translations.placeholder_description }}</span>
							</span>
						</div>

						<div class="mdl-card__input-wrapper">
							<input id="placeholder" type="text" v-model="attribute.placeholder">
						</div>

					</template>

					<div v-if="showPlaceholderRange">

						<div class="mh-single-attribute__subheading">{{ translations.placeholder }}
							<span class="mh-tooltip">
								<span class="dashicons dashicons-info"></span>
								<span class="mh-tooltip__text">{{ translations.placeholder_description }}</span>
							</span>
						</div>

						<div class="mdl-card__input-wrapper mdl-card__input-wrapper--first-half">
							<div>
								<label for="placeholder_from">{{ translations.from }}</label>
							</div>
							<div>
								<input id="placeholder_from" type="text" v-model="attribute.placeholder_from">
							</div>
						</div>

						<div class="mdl-card__input-wrapper mdl-card__input-wrapper--second-half" v-if="showPlaceholderRange">
							<div>
								<label for="placeholder_to">{{ translations.to }}</label>
							</div>
							<div>
								<input id="placeholder_to" type="text" v-model="attribute.placeholder_to">
							</div>
						</div>
						<div class="clearfix"></div>
					</div>

					<div class="mdl-card__input-wrapper" v-if="showDefaultValues">
						<label for="default_values">{{ getString('default_values') }}</label>
						<select class="form-control" id="default_values" v-model="attribute.default_values">
							<option value="all">{{ getString('all') }}</option>
							<option value="most_popular">{{ getString('most_popular') }}</option>
							<option value="static">{{ getString('static') }}</option>
						</select>

						<div v-if="attribute.default_values === 'static'" class="mh-admin-static-link">
							<i class="fa fa-question-circle-o"></i>
							<a href="https://myhometheme.zendesk.com/hc/en-us/articles/115001342153" target="_blank">
								{{ getString('read_static') }}</a>
						</div>
					</div>

					<div v-if="showSuggestions" class="mh-single-attribute__subheading">{{ translations.suggestions }}</div>

					<div class="mh-admin-checkbox" v-if="showSuggestions">
						<div>
							<input id="suggestions" type="checkbox" v-model="attribute.suggestions">
						</div>
						<div>
							<label for="suggestions">{{ getString('suggestions_show') }}</label>
						</div>
					</div>

					<div class="mdl-card__input-wrapper" v-if="showNumberOperator">
						<label for="number_operator">{{ getString('number_operator') }}</label>
						<select id="number_operator" v-model="attribute.number_operator">
							<option value=">">></option>
							<option value=">=">>=</option>
							<option value="=">=</option>
							<option value="<="><=</option>
							<option value=">"><</option>
						</select>
					</div>

					<div class="mdl-card__input-wrapper" v-if="showStaticValues">
						<label>{{ getString('static_values') }}</label>
						<div class="static-values-wrapper">
							<div class="static-values">
								<div class="static-values__col-1">{{ getString('name') }}</div>
								<div class="static-values__col-2">{{ translations.value }}</div>
								<div class="static-values__col-3"></div>
							</div>
							<div class="static-values" v-for="(field, key) in attribute.static_values">
								<div class="static-values__col-1">
									<input type="text" v-model="attribute.static_values[key]['name']">
								</div>
								<div class="static-values__col-2">
									<input type="text" v-model="attribute.static_values[key]['value']">
								</div>
								<div class="static-values__col-3">
									<button class="mdl-button mdl-js-button" @click="onDeleteStaticValue(key)">
										<i class="material-icons">delete</i>
									</button>
								</div>
							</div>
							<div class="static-values">
								<div class="static-values__col-1">
									<input type="text" v-model="staticValue['name']">
								</div>
								<div class="static-values__col-2">
									<input type="text" v-model="staticValue['value']">
								</div>
								<div class="static-values__col-3">
									<button class="mdl-button mdl-js-button" @click="onAddStaticValue">
										<i class="material-icons">add</i>
									</button>
								</div>
							</div>
						</div>
					</div>

					<div class="mdl-card__input-wrapper" v-if="showMostPopularLimit">
						<label for="most_popular_limit">{{ getString('most_popular_limit') }}</label>
						<input class="form-control" id="most_popular_limit" type="text"
							   v-model="attribute.most_popular_limit">
					</div>


				</template>

				<button class="mdl-button mdl-js-button mdl-button--accent mdl-button--end" @click="onSave">
					{{ translations.save }}
				</button>

				<div class="mh-backend-id-number">
					<div>{{ translations.internal_id }}: {{ attribute.id }}</div>
				</div>

			</main>

		</form>
	</div>
</template>

<script>
	import Draggable from 'vuedraggable'

	export default {
		data() {
			return {
				attribute  : {},
				staticValue: {name: '', value: ''}
			}
		},
		components: {Draggable},
		props     : {
			attr      : {
				type: Object
			},
			attributes: {
				attributes: {
					type: Array
				}
			}
		},
		computed  : {
			icon() {
				if (this.attribute.icon.indexOf('fa') !== -1) {
					return 'fa ' + this.attribute.icon;
				}

				return this.attribute.icon;
			},
			hasIcon() {
				return typeof this.attribute.icon !== 'undefined' && this.attribute.icon !== '';
			},
			translations() {
				return window.MyHomePanelSettings.translations;
			},
			isPropertyID() {
				return this.attribute.base_slug === 'property_id';
			},
			isPropertyType() {
				return this.attribute.base_slug === 'property_type'
			},
			isKeyword() {
				return this.attribute.base_slug === 'keyword';
			},
			showPriceSettings() {
				return this.isPrice && !this.attribute.currency_settings.hide_price;
			},
			showDisplayAsLink() {
				return this.isTaxonomy && this.attribute.property_show;
			},
			showDefaultValues() {
				let formControl = this.attribute.search_form_control;
				return this.isTaxonomy && formControl !== 'text' && formControl !== 'text_range' && (this.attribute.parent_id === 0 || this.attribute.parent_id === '0' || this.attribute.parent_id === '');
			},
			parentAttributes() {
				let attributes = [];
				attributes.push({name: this.getString('no_parent_attribute'), id: 0});
				$.each(this.attributes, function (key, attr) {
					if (attr.id === this.attribute.id || attr.type !== 'taxonomy' || attr.parent_id === this.attr.id) {
						return
					}
					attributes.push({name: attr.name, id: attr.id})
				}.bind(this));
				return attributes
			},
			showSuggestions() {
				return this.attribute.search_form_control === 'text' || this.attribute.search_form_control === 'text_range'
			},
			isCore() {
				return this.attribute.type === 'core'
			},
			isPrice() {
				return this.attribute.type === 'price'
			},
			showPlaceholderRange() {
				return this.attribute.search_form_control === 'text_range' || this.attribute.search_form_control === 'select_range'
			},
			searchFormControls() {
				let formControls = {};
				if (this.attribute.type === 'taxonomy') {
					formControls = {
						select         : this.getString('select'),
						select_multiple: this.getString('select_multiple'),
						text           : this.getString('text'),
						checkbox       : this.getString('checkbox'),
						radio_button   : this.getString('radio_button'),
					};

					if (typeof this.attribute.is_breadcrumb !== 'undefined' && this.attribute.is_breadcrumb) {
						delete formControls.select_multiple;
						delete formControls.checkbox;
					}

					if (this.attribute.base_slug === 'property_type') {
						delete formControls.text;
					}
				} else if (this.attribute.type === 'field' || this.attribute.type === 'price') {
					formControls = {
						select         : this.getString('select'),
						select_range   : this.getString('select_range'),
						select_multiple: this.getString('select_multiple'),
						text           : this.getString('text'),
						text_range     : this.getString('text_range'),
						checkbox       : this.getString('checkbox'),
						radio_button   : this.getString('radio_button'),
					}
				}
				return formControls;
			},
			isTaxonomy() {
				return this.attribute.type === 'taxonomy'
			},
			isNumber() {
				return this.attribute.type === 'field';
			},
			showStaticValues() {
				let formControl = this.attribute.search_form_control;
				let type = this.attribute.type;
				let defaultValues = this.attribute.default_values;
				let isText = formControl === 'text' || formControl === 'text_range';
				return (
					(defaultValues === 'static' && !isText) ||
					((type === 'field' || type === 'price') && !isText) ||
					(this.showSuggestions && !this.isTaxonomy && isText && this.attribute.suggestions)
				) && (typeof this.attribute.parent_id === 'undefined' || this.attribute.parent_id === '' || this.attribute.parent_id === '0' || this.attribute.parent_id === 0)
			},
			showNumberOperator() {
				let formControl = this.attribute.search_form_control
				return !this.isTaxonomy && ((formControl === 'radio_button' || formControl === 'select') ||
					(formControl === 'text' && this.attribute.suggestions && this.showSuggestions))
			},
			showMostPopularLimit() {
				return this.attribute.default_values === 'most_popular' && this.showDefaultValues;
			},
			showNewBox() {
				return this.attribute.tags
			},
			showPlaceholder() {
				return this.attribute.search_form_control !== 'checkbox' && !this.showPlaceholderRange
			}
		},
		methods   : {
			onADeleteCurrency(currencyKey) {
				this.attribute.currency_settings.currencies.splice(currencyKey, 1);
			},
			onAddCurrency() {
				if (typeof this.attribute.currency_settings.currencies === 'undefined' || !$.isArray(this.attribute.currency_settings.currencies)) {
					this.attribute.currency_settings.currencies = [];
				}

				this.attribute.currency_settings.currencies.push({
					name         : 'Dollar',
					key          : '',
					sign         : '$',
					location     : 'before_price',
					thousands_sep: ',',
					decimal_sep  : '.',
					decimal      : 0
				});
				this.$set(this.attribute.currency_settings, 'currencies', this.attribute.currency_settings.currencies);
			},
			onAddStaticValue() {
				this.attribute.static_values.push(this.staticValue);
				this.staticValue = {
					name : '',
					value: ''
				}
			},
			onDeleteStaticValue(key) {
				this.attribute.static_values.splice(key, 1)
			},
			onDelete() {
				this.$parent.onDelete();
			},
			onSave() {
				if (this.isTaxonomy && this.attribute.slug === '') {
					Swal({
						title              : this.getString('error'),
						text               : this.getString('slug_is_required'),
						showLoaderOnConfirm: false,
						showConfirmButton  : true,
						allowEscapeKey     : false,
						showCloseButton    : false,
						showCancelButton   : false,
						allowOutsideClick  : false,
						type               : 'error'
					}).catch(Swal.noop);
					return false;
				}

				Swal({
					title              : this.getString('saving_changes'),
					showLoaderOnConfirm: false,
					showConfirmButton  : false,
					allowEscapeKey     : false,
					showCloseButton    : false,
					showCancelButton   : false,
					allowOutsideClick  : false,
					type               : 'info'
				}).catch(Swal.noop);
				Swal.showLoading();

				this.$http.post(window.MyHomePanelSettings.requestUrl, {
					action   : 'attribute_update',
					_wpnonce : window.MyHomePanelSettings.nonce,
					attribute: this.attribute
				}, {emulateJSON: true}).then(response => {
//					window.MyHomeAdminEventBus.$emit('attributeUpdated', response.body.attribute);
//					window.MyHomeAdminEventBus.$emit('attributeUpdated' + response.body.attribute.id, response.body.attribute);
					Swal({
						title            : this.getString('success'),
						type             : 'success',
						showConfirmButton: false,
						timer            : 1000
					}).then(() => {
						window.location.reload();
					}, () => {
						window.location.reload();
					}).catch(Swal.noop);
				}, response => {
					Swal({
						title: this.getString('error'),
						type : 'error'
					}).catch(Swal.noop);
				})
			},
			getString(key) {
				if (typeof window.MyHomePanelSettings.translations[key] !== 'undefined') {
					return window.MyHomePanelSettings.translations[key]
				} else {
					return ''
				}
			}
		},
		created() {
			this.attribute = jQuery.extend({}, this.attr);
			if (this.isPrice && typeof this.attribute.currency_settings.currencies === 'undefined') {
				this.$set(this.attribute.currency_settings, 'currencies', []);
			}

			if (this.isPrice) {
				this.attribute.currency_settings.hide_price = this.attribute.currency_settings.hide_price === 'true';
			}

			if (this.isTaxonomy && typeof this.attribute.order_by === 'undefined' || this.attribute.order_by === '') {
				this.attribute.order_by = 'count';
			}
		},
		mounted() {
			this.$nextTick(() => {
				let iconPicker = jQuery('.mh-attribute__icon-picker');

				if (iconPicker.length) {
					iconPicker.iconpicker({
						title: this.translations.set_icon,
						icons: jQuery.merge([
							'flatfront-area',
							'flatfront-air-conditioner',
							'flatfront-apartment',
							'flatfront-bath',
							'flatfront-bath-2',
							'flatfront-bathtub',
							'flatfront-bed',
							'flatfront-bulb',
							'flatfront-city',
							'flatfront-city-2',
							'flatfront-computer',
							'flatfront-construction',
							'flatfront-construction-2',
							'flatfront-date',
							'flatfront-dishwasher',
							'flatfront-door',
							'flatfront-fence',
							'flatfront-fireplace',
							'flatfront-full-size',
							'flatfront-furniture',
							'flatfront-garage',
							'flatfront-home',
							'flatfront-home-2',
							'flatfront-home-3',
							'flatfront-home-4',
							'flatfront-home-5',
							'flatfront-home-6',
							'flatfront-house-plan',
							'flatfront-house-plan-2',
							'flatfront-interface',
							'flatfront-layers',
							'flatfront-lift',
							'flatfront-location',
							'flatfront-location-2',
							'flatfront-mail',
							'flatfront-mail-2',
							'flatfront-map',
							'flatfront-medical',
							'flatfront-microwave',
							'flatfront-multimedia',
							'flatfront-office',
							'flatfront-office-2',
							'flatfront-owen',
							'flatfront-parquet',
							'flatfront-phone',
							'flatfront-pin',
							'flatfront-prize',
							'flatfront-rent',
							'flatfront-roof',
							'flatfront-school',
							'flatfront-school-2',
							'flatfront-shower',
							'flatfront-sofa',
							'flatfront-sofa-2',
							'flatfront-sold',
							'flatfront-stairs',
							'flatfront-swimming-pool',
							'flatfront-technology',
							'flatfront-transport',
							'flatfront-wall',
							'flatfront-wardrobe',
							'flatfront-wifi',
							'flatfront-window',
						], jQuery.iconpicker.defaultOptions.icons)
					});

					iconPicker.on('iconpickerSelected', (event) => {
						this.attribute.icon = event.iconpickerValue;
					});
				}
			});
		}
	}
</script>