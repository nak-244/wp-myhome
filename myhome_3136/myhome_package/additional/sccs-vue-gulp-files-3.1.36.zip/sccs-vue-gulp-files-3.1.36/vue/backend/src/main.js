"use strict";

import Vue from 'vue'
import VueResource from 'vue-resource'
import VueProgressBar from 'vue-progressbar'
import AttributesForm from './components/attributes/AttributesForm.vue'
import PanelSettings from './components/panel/PanelSettings.vue'
import EstateElements from './components/estate/EstateElements.vue'
import BackendPanel from './components/BackendPanel.vue'
import Swal from 'sweetalert2'

Vue.use(VueResource);

let options = {
	failedColor: 'red',
	thickness  : '5px',
	transition : {
		speed      : '0.2s',
		opacity    : '0.6s',
		termination: 300
	},
	autoRevert : false,
	location   : 'bottom',
	inverse    : false
};

if (typeof window.MyHomePanelSettings !== 'undefined') {
	options.color = window.MyHomePanelSettings.primaryColor
}

Vue.use(VueProgressBar, options);

window.MyHomeAdminEventBus = new Vue();
window.$ = window.jQuery;
window.Swal = Swal;

if (document.querySelector('#myhome-backend-panel')) {
	new Vue({
		el        : '#myhome-backend-panel',
		components: {BackendPanel}
	})
}

if (document.querySelector('#myhome-attributes-form')) {
	new Vue({
		el        : '#myhome-attributes-form',
		components: {AttributesForm}
	})
}

if (document.querySelector('#myhome-panel-settings')) {
	new Vue({
		el        : '#myhome-panel-settings',
		components: {PanelSettings}
	})
}

if (document.querySelector('#myhome-estate-elements-config')) {
	new Vue({
		el        : '#myhome-estate-elements-config',
		components: {EstateElements}
	})
}