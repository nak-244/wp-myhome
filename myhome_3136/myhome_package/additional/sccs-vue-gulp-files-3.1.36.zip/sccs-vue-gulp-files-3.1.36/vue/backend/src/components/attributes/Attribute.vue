<template>
	<div class="mh-single-attribute">

		<div class="mh-single-attribute__id">{{ index + 1 }}.</div>
		<div class="mh-single-attribute__name">{{ attribute.name }}</div>
		<div class="mh-single-attribute__type">{{ attribute.type_name }}</div>
		<div class="mh-single-attribute__edit-button">
			<button class="mdl-button mdl-js-button mdl-button--primary" @click="onEdit">
				<i v-if="!editMode" class="material-icons">settings</i>
				<i v-if="editMode" class="material-icons">close</i>
			</button>
		</div>
		<div v-if="attr.base_slug === ''" class="mh-single-attribute__delete-button">
			<button class="mdl-button mdl-js-button mdl-button--primary" @click="onDelete">
				<i class="material-icons">remove_circle_outline</i></button>
		</div>

		<div
			class="mh-single-attribute__edit-open"
			v-if="editMode"
		>
			<EditAttribute
				:attr="attribute"
				:attributes="attributes"
			></EditAttribute>

			<div class="clearfix"></div>
		</div>
	</div>
</template>

<script>
	import EditAttribute from './EditAttribute.vue'

	export default {
		components: {EditAttribute},
		data() {
			return {
				attribute: {},
				editMode : false
			}
		},
		props     : {
			index     : {
				type: Number
			},
			attr      : {
				type: Object
			},
			attributes: {
				type: Array
			}
		},
		computed  : {
			translations() {
				return window.MyHomePanelSettings.translations;
			}
		},
		methods   : {
			getString(key) {
				if (typeof window.MyHomePanelSettings.translations[key] !== 'undefined') {
					return window.MyHomePanelSettings.translations[key]
				} else {
					return ''
				}
			},
			onDelete() {
				Swal({
					title            : this.getString('are_you_sure'),
					type             : 'warning',
					showConfirmButton: true,
					allowEscapeKey   : false,
					showCloseButton  : false,
					showCancelButton : true,
					allowOutsideClick: false
				}).then(function () {
					window.MyHomeAdminEventBus.$emit('attributeDeleted', {attribute: this.attribute, index: this.index});
					Swal({
						title              : this.getString('saving_changes'),
						showLoaderOnConfirm: true,
						showConfirmButton  : false,
						allowEscapeKey     : false,
						showCloseButton    : false,
						showCancelButton   : false,
						allowOutsideClick  : false,
						type               : 'info'
					}).catch(Swal.noop);
					Swal.showLoading();
					this.$http.post(window.MyHomePanelSettings.requestUrl, {
						action      : 'attribute_delete',
						_wpnonce    : window.MyHomePanelSettings.nonce,
						attribute_id: this.attribute.id
					}, {emulateJSON: true}).then(response => {
						Swal({
							title            : this.getString('success'),
							type             : 'success',
							showConfirmButton: false,
							timer            : 1000
						}).catch(Swal.noop);
					}, response => {
						Swal({
							title: this.getString('error'),
							text : this.getString('something_went_wrong'),
							type : 'error'
						}).catch(Swal.noop);
					})
				}.bind(this), function () {
					Swal({
						title: this.getString('error'),
						text : this.getString('something_went_wrong'),
						type : 'error'
					}).catch(Swal.noop);
				})
			},
			onEdit() {
				this.editMode = !this.editMode
			}
		},
		created() {
			this.attribute = this.attr;

			window.MyHomeAdminEventBus.$on('attributeUpdated' + this.attribute.id, (attribute) => {
				this.$nextTick(() => {
					this.attribute = attribute;
					this.editMode = false;
				});
			});
		}
	}
</script>