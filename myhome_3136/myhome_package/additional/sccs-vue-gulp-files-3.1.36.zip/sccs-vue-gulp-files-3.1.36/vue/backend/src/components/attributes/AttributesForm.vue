<template>

	<div>

		<div v-if="showSearchAttributes">

			<div class="mh-attributes-wrapper">

				<div class="mh-single-attribute mh-single-attribute--header">

					<div class="mh-single-attribute__id">{{ translations.order }}</div>
					<div class="mh-single-attribute__name">{{ translations.name }}</div>
					<div class="mh-single-attribute__type">{{ translations.type }}</div>
					<div class="mh-single-attribute__edit-button">
						{{ translations.edit }}
					</div>
					<div class="mh-single-attribute__delete-button">
						{{ translations.remove }}
					</div>

				</div>

				<draggable
					v-model="searchAttributes"
					@end="onUpdate"
					:options="{animation: 150}"
				>

					<attribute
						v-for="(attribute, index) in searchAttributes"
						:key="'id-' + attribute.id"
						:index="index"
						:attr="attribute"
						:attributes="searchAttributes"
					>
					</attribute>

				</draggable>

			</div>

		</div>

		<div v-if="showAdditionalAttributes">

			<h2>{{ getString('additional_attributes') }}</h2>

			<attribute
				v-for="(attribute, index) in additionalAttributes"
				:key="'id-' + attribute.id"
				:index="index"
				:attr="attribute"
				:attributes="additionalAttributes"
			>
			</attribute>

		</div>

	</div>


</template>

<script>
	import Draggable from 'vuedraggable'
	import Attribute from './Attribute.vue'
	import CreateAttribute from './CreateAttribute.vue'

	export default {
		components: {Attribute, CreateAttribute, Draggable},
		data() {
			return {
				searchAttributes    : [],
				additionalAttributes: []
			}
		},
		props     : {
			atts: {
				type: Array
			}
		},
		computed  : {
			translations() {
				return window.MyHomePanelSettings.translations;
			},
			showAdditionalAttributes() {
				return this.additionalAttributes.length > 0
			},
			showSearchAttributes() {
				return this.searchAttributes.length > 0
			}
		},
		methods   : {
			isSearchAttribute(attribute) {
				return attribute.type === 'taxonomy' || attribute.type === 'field' || attribute.type === 'core' ||
					attribute.type === 'price'
			},
			getString(key) {
				if (typeof window.MyHomePanelSettings.translations[key] !== 'undefined') {
					return window.MyHomePanelSettings.translations[key]
				} else {
					return ''
				}
			},
			onUpdate() {
				for (let i = 0; i < this.searchAttributes.length; i++) {
					this.$set(this.searchAttributes[i], 'form_order', i)
				}

				this.$http.post(window.MyHomePanelSettings.requestUrl, {
					action    : 'attribute_move',
					_wpnonce  : window.MyHomePanelSettings.nonce,
					attributes: this.searchAttributes
				}, {emulateJSON: true}).then(response => {
				}, response => {
					Swal({
						title: this.getString('error'),
						text : this.getString('something_went_wrong'),
						type : 'error'
					})
				})
			}
		},
		created() {
			for (let i = 0; i < this.atts.length; i++) {
				if (this.isSearchAttribute(this.atts[i])) {
					this.searchAttributes.push(this.atts[i])
				} else {
					this.additionalAttributes.push(this.atts[i])
				}
			}

			window.MyHomeAdminEventBus.$on('attributeDeleted', function (data) {
				if (this.isSearchAttribute(data.attribute)) {
					this.searchAttributes.splice(data.index, 1)
				} else {
					this.additionalAttributes.splice(data.index, 1)
				}
				setTimeout(() => {
					window.location.reload();
				}, 1200);
			}.bind(this));

			window.MyHomeAdminEventBus.$on('attributeCreated', function (attribute) {
				if (this.isSearchAttribute(attribute)) {
					this.searchAttributes.push(attribute)
				} else {
					this.additionalAttributes.push(attribute)
				}
				setTimeout(() => {
					window.location.reload();
				}, 1200);
			}.bind(this));

			window.MyHomeAdminEventBus.$on('attributeUpdated', function (attribute) {
				let attributesType;
				if (this.isSearchAttribute(attribute)) {
					attributesType = 'searchAttributes'
				} else {
					attributesType = 'additionalAttributes'
				}

				for (let i = 0; i < this[attributesType].length; i++) {
					if (this[attributesType][i].id === attribute.id) {
						this.$set(this[attributesType], i, attribute);
						setTimeout(() => {
							window.location.reload();
						}, 1200);
						return false
					}
				}
			}.bind(this));
		}
	}
</script>