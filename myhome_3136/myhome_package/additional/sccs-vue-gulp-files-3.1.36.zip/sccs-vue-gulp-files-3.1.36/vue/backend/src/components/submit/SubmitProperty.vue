<template>
	<div>
		<div class="mh-grid-alternative">

			<slot></slot>

			<div class="mh-grid-alternative__col-1">
				<h2>{{ translations.submit_property }}</h2>

				<draggable
					v-model="currentSteps"
					:options="{groups: 'steps', animation: 150}"
					@change="updateSteps"
				>
					<step
						v-for="(step, index) in currentSteps"
						:step="step"
						:index="index"
						:key="step.key"
					>
					</step>
				</draggable>

				<div class="mh-next-step-button">
					<button
						class="mdl-button mdl-js-button mdl-button--accent"
						@click="onCreateStep"
					>
						{{ translations.create_new_step }}
					</button>
				</div>
			</div>

			<div class="mh-grid-alternative__col-2" style="height: 800px;">
				<h2>{{ translations.hidden }}</h2>

				<draggable
					v-model="currentFields"
					class="mh-small-cards-wrapper mh-small-cards-wrapper--submit-property"
					:options="{group: 'fields', animation: 150}"
				>
					<field
						v-for="field in currentFields"
						:key="field.slug"
						:field="field"
						:isSelected="false"
					>
					</field>
				</draggable>
			</div>

		</div>
	</div>
</template>

<script>
	import Step from './Step.vue'
	import Field from './Field.vue'
	import Draggable from 'vuedraggable'

	export default {
		name      : "submit-property",
		components: {Step, Field, Draggable},
		data() {
			return {
				currentSteps : [],
				currentFields: []
			}
		},
		props     : {
			steps : Array,
			fields: Array
		},
		computed  : {
			translations() {
				return window.MyHomePanelSettings.translations;
			}
		},
		methods   : {
			onCreateStep() {
				this.currentSteps.push({
					name  : this.translations.set_step_name,
					fields: [],
					key   : new Date().getTime()
				});
				this.updateSteps();
			},
			updateSteps() {
				this.$http.post(window.MyHomePanelSettings.requestUrl, {
					steps   : this.currentSteps,
					_wpnonce: window.MyHomePanelSettings.nonce,
					action  : 'myhome_submit_property_update_steps'
				}, {emulateJSON: true}).then(() => {

				}, (response) => {

				});
			}
		},
		created() {
			this.currentSteps = this.steps;
			this.currentFields = this.fields;

			window.MyHomeAdminEventBus.$on('myhomeSubmitPropertyRemoveStep', (index) => {
				this.currentSteps.splice(index, 1);
				this.updateSteps();
			});

			window.MyHomeAdminEventBus.$on('myhomeSubmitPropertyUpdateStep', (data) => {
				this.$set(this.currentSteps, data.index, data.step);
				this.updateSteps();
			});

			window.MyHomeAdminEventBus.$on('myhomeAddAvailableField', (field) => {
				this.currentFields.push(field);
			});
		},
		mounted() {
			jQuery('.mh-grid-alternative__col-2').stick_in_parent({
				offset_top: 0
			});
		}
	}
</script>