<template>
	<div>

		<div class="mh-grid-alternative">

			<div class="mh-grid-alternative__col-1">
				<h2>{{ translations.submit_property }}</h2>
				<PanelFields :fields="currentSelectedFields" :isSelected="true"></PanelFields>
			</div>

			<div class="mh-grid-alternative__col-2">
				<h2>{{ translations.hidden }}</h2>
				<PanelFields :fields="currentAvailableFields" :isSelected="false"></PanelFields>
			</div>

		</div>

	</div>
</template>

<script>
	import PanelFields from './PanelFields.vue'

	export default {
		components: {PanelFields},
		data() {
			return {
				currentSelectedFields : [],
				currentAvailableFields: []
			}
		},
		props     : {
			selectedFields : Array,
			availableFields: Array
		},
		computed  : {
			translations() {
				return window.MyHomePanelSettings.translations;
			}
		},
		methods   : {
			onSave() {
				this.$http.post(window.MyHomePanelSettings.requestUrl, {
					fields  : this.selectedFields,
					_wpnonce: window.MyHomePanelSettings.nonce,
					action  : 'myhome_user_panel_fields'
				}, {emulateJSON: true}).then(() => {

				}, (response) => {

				});
			}
		},
		created() {
			this.currentAvailableFields = this.availableFields;
			this.currentSelectedFields = this.selectedFields;
		}
	}
</script>