<template>
	<div>
		<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
			<header class="mdl-layout__header">
				<div class="mdl-layout__header-row">
					<!-- Title -->
					<span class="mdl-layout-title">{{ translations.myhome_panel }}</span>
					<!--<div class="mdl-layout-subtitle"></div>-->
				</div>
				<!-- Tabs -->
				<div class="mdl-layout__tab-bar mdl-layout__tab-bar--big mdl-js-ripple-effect">
					<a id="mh-tab-1" href="#fixed-tab-1" class="mdl-layout__tab is-active"><i class="glyph-icon flaticon-settings-1"></i> {{ translations.general }}</a>
					<a id="mh-tab-2" href="#fixed-tab-2" class="mdl-layout__tab"><i class="glyph-icon flaticon-internet"></i> {{ translations.property_page }}</a>
					<a id="mh-tab-3" href="#fixed-tab-3" class="mdl-layout__tab"><i class="glyph-icon flaticon-construction"></i> {{ translations.submit_property }}</a>
					<a id="mh-tab-5" href="#fixed-tab-5" class="mdl-layout__tab"><i class="glyph-icon flaticon-info"></i> {{ translations.agent }}</a>
					<a id="mh-tab-6" href="#fixed-tab-6" class="mdl-layout__tab"><i class="material-icons">search</i> {{ translations.custom_search_forms }}</a>
				</div>
			</header>

			<main class="mdl-layout__content">
				<div class="mdl-layout__content__inner">

					<section class="mdl-layout__tab-panel is-active" id="fixed-tab-1">
						<div class="page-content">
							<div class="mh-grid-alternative">
								<div class="mh-grid-alternative__col-1">
									<h2>{{ translations.property_fields }}</h2>
									<AttributesForm
										:atts="attributes"
									>
									</AttributesForm>
								</div>
								<div class="mh-grid-alternative__col-2">
									<h2>{{ translations.create_new_property_field }}</h2>
									<CreateAttribute>
									</CreateAttribute>
								</div>
							</div>
						</div>
					</section>

					<section class="mdl-layout__tab-panel" id="fixed-tab-2">
						<div class="page-content">
							<EstateElements
								:selected-elements="selectedElements"
								:available-elements="availableElements"
								:element-types="elementTypes"
							>
							</EstateElements>
						</div>
					</section>

					<section class="mdl-layout__tab-panel" id="fixed-tab-3">
						<div class="page-content">
							<SubmitProperty
								:steps="submitPropertySteps"
								:fields="submitPropertyFields"
							>
								<slot></slot>
							</SubmitProperty>
						</div>
					</section>

					<section class="mdl-layout__tab-panel" id="fixed-tab-5">
						<div class="page-content">
							<AgentFields
								:fields-list="agentFields"
							>
							</AgentFields>
						</div>
					</section>

					<section class="mdl-layout__tab-panel" id="fixed-tab-6">
						<div class="page-content">
							<SearchForms :searchForms="searchForms">
							</SearchForms>
						</div>
					</section>

				</div>
			</main>
		</div>
		<div class="clearfix"></div>
	</div>
</template>

<script>
	import AttributesForm from './attributes/AttributesForm.vue'
	import CreateAttribute from './attributes/CreateAttribute.vue'
	import EstateElements from './estate/EstateElements.vue'
	import AgentFields from './agents/AgentFields.vue'
	import PanelSettings from './panel/PanelSettings.vue'
	import SearchForms from './search_forms/SearchForms.vue'
	import SubmitProperty from './submit/SubmitProperty.vue'

	export default {
		data() {
			return {
				state     : 'propertyFields',
				attributes: []
			}
		},
		components: {
			AttributesForm,
			EstateElements,
			CreateAttribute,
			AgentFields,
			PanelSettings,
			SearchForms,
			SubmitProperty
		},
		props     : {
			atts                : Array,
			nonce               : String,
			selectedElements    : Array,
			availableElements   : Array,
			elementTypes        : Object,
			selectedFields      : Array,
			availableFields     : Array,
			agentFields         : Array,
			searchForms         : Array,
			submitPropertySteps : Array,
			submitPropertyFields: Array
		},
		computed  : {
			translations() {
				return window.MyHomePanelSettings.translations;
			}
		},
		created() {
			this.attributes = this.atts;
		}
	}
</script>