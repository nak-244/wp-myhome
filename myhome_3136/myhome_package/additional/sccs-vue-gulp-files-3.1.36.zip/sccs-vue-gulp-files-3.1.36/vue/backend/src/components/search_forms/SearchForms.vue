<template>
	<div>
		<div class="mh-grid-alternative">
			<div class="mh-grid-alternative__col-1">
				<h2>{{ translations.choose_search_form }}</h2>

				<div class="mh-new-field__input-wrapper">
					<select
						v-if="showSelect"
						v-model="currentSearchForm"
					>
						<option
							v-for="(form, key) in currentSearchForms"
							:key="key"
							:value="form.key"
						>
							{{ form.label }}
						</option>
					</select>
				</div>
				<button
					v-if="currentSearchForm"
					@click="onDelete"
					class="mdl-button mdl-js-button mdl-button--accent"
				>
					{{ translations.remove }}
				</button>
			</div>
			<div class="mh-grid-alternative__col-2">

				<h2>{{ translations.create_new }}</h2>
				<div class="mh-new-field">
					<!--<p>{{ translations.searchforms_description }}</p>-->

						<div class="mh-new-field__input-wrapper">
							<label for="name">{{ translations.searchform_name }}</label>
							<input  type="text" v-model="newSearchFormName">
						</div>

					<button
						@click="onCreate"
						class="mdl-button mdl-js-button mdl-button--accent"
					>
						{{ translations.create }}
					</button>

				</div>
			</div>
		</div>


		<SearchForm
			:key="currentSearchForm"
			v-if="currentSearchForm"
			:searchForm="searchForm"
		></SearchForm>

	</div>

</template>

<script>
	import SearchForm from './SearchForm.vue'

	export default{
		data() {
			return {
				currentSearchForm : false,
				currentSearchForms: [],
				newSearchFormName : ''
			}
		},
		components: {SearchForm},
		props     : {
			searchForms       : Array,
			searchFormElements: Array
		},
		computed  : {
			translations() {
				return window.MyHomePanelSettings.translations;
			},
			showSelect() {
				return this.currentSearchForms.length > 0;
			},
			searchForm() {
				for (let i = 0; i < this.currentSearchForms.length; i++) {
					if (this.currentSearchForms[i].key === this.currentSearchForm) {
						return this.currentSearchForms[i];
					}
				}
			}
		},
		methods   : {
			onCreate() {
				Swal({
					title            : this.translations.searchform_save,
					allowEscapeKey   : false,
					allowOutsideClick: false,
					showConfirmButton: false
				});
				Swal.showLoading();

				this.$http.post(window.MyHomePanelSettings.requestUrl, {
					action  : 'search_form_create',
					_wpnonce: window.MyHomePanelSettings.nonce,
					label   : this.newSearchFormName
				}, {emulateJSON: true}).then(response => {
					if (response.body.success === true) {
						this.newSearchFormName = '';
						let searchForm = response.body.search_form;
						this.currentSearchForms.push(searchForm);
						this.currentSearchForm = searchForm.key;

						Swal({
							title            : this.translations.success,
							type             : 'success',
							showConfirmButton: false,
							timer            : 1000
						}).catch(Swal.noop);
					} else {
						Swal({
							title: this.translations.error,
							type : 'error'
						}).catch(Swal.noop);
					}
				}, response => {
					Swal({
						title: this.translations.error,
						type : 'error'
					}).catch(Swal.noop);
				})
			},
			onDelete() {
				Swal({
					title            : this.translations.are_you_sure,
					type             : 'warning',
					showCancelButton : true,
					cancelButtonText : this.translations.cancel,
					confirmButtonText: this.translations.yes
				}).then(() => {
					Swal({
						title            : this.translations.deleting_searchform,
						type             : 'info',
						showConfirmButton: false
					});
					Swal.showLoading();
					this.$http.post(window.MyHomePanelSettings.requestUrl, {
						action  : 'search_form_delete',
						_wpnonce: window.MyHomePanelSettings.nonce,
						key     : this.currentSearchForm
					}, {emulateJSON: true}).then(response => {
						let success = response.body.success;
						if (success === true) {
							let key = this.currentSearchForm;
							this.currentSearchForm = false;
							$.each(this.currentSearchForms, (index, searchForm) => {
								if (searchForm.key === key) {
									this.currentSearchForms.splice(index, 1);
									return false;
								}
							});
							Swal({
								title            : this.translations.success,
								type             : 'success',
								showConfirmButton: false,
								timer            : 1000
							}).catch(Swal.noop);
						} else {
							Swal({
								title: this.translations.error,
								type : 'error'
							}).catch(Swal.noop);
						}
					}, response => {
						Swal({
							title: this.translations.error,
							type : 'error'
						}).catch(Swal.noop);
					});
				}).catch(Swal.noop);
			}
		},
		created() {
			this.currentSearchForms = this.searchForms;

			window.MyHomeAdminEventBus.$on('updateSearchForm', (searchForm) => {
				$.each(this.currentSearchForms, (index, form) => {
					if (this.currentSearchForms[index].key === searchForm.key) {
						this.$set(this.currentSearchForms, index, searchForm);
						return false;
					}
				});
			});
		}
	}
</script>