<template>
	<div>

		<div class="mh-grid-alternative">

			<div class="mh-grid-alternative__col-1">
				<h2>{{ translations.agent_fields }}</h2>

				<Draggable
					v-model="fields"
					class="mh-small-cards-wrapper"
					:options="{animation: 150}"
					@change="onSave"
				>

					<div
						v-for="(field, index) in fields"
						:key="field.slug"
						class="mh-small-card"
					>

						<AgentField
							:key="field.name"
							:field="field"
							:index="index"
						></AgentField>

					</div>

				</Draggable>

			</div>

			<div class="mh-grid-alternative__col-2">
				<h2>{{ translations.create_new_agent_field }}</h2>
				<CreateAgentField></CreateAgentField>
			</div>
		</div>

		<vue-progress-bar></vue-progress-bar>

	</div>
</template>

<script>
	import Draggable from 'vuedraggable'
	import AgentField from './AgentField.vue'
	import CreateAgentField from './CreateAgentField.vue'

	export default {
		data() {
			return {
				fields     : [],
				showLoading: false
			}
		},
		components: {Draggable, AgentField, CreateAgentField},
		props     : {
			fieldsList: Array
		},
		computed  : {
			translations() {
				return window.MyHomePanelSettings.translations;
			}
		},
		methods   : {
			onSave() {
				if (this.showLoading) {
					Swal({
						title            : 'saving changes',
						type             : 'info',
						allowOutsideClick: false,
						allowEscapeKey   : false
					}).catch(Swal.noop);
					Swal.showLoading();
				} else {
					this.$Progress.start();
				}
				this.$http.post(window.MyHomePanelSettings.requestUrl, {
					action  : 'myhome_agent_fields_save',
					fields  : this.fields,
					_wpnonce: window.MyHomePanelSettings.nonce
				}, {emulateJSON: true}).then(() => {
					if (this.showLoading) {
						Swal({
							title            : 'success',
							type             : 'success',
							timer            : 1000,
							showConfirmButton: false,
						}).catch(Swal.noop);
					} else {
						this.$Progress.finish();
					}
					this.showLoading = false;
				}, () => {
					if (this.showLoading) {
						Swal({
							title: 'error',
							type : 'error'
						}).catch(Swal.noop);
					} else {
						this.$Progress.fail();
					}
					this.showLoading = false;
				});
			}
		},
		created() {
			this.fields = this.fieldsList;

			window.MyHomeAdminEventBus.$on('agentFieldUpdate', (fieldData) => {
				$.each(this.fields, (index, field) => {
					if (field.slug === fieldData.slug) {
						this.$set(this.fields, index, fieldData);
						this.showLoading = true;
						this.onSave();
						return false;
					}
				});
			});

			window.MyHomeAdminEventBus.$on('agentFieldDelete', (fieldData) => {
				$.each(this.fields, (index, field) => {
					if (field.slug === fieldData.slug) {
						this.fields.splice(index, 1);
						this.showLoading = true;
						this.onSave();
						return false;
					}
				});
			});

			window.MyHomeAdminEventBus.$on('agentFieldCreate', (fieldData) => {
				this.fields.push(fieldData);
			});
		}
	}
</script>