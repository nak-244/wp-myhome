<template>
	<div>
		<div class="mh-admin-step">
			<h4 class="mh-admin-step__heading">{{ step.name }}</h4>
			<div class="mh-admin-step__info">
				<div class="mh-admin-step__name">
					<input type="text" v-model.lazy="currentStep.name">
				</div>
				<div class="mh-admin-step__remove">
					<button
						v-if="index"
						class="mdl-button mdl-js-button"
						@click="onDelete"
					>
						<i class="material-icons">delete</i>
					</button>
				</div>
			</div>
		</div>

		<draggable
			v-model="currentStep.fields"
			class="mh-small-cards-wrapper mh-small-cards-wrapper--submit-property  mh-small-cards-wrapper--submit-property-new"
			:options="{group: 'fields', animation: 150}"
			@change="onSave"
			style="min-height:70px;"
		>
			<field
				v-for="field in currentStep.fields"
				:field="field"
				:key="field.slug"
				:is-selected="true"
			>
			</field>
		</draggable>

	</div>
</template>

<script>
	import Field from './Field.vue'
	import Draggable from 'vuedraggable'

	export default {
		name      : "step",
		components: {Field, Draggable},
		data() {
			return {
				currentStep: Object
			}
		},
		props     : {
			step : Object,
			index: Number
		},
		methods   : {
			onSave() {
				window.MyHomeAdminEventBus.$emit('myhomeSubmitPropertyUpdateStep', {
					index: this.index,
					step : this.currentStep
				});
			},
			onDelete() {
				jQuery.each(this.currentStep.fields, (index, field) => {
					window.MyHomeAdminEventBus.$emit('myhomeAddAvailableField', field);
				});
				window.MyHomeAdminEventBus.$emit('myhomeSubmitPropertyRemoveStep', this.index);
			}
		},
		created() {
			this.currentStep = this.step;

			if (typeof this.currentStep.fields === 'undefined' || !jQuery.isArray(this.currentStep.fields)) {
				this.$set(this.currentStep, 'fields', []);
			}

			window.MyHomeAdminEventBus.$on('myhomeSubmitPropertyUpdateField', (field) => {
				jQuery.each(this.currentStep.fields, (index, stepField) => {
					if (stepField.slug === field.slug) {
						this.$set(this.currentStep.fields, index, field);
						this.onSave();
						return false;
					}
				});
			});
		},
		watch     : {
			'step.name': function () {
				this.onSave();
			}
		}
	}
</script>