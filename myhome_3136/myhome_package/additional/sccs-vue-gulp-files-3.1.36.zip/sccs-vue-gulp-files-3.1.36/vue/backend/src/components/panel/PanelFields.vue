<template>
	<div>

		<draggable
			v-model="currentFields"
			class="mh-small-cards-wrapper mh-small-cards-wrapper--submit-property"
			:options="{group: 'fields', animation: 150}"
			@change="save"
		>
			<PanelField
				v-for="field in currentFields"
				:key="field.slug"
				:field="field"
				:isSelected="isSelected"
			>
			</PanelField>
		</draggable>
		<vue-progress-bar v-if="isSelected"></vue-progress-bar>
	</div>
</template>

<script>
	import Draggable from 'vuedraggable'
	import PanelField from './PanelField.vue'

	export default {
		components: {Draggable, PanelField},
		data() {
			return {
				currentFields: [],
				showLoading  : false
			}
		},
		props     : {
			fields    : Array,
			isSelected: Boolean
		},
		computed  : {
			translations() {
				return window.MyHomePanelSettings.translations;
			}
		},
		methods   : {
			save() {
				if (!this.isSelected) {
					return;
				}

				if (this.showLoading) {
					Swal({
						title            : this.translations.saving_changes,
						type             : 'info',
						showConfirmButton: false,
						allowEscapeKey   : false,
						allowOutsideClick: false
					}).catch(Swal.noop);
					Swal.showLoading();
				} else {
					this.$Progress.start();
				}

				this.$http.post(window.MyHomePanelSettings.requestUrl, {
					action  : 'myhome_panel_settings_save',
					fields  : this.currentFields,
					_wpnonce: window.MyHomePanelSettings.nonce
				}, {emulateJSON: true}).then(() => {
					if (this.showLoading) {
						Swal({
							title            : this.translations.success,
							type             : 'success',
							timer            : 1000,
							showConfirmButton: false
						}).catch(Swal.noop);
						this.showLoading = false;
					} else {
						this.$Progress.finish()
					}
				}, () => {
					if (this.showLoading) {
						Swal({
							title: this.translations.error,
							type : 'error'
						}).catch(Swal.noop);
						this.showLoading = false;
					} else {
						this.$Progress.fail();
					}
				})
			}
		},
		created() {
			this.currentFields = this.fields;

			window.MyHomeAdminEventBus.$on('panelRemoveField', (field) => {
				if (!this.isSelected) {
					this.currentFields.push(field);
					return;
				}

				$.each(this.currentFields, (index, f) => {
					if (f.slug === field.slug) {
						this.currentFields.splice(index, 1);
						return false;
					}
				});
				this.save();
			});

			window.MyHomeAdminEventBus.$on('panelUpdateField', (field) => {
				if (!this.isSelected) {
					return;
				}

				$.each(this.currentFields, (index, f) => {
					if (f.slug === field.slug) {
						this.$set(this.currentFields, index, field);
						this.showLoading = true;
						this.save();
						return false;
					}
				});
			});
		}

	}
</script>