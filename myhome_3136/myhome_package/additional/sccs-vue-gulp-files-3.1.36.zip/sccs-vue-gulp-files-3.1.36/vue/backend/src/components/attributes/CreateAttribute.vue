<template>
	<div>

		<div class="mh-new-field">
			<form @submit.prevent>

				<div class="mh-new-field__input-wrapper">
					<label for="field-name">{{ getString('field_name') }}</label>
					<input id="field-name" type="text" v-model="attribute.name">
				</div>

				<div class="mh-new-field__input-wrapper">
					<label for="field-type">{{ getString('field_type') }}</label>
					<select id="field-type" v-model="attribute.type">
						<option v-for="(fieldType, key) in fieldTypes" :value="key">{{ fieldType }}</option>
					</select>
				</div>

				<button @click="onCreate" class="mdl-button mdl-js-button mdl-button--accent">
					{{ translations.create_new_field }}
				</button>

			</form>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				attribute : {
					name: '',
					type: 'taxonomy'
				},
				fieldTypes: {
					taxonomy: this.getString('text_field'),
					field   : this.getString('number_field'),
//					widgets : this.getString('widgets_field'),
//					textarea: this.getString('text_area_field')
				}
			}
		},
		computed: {
			translations() {
				return window.MyHomePanelSettings.translations;
			}
		},
		methods : {
			getString(key) {
				if (typeof window.MyHomePanelSettings.translations[key] !== 'undefined') {
					return window.MyHomePanelSettings.translations[key]
				} else {
					return ''
				}
			},
			onCreate() {
				Swal({
					title              : this.getString('saving_changes'),
					showLoaderOnConfirm: true,
					showConfirmButton  : false,
					allowEscapeKey     : false,
					showCloseButton    : false,
					showCancelButton   : false,
					allowOutsideClick  : false,
					type               : 'info'
				}).catch(Swal.noop);
				Swal.showLoading();
				this.$http.post(window.MyHomePanelSettings.requestUrl, {
					action   : 'attribute_create',
					_wpnonce : window.MyHomePanelSettings.nonce,
					attribute: this.attribute
				}, {emulateJSON: true}).then(response => {
					Swal({
						title            : this.getString('success'),
						type             : 'success',
						showConfirmButton: false,
						timer            : 1000
					}).then(function () {
					}, function () {
						window.MyHomeAdminEventBus.$emit('attributeCreated', response.body.attribute);
						$('#mh-tab-1').get(0).click();
					}).catch(Swal.noop);
				}, response => {
					Swal({
						title: this.getString('error'),
						text : this.getString('something_went_wrong'),
						type : 'error'
					}).catch(Swal.noop);
				})
			},
			reset() {
				this.attribute = {
					name: '',
					type: ''
				}
			}
		}
	}
</script>