<template>
	<div :class="fieldClass">
		<div class="mh-small-card">
			<div class="mh-small-card__title" v-if="!editLabel">
				{{ currentField.name }} <span v-if="showDisplayAfter">{{ currentField.display_after }}</span>
				<span class="mh-small-card__title__icon" v-if="showButtons">
					<button
						v-if="!editMode"
						class="mdl-button mdl-js-button"
						@click="onEdit"
					>
						<i class="material-icons">settings</i>
					</button>
					<button
						v-if="editMode"
						class="mdl-button mdl-js-button"
						@click="onEdit"
					>
						<i class="material-icons">close</i>
					</button>
				</span>
			</div>

			<div class="mh-small-card__content" v-if="editMode">
				<div>
					<label>
						{{ translations.instructions }}
						<input v-model="currentField.instructions" type="text">
					</label>
				</div>
				<div v-if="showWidth">
					<label>
						{{ translations.width }}
						<select v-model="currentField.width">
							<option value="1">1/1</option>
							<option value="2">1/2</option>
							<option value="3">1/3</option>
						</select>
					</label>
				</div>

				<div v-if="isPropertyType">
					{{ translations.property_field_type }}
					<a href="https://myhometheme.zendesk.com/hc/en-us/articles/115001342133-How-To-Make-Unnecessary-Search-Form-Filters-Disappear-After-Changing-Property-Type" target="_blank">{{ translations.link }}</a>
					<br><br>
				</div>

				<div v-if="showControlType">
					{{ translations.control_type }}
					<select v-model="currentField.control">
						<option value="text">{{ translations.text_input }}</option>
						<option value="select">{{ translations.select }}</option>
					</select>
				</div>

				<template v-if="!showTextFieldOptions">
					<div v-if="showLocationPart && currentField.type === 'text'" class="mh-admin-checkbox">
						<div>
							<input v-model="currentField.is_location_part" type="checkbox">
						</div>

						<div>
							<label>{{ translations.location_part }}</label>
						</div>
					</div>

					<template v-if="showLocationOptions">

						<div class="mh-admin-location-type">
							<label>{{ translations.location_type }}</label>
							<select v-model="currentField.location_type">
								<option value="administrative_area_level_1">administrative_area_level_1</option>
								<option value="administrative_area_level_2">administrative_area_level_2</option>
								<option value="administrative_area_level_3">administrative_area_level_3</option>
								<option value="administrative_area_level_4">administrative_area_level_4</option>
								<option value="administrative_area_level_5">administrative_area_level_5</option>
								<option value="colloquial_area">colloquial_area</option>
								<option value="country">country</option>
								<option value="establishment">establishment</option>
								<option value="finance">finance</option>
								<option value="floor">floor</option>
								<option value="food">food</option>
								<option value="general_contractor">general_contractor</option>
								<option value="geocode">geocode</option>
								<option value="health">health</option>
								<option value="intersection">intersection</option>
								<option value="locality">locality</option>
								<option value="natural_feature">natural_feature</option>
								<option value="neighborhood">neighborhood</option>
								<option value="place_of_worship">place_of_worship</option>
								<option value="political">political</option>
								<option value="point_of_interest">point_of_interest</option>
								<option value="post_box">post_box</option>
								<option value="postal_code">postal_code</option>
								<option value="postal_code_prefix">postal_code_prefix</option>
								<option value="postal_code_suffix">postal_code_suffix</option>
								<option value="postal_town">postal_town</option>
								<option value="premise">premise</option>
								<option value="room">room</option>
								<option value="route">route</option>
								<option value="street_address">street_address</option>
								<option value="street_number">street_number</option>
								<option value="sublocality">sublocality</option>
								<option value="sublocality_level_5">sublocality_level_5</option>
								<option value="sublocality_level_4">sublocality_level_4</option>
								<option value="sublocality_level_3">sublocality_level_3</option>
								<option value="sublocality_level_2">sublocality_level_2</option>
								<option value="sublocality_level_1">sublocality_level_1</option>
								<option value="subpremise">subpremise</option>
							</select>
						</div>

					</template>
				</template>

				<template v-if="showTextFieldOptions">

					<div v-if="showMultiple" class="mh-admin-checkbox">
						<div>
							<input v-model="currentField.multiple" type="checkbox">
						</div>
						<div>
							<label>{{ translations.allow_multiple_values }}</label>
						</div>
					</div>

					<div class="mh-admin-checkbox">
						<div>
							<input v-model="currentField.allow_new_values" type="checkbox">
						</div>
						<div>
							<label>{{ translations.allow_new_values }}</label>
						</div>
					</div>

					<div class="mh-admin-checkbox">
						<div>
							<input v-model="currentField.autocomplete" type="checkbox">
						</div>
						<div>
							<label>{{ translations.enable_autocomplete }}</label>
						</div>
					</div>

					<div v-if="showLocationPart" class="mh-admin-checkbox">
						<div>
							<input v-model="currentField.is_location_part" type="checkbox">
						</div>

						<div>
							<label>{{ translations.location_part }}</label>
						</div>
					</div>

					<template v-if="showLocationOptions">

						<div>
							<label>{{ translations.location_type }}</label>
							<select v-model="currentField.location_type">
								<option value="administrative_area_level_1">administrative_area_level_1</option>
								<option value="administrative_area_level_2">administrative_area_level_2</option>
								<option value="administrative_area_level_3">administrative_area_level_3</option>
								<option value="administrative_area_level_4">administrative_area_level_4</option>
								<option value="administrative_area_level_5">administrative_area_level_5</option>
								<option value="colloquial_area">colloquial_area</option>
								<option value="country">country</option>
								<option value="establishment">establishment</option>
								<option value="finance">finance</option>
								<option value="floor">floor</option>
								<option value="food">food</option>
								<option value="general_contractor">general_contractor</option>
								<option value="geocode">geocode</option>
								<option value="health">health</option>
								<option value="intersection">intersection</option>
								<option value="locality">locality</option>
								<option value="natural_feature">natural_feature</option>
								<option value="neighborhood">neighborhood</option>
								<option value="place_of_worship">place_of_worship</option>
								<option value="political">political</option>
								<option value="point_of_interest">point_of_interest</option>
								<option value="post_box">post_box</option>
								<option value="postal_code">postal_code</option>
								<option value="postal_code_prefix">postal_code_prefix</option>
								<option value="postal_code_suffix">postal_code_suffix</option>
								<option value="postal_town">postal_town</option>
								<option value="premise">premise</option>
								<option value="room">room</option>
								<option value="route">route</option>
								<option value="street_address">street_address</option>
								<option value="street_number">street_number</option>
								<option value="sublocality">sublocality</option>
								<option value="sublocality_level_5">sublocality_level_5</option>
								<option value="sublocality_level_4">sublocality_level_4</option>
								<option value="sublocality_level_3">sublocality_level_3</option>
								<option value="sublocality_level_2">sublocality_level_2</option>
								<option value="sublocality_level_1">sublocality_level_1</option>
								<option value="subpremise">subpremise</option>
							</select>
						</div>

					</template>

				</template>

				<div v-if="currentField.type !== 'featured'" class="mh-admin-checkbox">
					<div>
						<input
							v-model="currentField.required"
							type="checkbox"
							:disabled="currentField.is_breadcrumbs === 'true' || currentField.is_breadcrumbs === true"
						>
					</div>
					<div>
						<label>{{ translations.required }}</label>
					</div>

					<span v-if="currentField.is_breadcrumbs === 'true' || currentField.is_breadcrumbs === true">
						{{ translations.required_breadcrumbs }}
					</span>
				</div>

				<div v-if="showButtons">
					<button
						v-if="editMode"
						class="mdl-button mdl-js-button mdl-button--accent"
						@click="onSave"
					>
						{{ translations.save }}
					</button>
				</div>

			</div>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				editMode    : false,
				currentField: false
			}
		},
		props   : {
			field     : Object,
			isSelected: Boolean
		},
		computed: {
			isPropertyType() {
				return typeof this.currentField.base_slug !== 'undefined' && this.currentField.base_slug === 'property_type'
			},
			showMultiple() {
				return typeof this.currentField.is_breadcrumbs === 'undefined' || !(this.currentField.is_breadcrumbs === 'true' || this.currentField.is_breadcrumbs === true);
			},
			showLocationPart() {
				return this.currentField.base_slug !== 'property_type' && this.currentField.base_slug !== 'offer_type';
			},
			showDisplayAfter() {
				return typeof this.currentField.display_after !== 'undefined' && this.currentField.display_after !== '';
			},
			translations() {
				return window.MyHomePanelSettings.translations;
			},
			showWidth() {
				let type = this.field.type;
				return type !== 'location' && type !== 'description' && type !== 'video' && type !== 'virtual_tour'
					&& type !== 'plans' && type !== 'gallery' && type !== 'additional_features' && type !== 'attachments'
					&& type !== 'featured_image' && type !== 'image'
			},
			fieldClass() {
				let width = parseInt(this.currentField.width);

				if (width === 1) {
					return 'mh-panel-width-100';
				} else if (width === 2) {
					return 'mh-panel-width-50';
				} else if (width === 3) {
					return 'mh-panel-width-33';
				} else {
					return '';
				}
			},
			showButtons() {
				return this.isSelected
			},
			showTextFieldOptions() {
				return this.currentField.type === 'text' && (typeof this.currentField.control === 'undefined' || this.currentField.control === 'select')
			},
			showControlType() {
				return this.currentField.type === 'text';
			},
			showLocationOptions() {
				return typeof this.currentField.is_location_part !== 'undefined' && this.currentField.is_location_part;
			}
		},
		methods : {
			onEdit() {
				this.editMode = !this.editMode;
				if (!this.editMode) {
					this.currentField = $.extend({}, this.field);
				}
			},
			onSave() {
				this.editMode = false;
				window.MyHomeAdminEventBus.$emit('myhomeSubmitPropertyUpdateField', this.currentField)
			}
		},
		created() {
			this.currentField = $.extend({}, this.field);
			if (!this.showWidth && this.isSelected && !(this.currentField.width === 1 || this.currentField.width === '1')) {
				this.$set(this.currentField, 'width', 1);
				this.onSave();
			}

			if (this.currentField.type === 'text') {
				this.$set(this.currentField, 'control', 'select');
			}
		}
	}
</script>