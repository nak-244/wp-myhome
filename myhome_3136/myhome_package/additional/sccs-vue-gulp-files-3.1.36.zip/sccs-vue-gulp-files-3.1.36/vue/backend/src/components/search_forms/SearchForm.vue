<template>
	<div>

		<div class="mh-grid-alternative">

			<div class="mh-grid-alternative__col-1">
				<h2>{{ translations.edit_searchform }}: {{ searchForm.label }}</h2>

				<Draggable
					class="mh-small-cards-wrapper"
					v-model="currentSearchForm.selected_elements"
					@end="onUpdate"
					:options="{animation: 150, group: 'elements'}"
				>
					<SearchFormField
						v-for="element in currentSearchForm.selected_elements"
						:field="element"
						:key="element.id"
					></SearchFormField>
				</Draggable>
			</div>

			<div class="mh-grid-alternative__col-2">
				<h2>{{ translations.available_fields }}</h2>

				<Draggable
					class="mh-small-cards-wrapper"
					v-model="currentSearchForm.available_elements"
					@end="onUpdate"
					:options="{animation: 150, group: 'elements'}"
				>
					<SearchFormField
						v-for="element in currentSearchForm.available_elements"
						:field="element"
						:key="element.id"
					></SearchFormField>
				</Draggable>
			</div>

		</div>

		<vue-progress-bar></vue-progress-bar>

	</div>
</template>

<script>
	import Draggable from 'vuedraggable'
	import SearchFormField from './SearchFormField.vue'

	export default {
		data() {
			return {
				currentSearchForm: false
			}
		},
		components: {Draggable, SearchFormField},
		props     : {
			searchForm: Object
		},
		computed  : {
			translations() {
				return window.MyHomePanelSettings.translations;
			}
		},
		methods   : {
			onUpdate() {
				this.$Progress.start();
				this.$http.post(window.MyHomePanelSettings.requestUrl, {
					action     : 'search_form_update',
					search_form: this.currentSearchForm,
					_wpnonce   : window.MyHomePanelSettings.nonce
				}, {emulateJSON: true}).then(() => {
					window.MyHomeAdminEventBus.$emit('updateSearchForm', this.currentSearchForm);
					this.$Progress.finish();
				}, () => {
					this.$Progress.fail();
				});
			}
		},
		created() {
			this.currentSearchForm = $.extend({}, this.searchForm);
		}
	}
</script>