<template>

	<div class="mh-small-card mh-small-card--single-property-page">
		<div class="mh-small-card__title" v-if="!editLabel">
			{{ currentElement.label }}
			<button
				v-if="showEdit"
				class="mdl-button mdl-js-button mdl-button--edit-label"
				@click="onEditLabel">
				<i v-if="currentElement.type !== 'shortcode'" class="material-icons">edit</i>
				<i v-if="currentElement.type == 'shortcode'" class="material-icons">settings</i>
			</button>
		</div>
		<div class="mh-small-card__title" v-else>
			<div v-if="currentElement.type !== 'shortcode'">
				<input
					:id="elementKey"
					type="text"
					v-model="currentElement.label"
					@focusout="onUpdateElement"
				>
			</div>

			<div v-if="currentElement.type === 'shortcode'">
				<p>
					<input
						:id="elementKey"
						type="text"
						v-model="currentElement.label"
					>
				</p>

				<p>
					<input type="text" v-model="currentElement.shortcode" :placeholder="translations.paste_shortcode">
				</p>

				<p>
					<button class="mdl-button mdl-js-button mdl-button--accent" @click="onUpdateElement">{{ translations.save }}</button>
				</p>
			</div>
		</div>
	</div>

</template>

<script>
	export default {
		data() {
			return {
				editLabel     : false,
				currentElement: {}
			}
		},
		props   : {
			element: Object
		},
		computed: {
			translations() {
				return window.MyHomePanelSettings.translations;
			},
			showEdit() {
				let type = this.currentElement.type;
				return type !== 'gallery' && type !== 'attributes' && type !== 'info' && type !== 'map';
			},
			elementKey() {
				return 'element-' + this.currentElement.slug
			}
		},
		methods : {
			onEditLabel() {
				this.editLabel = true;
				this.$nextTick(() => {
					$('#' + this.elementKey).focus()
				})
			},
			onUpdateElement() {
				this.editLabel = false;
				window.MyHomeAdminEventBus.$emit('updateEstateElement', this.currentElement)
			}
		},
		created() {
			this.currentElement = jQuery.extend({}, this.element);
		}
	}
</script>