<template>
	<div>

		<div class="mh-grid-alternative">

			<div class="mh-grid-alternative__col-1">
				<h2>{{ translations.single_property_page }}</h2>

				<draggable
					v-model="selectedElementsList"
					class="mh-small-cards-wrapper"
					:options="{group: 'elements', animation: 150}"
					@change="save"
				>
					<EstateElement
						v-for="element in selectedElementsList"
						:key="element.slug"
						:element="element"
					>
					</EstateElement>
				</draggable>

			</div>

			<div class="mh-grid-alternative__col-2">
				<h2>{{ translations.hidden }}</h2>

				<draggable
					v-model="availableElementsList"
					class="mh-small-cards-wrapper"
					:options="{group: 'elements', animation: 150}"
					@change="save"
				>
					<EstateElement
						v-for="element in availableElementsList"
						:key="element.slug"
						:element="element"
					>
					</EstateElement>
				</draggable>

			</div>

		</div>

		<vue-progress-bar></vue-progress-bar>
	</div>
</template>
<script>
	import Draggable from 'vuedraggable'
	import EstateElement from './EstateElement.vue'

	export default {
		components: {Draggable, EstateElement},
		data() {
			return {
				selectedElementsList : [],
				availableElementsList: [],
				showLoading          : false
			}
		},
		props     : {
			selectedElements : {
				default: []
			},
			availableElements: {
				default: []
			},
			types            : {
				type: Object
			}
		},
		computed  : {
			translations() {
				return window.MyHomePanelSettings.translations;
			},
			elementsCount() {
				return this.elementsList.length
			}
		},
		methods   : {
			save() {
				if (this.showLoading) {
					Swal({
						title            : 'saving changes',
						type             : 'info',
						showConfirmButton: false,
						allowEscapeKey   : false,
						allowOutsideClick: false
					}).catch(Swal.noop);
					Swal.showLoading();
				} else {
					this.$Progress.start();
				}

				this.$http.post(window.MyHomePanelSettings.requestUrl, {
					action  : 'myhome_estate_elements_save',
					elements: this.selectedElementsList,
					_wpnonce: window.MyHomePanelSettings.nonce
				}, {emulateJSON: true}).then(() => {
					if (this.showLoading) {
						Swal({
							title            : 'Success',
							type             : 'success',
							timer            : 1000,
							showConfirmButton: false
						});
						this.showLoading = false;
					} else {
						this.$Progress.finish();
					}

				}, () => {
					if (this.showLoading) {
						Swal({
							title: 'Error',
							type : 'error'
						}).catch(Swal.noop);
						this.showLoading = false;
					} else {
						this.$Progress.fail();
					}
				})
			}
		},
		created() {
			this.selectedElementsList = this.selectedElements;
			this.availableElementsList = this.availableElements;

			window.MyHomeAdminEventBus.$on('updateEstateElement', (element) => {
				jQuery.each(this.selectedElementsList, (index, el) => {
					if (el.slug === element.slug) {
						this.$set(this.selectedElementsList, index, element);
						this.showLoading = true;
						this.save();
						return false
					}
				})
			})
		}
	}
</script>
