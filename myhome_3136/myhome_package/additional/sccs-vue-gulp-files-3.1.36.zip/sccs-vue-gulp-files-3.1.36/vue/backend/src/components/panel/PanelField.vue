<template>
	<div :class="fieldClass">
		<div class="mh-small-card">
			<div class="mh-small-card__title" v-if="!editLabel">
				{{ currentField.name }} <span v-if="showDisplayAfter">{{ currentField.display_after }}</span>
				<span class="mh-small-card__title__icon" v-if="showButtons">
					<button
						v-if="!editMode"
						class="mdl-button mdl-js-button"
						@click="onEdit"
					>
						<i class="material-icons">settings</i>
					</button>
					<button
						v-if="editMode"
						class="mdl-button mdl-js-button"
						@click="onEdit"
					>
						<i class="material-icons">close</i>
					</button>
				</span>
			</div>

			<div class="mh-small-card__content" v-if="editMode">
				<div>
					<label>
						{{ translations.instructions }}
						<input v-model="currentField.instructions" type="text">
					</label>
				</div>
				<div v-if="showWidth">
					<label>
						{{ translations.width }}
						<select v-model="currentField.width">
							<option value="1">100%</option>
							<option value="2">50%</option>
						</select>
					</label>
				</div>

				<div v-if="showControlType">
					{{ translations.control_type }}
					<select v-model="currentField.control">
						<option value="text">{{ translations.text_input }}</option>
						<option value="select">{{ translations.select }}</option>
					</select>
				</div>

				<template v-if="showTextFieldOptions">

					<div v-if="showMultiple" class="mh-admin-checkbox">
						<div>
							<input v-model="currentField.multiple" type="checkbox">
						</div>
						<div>
							<label>{{ translations.allow_multiple_values }}</label>
						</div>
					</div>

					<div class="mh-admin-checkbox">
						<div>
							<input v-model="currentField.allow_new_values" type="checkbox">
						</div>
						<div>
							<label>{{ translations.allow_new_values }}</label>
						</div>
					</div>

					<div class="mh-admin-checkbox">
						<div>
							<input v-model="currentField.autocomplete" type="checkbox">
						</div>
						<div>
							<label>{{ translations.enable_autocomplete }}</label>
						</div>
					</div>

				</template>

				<div v-if="currentField.type !== 'featured'" class="mh-admin-checkbox">
					<div>
						<input v-model="currentField.required" type="checkbox" :disabled="currentField.is_breadcrumbs">
					</div>
					<div>
						<label>{{ translations.required }}</label>
					</div>
				</div>

				<div v-if="showButtons">
					<button
						v-if="editMode"
						class="mdl-button mdl-js-button mdl-button--accent"
						@click="onSave"
					>
						{{ translations.save }}
					</button>
				</div>

			</div>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				editMode    : false,
				currentField: false
			}
		},
		props   : {
			field     : Object,
			isSelected: Boolean
		},
		computed: {
			showMultiple() {
				return typeof this.currentField.is_breadcrumbs === 'undefined' || !this.currentField.is_breadcrumbs;
			},
			showDisplayAfter() {
				return typeof this.currentField.display_after !== 'undefined' && this.currentField.display_after !== '';
			},
			translations() {
				return window.MyHomePanelSettings.translations;
			},
			showWidth() {
				let type = this.field.type;
				return type !== 'location' && type !== 'description' && type !== 'video' && type !== 'virtual_tour'
					&& type !== 'plans' && type !== 'gallery'
			},
			fieldClass() {
				return this.currentField.width === '1' || this.currentField.width === 1 || !this.isSelected ? 'mh-panel-width-100' : 'mh-panel-width-50'
			},
			showButtons() {
				return this.isSelected
			},
			showTextFieldOptions() {
				return this.currentField.type === 'text' && (typeof this.currentField.control === 'undefined' || this.currentField.control === 'select')
			},
			showControlType() {
				return this.currentField.type === 'text';
			}
		},
		methods : {
			onEdit() {
				this.editMode = !this.editMode;
				if (!this.editMode) {
					this.currentField = $.extend({}, this.field);
				}
			},
			onSave() {
				this.editMode = false;
				window.MyHomeAdminEventBus.$emit('panelUpdateField', this.currentField)
			},
			onDelete() {
				window.MyHomeAdminEventBus.$emit('panelRemoveField', this.currentField)
			}
		},
		created() {
			this.currentField = $.extend({}, this.field);
			if (!this.showWidth && this.isSelected && !(this.currentField.width === 1 || this.currentField.width === '1')) {
				this.$set(this.currentField, 'width', 1);
				this.onSave();
			}
		}
	}
</script>