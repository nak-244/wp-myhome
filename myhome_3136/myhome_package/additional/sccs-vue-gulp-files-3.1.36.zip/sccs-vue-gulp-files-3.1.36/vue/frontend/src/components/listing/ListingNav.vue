<template>

	<div class="mh-filters">

		<div class="mh-filters__left" v-if="showOrderBy">

			<div class="mh-filters__sort">
				<i class="fa fa-sort-amount-desc" aria-hidden="true"></i>
				{{ translations.sort_by }}
			</div>

			<div class="mh-filters__buttons">

				<button
					v-if="showSort('newest')"
					class="mh-filters__button"
					:class="{'mh-filters__button--active': isSortBy('newest')}"
					@click="setSortBy('newest')"
				>
					{{ translations.newest }}
				</button>

				<button
					v-if="showSort('popular')"
					class="mh-filters__button"
					:class="{'mh-filters__button--active': isSortBy('popular')}"
					@click="setSortBy('popular')"
				>
					{{ translations.popular }}
				</button>

				<button
					v-if="showSort('price_high_to_low')"
					class="mh-filters__button"
					:class="{'mh-filters__button--active': isSortBy('priceHighToLow')}"
					@click="setSortBy('priceHighToLow')"
				>
					{{ translations.price_high_to_low }}
				</button>

				<button
					v-if="showSort('price_low_to_high')"
					class="mh-filters__button"
					:class="{'mh-filters__button--active': isSortBy('priceLowToHigh')}"
					@click="setSortBy('priceLowToHigh')"
				>
					{{ translations.price_low_to_high }}
				</button>

				<button
					v-if="showSort('alphabetically')"
					class="mh-filters__button"
					:class="{'mh-filters__button--active': isSortBy('titleASC')}"
					@click="setSortBy('titleASC')"
				>
					{{ translations.alphabetically }}
				</button>

			</div>

		</div>

		<div v-if="showViewTypes" class="mh-filters__right">

			<button
				v-show="showColThree"
				@click="setView('colThree')"
				:class="{'mh-filters__right__button--active': isView('colThree')}"
			>
				<i class="fa fa-th"></i>
			</button>

			<button
				@click="setView('colTwo')"
				:class="{'mh-filters__right__button--active': isView('colTwo')}"
			>
				<i class="fa fa-th-large"></i>
			</button>

			<button
				@click="setView('row')"
				:class="{'mh-filters__right__button--active':
                    isView('row')}"
			>
				<i class="fa fa-th-list"></i>
			</button>

		</div>

	</div>

</template>

<script>
	export default {
		data() {
			return {
				view                : 'colTwo',
				sortBy              : 'newest',
				showViewTypeControls: true,
				showColThree        : true
			}
		},
		props   : {
			config: Object
		},
		computed: {
			translations() {
				return window.MyHome.translations
			},
			showViewTypes() {
				return this.config.show_view_types && this.showViewTypeControls
			},
			showOrderBy() {
				return this.config.show_sort_by;
			}
		},
		methods : {
			showSort(sortBy) {
				return this.config['show_sort_by_' + sortBy];
			},
			isSortBy(sortBy) {
				return this.sortBy === sortBy
			},
			setSortBy(sortBy) {
				this.sortBy = sortBy
			},
			isView(view) {
				return this.view === view
			},
			setView(view) {
				this.view = view;
				window.MyHomeEventBus.$emit('listingViewChanged');
			},
			checkWidth() {
				this.$nextTick(() => {
					let listingWidth = document.getElementById('myhome-listing').offsetWidth;
					if (window.innerWidth < 768) {
						this.setView('colTwo');
						this.showViewTypeControls = false;
						this.showColThree = false;
					} else if (listingWidth < 1120) {
						if (this.view === 'colThree') {
							this.setView('colTwo');
						}
						this.showColThree = false;
						this.showViewTypeControls = true;
					} else {
						this.showColThree = true;
						this.showViewTypeControls = true;
					}
				});
			},
		},
		created() {
			this.setView(this.config.listing_default_view);

			if (typeof this.config.listing_sort_by !== 'undefined' && this.config.listing_sort_by !== '') {
				this.sortBy = this.config.listing_sort_by;
			}
		},
		mounted() {
			this.checkWidth();
			jQuery(window).resize(() => {
				this.checkWidth();
			});
		},
		watch   : {
			view(view) {
				window.MyHomeEventBus.$emit('setListingView', view)
			},
			sortBy(sortBy) {
				window.MyHomeEventBus.$emit('listingSortBy', sortBy)
			}
		}
	}
</script>