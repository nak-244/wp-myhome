<template>
    <div v-if="showSaveSearch" class="mh-save-search-window-wrapper">
        <div class="mh-save-search-window">
            <div class="mh-save-search-window__inner">
                <template v-if="isSaved">
                    <div class="mh-save-search-window__label mh-save-search-window__label--success"><i
                            class="fa fa-check"></i> {{ translations.saved_success }}
                    </div>
                </template>

                <template v-if="!isSaved">
                    <div class="mh-save-search-window__label" v-if="!inProgress">{{ translations.save_search }}</div>
                    <div class="mh-save-search-window__label" v-if="inProgress"></div>
                    <form @submit.prevent="saveSearch">
                        <input v-model="search.name" type="text" :placeholder="translations.enter_s_name">
                        <span v-if="showNameEmptyError" class="mh-search-field-required">{{ translations.name_required }}</span>
                        <button
                                :disabled="isDisabled"
                                class="mdl-button--lg mdl-button--full-width mdl-button mdl-js-button mdl-button--raised mdl-button--primary"
                        >
                            {{ translations.save }}
                        </button>
                    </form>
                </template>
                <div @click="onClose" class="mh-save-search-window__exit">×</div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "SaveSearch",
        data() {
            return {
                inProgress: false,
                showSaveSearch: false,
                search: {
                    name: '',
                    url: '',
                    requestData: null
                },
                nameEmptyNotify: false,
                isSaved: false
            }
        },
        computed: {
            isDisabled() {
              return this.inProgress
            },
            showNameEmptyError() {
                return this.search.name === '' && this.nameEmptyNotify
            },
            translations() {
                return window.MyHome.translations
            }
        },
        methods: {
            onClose() {
                this.showSaveSearch = false;
                this.isSaved = false;
            },
            onSaveSearch(requestData) {
                this.$set(this, 'search', {
                    url: location.href.replace(location.hash, ''),
                    name: '',
                    data: requestData
                });

                this.$nextTick(() => {
                    this.showSaveSearch = true;
                });
            },
            saveSearch() {
                this.nameEmptyNotify = true;
                if (this.search.name === '') {
                    return false;
                }

                this.inProgress = true;
                let data = {
                    search: this.search,
                    action: 'myhome_save_search',
                };
                this.$http.post(window.MyHome.requestUrl, data, {emulateJSON: true}).then(() => {
                    this.inProgress = false;
                    this.isSaved = true;
                    this.nameEmptyNotify = false;
                    setTimeout(() => {
                        this.onClose();
                    }, 2000);
                }, () => {
                    this.inProgress = false;
                    this.onClose();
                });
            }
        },
        created() {
            window.MyHomeEventBus.$on('saveSearch', (requestData) => {
                this.onSaveSearch(requestData);
            });
        }
    }
</script>
