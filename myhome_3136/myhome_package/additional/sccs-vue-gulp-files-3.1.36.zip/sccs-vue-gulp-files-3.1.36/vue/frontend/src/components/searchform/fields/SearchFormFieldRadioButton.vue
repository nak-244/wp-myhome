<template>
	<div>

		<div :id="fieldKey" class="mh-search__panel">

			<div>
				<label class="mdl-radio mdl-js-radio mdl-js-ripple-effect">
					<input v-model="value" type="radio" class="mdl-radio__button" value="any">
					<span class="mdl-radio__label">{{ placeholder }}</span>
				</label>
			</div>

			<div v-for="option in options">
				<label class="mdl-radio mdl-js-radio mdl-js-ripple-effect">
					<input v-model="value" type="radio" class="mdl-radio__button" :value="option.slug">
					<span class="mdl-radio__label">{{ option.name }}</span>
				</label>
			</div>

		</div>

	</div>
</template>

<script>
	const DEFAULT_VALUE = 'any';

	export default {
		data() {
			return {
				value       : DEFAULT_VALUE,
				parentValues: [],
				flag        : true
			}
		},
		props   : {
			field   : Object,
			position: String,
			config  : Object
		},
		computed: {
			fieldKey() {
				return 'field-' + this.field.slug;
			},
			placeholder() {
				return window.MyHome.translations.any;
			},
			isActive() {
				return this.value !== DEFAULT_VALUE;
			},
			options() {
				if (this.field.parent_id === 0 || this.parentValues.length === 0) {
					return this.field.values['any'];
				}

				let options = {};

				if (this.field.parent_type === 'manual') {
					jQuery.each(this.field.values['any'], (index, option) => {
						if (this.parentValues.indexOf(option.options.parent_term) !== -1) {
							options[option.slug] = option;
						}
					});
				} else {
					this.parentValues.forEach((slug) => {
						this.field.values[slug].forEach((value) => {
							options[value.slug] = value;
						});
					});
				}

				return options;
			}
		},
		methods : {
			refresh() {
				this.$nextTick(() => {
					jQuery('#' + this.fieldKey + ' .mdl-js-radio').each(function (index, element) {
						componentHandler.upgradeElement(element, 'MaterialRadio');
					});
				});
			},
			setDefault() {
				if (typeof this.config.default_values[this.field.slug] !== 'undefined') {
					jQuery.each(this.config.default_values[this.field.slug].values, (index, data) => {
						this.value = data.value;
					});
				} else {
					this.value = DEFAULT_VALUE;
				}
			},
			updateParentValues(values) {
				this.parentValues.splice(0, this.parentValues.length);
				values.forEach((v) => {
					this.parentValues.push(v.value);
				});

				if (!this.options.hasOwnProperty(this.value)) {
					this.value = DEFAULT_VALUE;
					this.refresh();
				}
			}
		},
		created() {
			this.setDefault();

			if (typeof this.config.current_values[this.field.slug] !== 'undefined') {
				jQuery.each(this.config.current_values[this.field.slug].values, (index, data) => {
					this.value = data.value;
				});
			}

			if (this.field.parent_id !== 0) {
				window.MyHomeEventBus.$on('parentAttributeChange' + this.field.parent_id, (values) => {
					this.updateParentValues(values)
				});

				jQuery.each(this.config.default_values, (attributeSlug, data) => {
					if (data.id === this.field.parent_id) {
						this.updateParentValues(data.values);
					}
				});
			}

			window.MyHomeEventBus.$on('searchFormClear', () => {
				this.value = DEFAULT_VALUE;
				jQuery('#' + this.fieldKey + ' .mdl-js-radio').each(function (index, element) {
					if (typeof element.MaterialRadio !== 'undefined') {
						if (index === 0) {
							element.MaterialRadio.check();
						} else {
							element.MaterialRadio.uncheck();
						}
					}
				});
			});
			window.MyHomeEventBus.$on('removeSearchFilterValue' + this.field.slug, () => {
				this.value = DEFAULT_VALUE;
				jQuery('#' + this.fieldKey + ' .mdl-js-radio').each(function (index, element) {
					if (typeof element.MaterialRadio !== 'undefined') {
						if (index === 0) {
							element.MaterialRadio.check();
						} else {
							element.MaterialRadio.uncheck();
						}
					}
				});
			});
		},
		mounted() {
			this.refresh();
			this.flag = false;
		},
		watch   : {
			value(val) {
				if (this.flag) {
					return;
				}

				let optIndex = 0;
				jQuery.each(this.options, (optionIndex, option) => {
					if (option.slug === val) {
						optIndex = optionIndex + 1;
					}
				});

				jQuery('#' + this.fieldKey + ' .mdl-js-radio').each(function (index, element) {
					if (typeof element.MaterialRadio !== 'undefined') {
						if (index === optIndex) {
							element.MaterialRadio.check();
						} else {
							element.MaterialRadio.uncheck();
						}
					}
				});

				if (val === DEFAULT_VALUE) {
					window.MyHomeEventBus.$emit('deleteSearchFilter', this.field.slug);
					window.MyHomeEventBus.$emit('parentAttributeChange' + this.field.id, []);
					return;
				}

				let name;
				if (this.field.is_number) {
					if (isNaN(val)) {
						return;
					}
					val = Number(val);
					name = this.field.name + ' ' + this.field.compare_operator + ' ' + val;
				} else {
					let currentOption = this.options.find(function (option) {
						return option.slug === val;
					});
					name = currentOption.name;
				}

				let values = [
					{name: name, value: val}
				];
				window.MyHomeEventBus.$emit('addSearchFilter', {
					slug    : this.field.slug,
					baseSlug: this.field.base_slug,
					key     : this.field.slug,
					units   : this.field.display_after,
					compare : this.field.compare_operator,
					values  : values
				});
				window.MyHomeEventBus.$emit('parentAttributeChange' + this.field.id, values);
			},
			parentValues() {
				if (this.value !== 'any' || this.field.is_number) {
					return;
				}

				let values = [];
				jQuery.each(this.options, (index, option) => {
					values.push({name: option.name, value: option.slug});
				});

				window.MyHomeEventBus.$emit('parentAttributeChange' + this.field.id, values);
			}
		}
	}
</script>