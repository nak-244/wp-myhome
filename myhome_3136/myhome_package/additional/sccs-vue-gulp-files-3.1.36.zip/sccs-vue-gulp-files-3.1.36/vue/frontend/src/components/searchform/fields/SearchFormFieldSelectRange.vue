<template>
    <div>

        <div class="mh-search__panel">
            <div class="mh-search__2-col">

                <div
                        :id="fieldKeyFrom"
                        :class="{'mh-active-input':isFromActive}"
                        class="mh-search__2-col__left"
                >
                    <select
                            v-model="valueFrom"
                            class="selectpicker"
                            data-container="body"
                            data-dropup-auto="false"
                    >
                        <option value="any">{{ placeholderFrom }}</option>
                        <option v-for="option in options" :value="option.slug">{{ option.name }}</option>
                    </select>
                </div>

                <div
                        :id="fieldKeyTo"
                        :class="{'mh-active-input':isToActive}"
                        class="mh-search__2-col__right"
                >
                    <select
                            v-model="valueTo"
                            class="selectpicker"
                            data-container="body"
                            data-dropup-auto="false"
                    >
                        <option value="any">{{ placeholderTo }}</option>
                        <option v-for="option in options" :value="option.slug">{{ option.name }}</option>
                    </select>
                </div>

            </div>
        </div>

    </div>
</template>

<script>
    const DEFAULT_VALUE = 'any';

    export default {
        data() {
            return {
                valueFrom: DEFAULT_VALUE,
                valueTo: DEFAULT_VALUE
            }
        },
        props: {
            field: Object,
            position: String,
            config: Object,
        },
        computed: {
            fieldKeyFrom() {
                return 'field-' + this.field.slug + '-from';
            },
            fieldKeyTo() {
                return 'field-' + this.field.slug + '-to';
            },
            placeholderFrom() {
                if (this.field.placeholder_from === '') {
                    return window.MyHome.translations.from;
                } else {
                    return this.field.placeholder_from;
                }
            },
            placeholderTo() {
                if (this.field.placeholder_to === '') {
                    return window.MyHome.translations.to;
                } else {
                    return this.field.placeholder_to;
                }
            },
            isFromActive() {
                return this.valueFrom !== DEFAULT_VALUE;
            },
            isToActive() {
                return this.valueTo !== DEFAULT_VALUE;
            },
            options() {
                if (this.field.parent_id === 0) {
                    return this.field.values['any'];
                } else if (this.parentValues.length === 0) {
                    return [];
                }

                let options = {};
                this.parentValues.forEach((slug) => {
                    this.field.values[slug].forEach((value) => {
                        options[value.slug] = value;
                    });
                });
                this.refresh();

                return options
            }
        },
        methods: {
            refresh() {
                this.$nextTick(() => {
                    jQuery('#' + this.fieldKeyFrom + ' .selectpicker, #' + this.fieldKeyTo + ' .selectpicker').selectpicker('refresh');
                });
            },
            setDefault() {
                if (typeof this.config.default_values[this.field.slug + '_from'] !== 'undefined') {
                    jQuery.each(this.config.default_values[this.field.slug + '_from'].values, (index, data) => {
                        this.valueFrom = data.value;
                    });
                } else {
                    this.valueFrom = DEFAULT_VALUE
                }

                if (typeof this.config.default_values[this.field.slug + '_to'] !== 'undefined') {
                    jQuery.each(this.config.default_values[this.field.slug + '_to'].values, (index, data) => {
                        this.valueTo = data.value;
                    });
                } else {
                    this.valueTo = DEFAULT_VALUE
                }
            }
        },
        created() {
            this.setDefault();

            if (typeof this.config.current_values[this.field.slug + '_from'] !== 'undefined') {
                jQuery.each(this.config.current_values[this.field.slug + '_from'].values, (index, data) => {
                    this.valueFrom = data.value;
                });
            }

            if (typeof this.config.current_values[this.field.slug + '_to'] !== 'undefined') {
                jQuery.each(this.config.current_values[this.field.slug + '_to'].values, (index, data) => {
                    this.valueTo = data.value;
                });
            }

            window.MyHomeEventBus.$on('searchFormClear', () => {
                this.valueFrom = DEFAULT_VALUE;
                this.valueTo = DEFAULT_VALUE;
                this.refresh();
            });
            window.MyHomeEventBus.$on('removeSearchFilterValue' + this.field.slug + '_from', () => {
                this.valueFrom = DEFAULT_VALUE;
                this.refresh();
            });
            window.MyHomeEventBus.$on('removeSearchFilterValue' + this.field.slug + '_to', () => {
                this.valueTo = DEFAULT_VALUE;
                this.refresh();
            })
        },
        mounted() {
            this.refresh();
        },
        watch: {
            valueFrom(val) {
                let slug = this.field.slug + '_from';
                if (val === DEFAULT_VALUE) {
                    window.MyHomeEventBus.$emit('deleteSearchFilter', slug);
                    return;
                }

                window.MyHomeEventBus.$emit('addSearchFilter', {
                    slug: slug,
                    baseSlug: this.field.base_slug,
                    key: this.field.slug,
                    units: this.field.display_after,
                    compare: '>=',
                    values: [
                        {name: this.field.name + ' > ' + val, value: val}
                    ]
                })
            },
            valueTo(val) {
                let slug = this.field.slug + '_to';
                if (val === DEFAULT_VALUE) {
                    window.MyHomeEventBus.$emit('deleteSearchFilter', slug);
                    return
                }

                window.MyHomeEventBus.$emit('addSearchFilter', {
                    slug: slug,
                    baseSlug: this.field.base_slug,
                    key: this.field.slug,
                    units: this.field.display_after,
                    compare: '<=',
                    values: [
                        {name: this.field.name + ' < ' + val, value: val}
                    ]
                })
            }
        }
    }
</script>