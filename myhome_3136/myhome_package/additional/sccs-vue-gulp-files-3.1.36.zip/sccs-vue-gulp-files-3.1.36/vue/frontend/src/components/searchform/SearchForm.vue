<template>

	<div>
		<div v-if="searchFormTopBottom" :class="searchFormClass">

			<h1 v-if="showLabel" class="mh-search__heading-big">
				{{ config.label }}
			</h1>

			<div class="mh-search">
				<SearchFormField
					v-for="searchField in fields"
					v-show="searchField.show"
					:key="searchField.field.slug"
					:field="searchField.field"
					:config="config"
					position="top-bottom"
				>
				</SearchFormField>
			</div>

			<div v-if="showButtons" class="mh-search__buttons">
				<button
					v-if="showClearButton"
					@click="onClear"
					class="mdl-button mdl-js-button mdl-button--raised mdl-button--primary-ghost mdl-button--clear"
				>
					{{ clearLabel }}
				</button>
				<button
					v-show="showAdvancedButton"
					@click.prevent="onAdvanced"
					class="mdl-button--advanced mdl-button mdl-js-button mdl-button--raised mdl-button--primary"
				>
					{{ advancedLabel }}
				</button>
			</div>

		</div>

		<div v-if="!searchFormTopBottom">

			<SearchFormField
				v-for="searchField in fields"
				v-show="searchField.show"
				:key="searchField.field.slug"
				:field="searchField.field"
				:config="config"
				position="left-right"
			>
			</SearchFormField>

			<button
				v-if="showClearButton"
				@click="onClear"
				class="mdl-button mdl-js-button mdl-button--raised mdl-button--primary-ghost mdl-button--clear"
			>
				{{ clearLabel }}
			</button>

			<div>
				<slot></slot>
			</div>

		</div>

	</div>

</template>

<script>
	import SearchFormField from './SearchFormField.vue'

	export default {
		data() {
			return {
				showAdvanced : false,
				hiddenFields : [],
				propertyTypes: [],
				currentWidth : 0
			}
		},
		components: {SearchFormField},
		props     : {
			config: Object
		},
		computed  : {
			showLabel() {
				return this.searchFormTopBottom && typeof this.config.label !== 'undefined' && this.config.label !== '';
			},
			showButtons() {
				return this.showClearButton || this.showAdvancedButton;
			},
			fields() {
				let fields = [];
				let advanced = true;
				this.config.fields.forEach((field) => {
					if (!this.showAdvanced && fields.length === this.config.search_form_advanced_number && this.searchFormTopBottom) {
						advanced = false
					}

					let show;
					if (this.propertyTypes.length === 0 || field.base_slug === 'property_type' || field.base_slug === 'keyword') {
						show = true;
					} else {
						show = this.propertyTypes.some((propertyType) => {
							return this.config.dependencies[field.slug][propertyType];
						});
					}

					let searchField = {field: field};
					searchField.show = show && advanced && this.hiddenFields.indexOf(field.slug) === -1;
					fields.push(searchField)
				});
				return fields
			},
			searchFormClass() {
				return {
					'mh-search-horizontal': this.searchFormTopBottom
				}
			},
			advancedLabel() {
				return this.showAdvanced ? window.MyHome.translations.hide_advanced : window.MyHome.translations.advanced
			},
			clearLabel() {
				return window.MyHome.translations.clear
			},
			searchFormTopBottom() {
				if (this.currentWidth <= 1023) {
					return true;
				}
				return this.config.search_form_position === 'top' || this.config.search_form_position === 'bottom'
			},
			showClearButton() {
				return this.config.show_clear;
			},
			showAdvancedButton() {
				return this.config.show_advanced;
			}
		},
		methods   : {
			checkCurrentWidth() {
				this.$nextTick(() => {
					this.currentWidth = jQuery(window).width();
				});
			},
			onClear() {
				setTimeout(() => {
					window.MyHomeEventBus.$emit('searchFormClear');
					this.propertyTypes = [];
				}, 100);
			},
			onAdvanced() {
				this.showAdvanced = !this.showAdvanced;
			}
		},
		created() {
			window.MyHomeEventBus.$on('hideField', (field) => {
				let index = this.hiddenFields.indexOf(field.slug);
				if (index === -1) {
					this.hiddenFields.push(field.slug);
				}
			});
			window.MyHomeEventBus.$on('showField', (field) => {
				let index = this.hiddenFields.indexOf(field.slug);
				if (index !== -1) {
					this.hiddenFields.splice(index, 1);
				}
			});
			window.MyHomeEventBus.$on('propertyTypeChange', (propertyTypes) => {
				this.propertyTypes.splice(0, this.propertyTypes.length);
				propertyTypes.forEach((propertyType) => {
					this.propertyTypes.push(propertyType.value);
				});
			});
		},
		mounted() {
			this.checkCurrentWidth();

			jQuery(window).resize(() => {
				this.checkCurrentWidth();
			});
		}
	}
</script>