<template>
	<div>

		<div
			:id="fieldKey"
			:class="{'mh-active-input': isActive}"
			class="mh-search__panel"
		>

			<select
				v-model="value"
				class="selectpicker"
				data-container="body"
				data-dropup-auto="false"
			>
				<option value="any">{{ placeholder }}</option>
				<option
					v-for="option in options"
					:value="option.slug"
				>
					{{ option.name }}
				</option>
			</select>

		</div>

	</div>
</template>

<script>
	const DEFAULT_VALUE = 'any';

	export default {
		data() {
			return {
				value       : DEFAULT_VALUE,
				parentValues: []
			}
		},
		props   : {
			field   : Object,
			position: String,
			config  : Object
		},
		computed: {
			fieldKey() {
				return 'field-' + this.field.slug
			},
			placeholder() {
				return this.field.placeholder === '' ? this.field.name : this.field.placeholder
			},
			isActive() {
				return this.value !== DEFAULT_VALUE
			},
			options() {
				if (this.field.parent_id === 0 || this.parentValues.length === 0) {
					return this.field.values['any']
				}

				let options = {};
				if (this.field.parent_type === 'manual') {
					jQuery.each(this.field.values['any'], (index, option) => {
						if (this.parentValues.indexOf(option.options.parent_term) !== -1) {
							options[option.slug] = option;
						}
					});

					return options;
				}

				this.parentValues.forEach((slug) => {
					if (typeof this.field.values[slug] !== 'undefined') {
						this.field.values[slug].forEach((value) => {
							options[value.slug] = value;
						});
					}
				});
				this.refresh();

				return options
			}
		},
		methods : {
			refresh() {
				this.$nextTick(() => {
					jQuery('#' + this.fieldKey + ' .selectpicker').selectpicker('refresh');
				});
			},
			updateParentValues(values) {
				this.parentValues.splice(0, this.parentValues.length);
				values.forEach((v) => {
					this.parentValues.push(v.value);
				});

				if (!this.options.hasOwnProperty(this.value)) {
					this.value = DEFAULT_VALUE;
					this.refresh();
				}
			},
			setDefault() {
				if (typeof this.config.default_values[this.field.slug] !== 'undefined') {
					jQuery.each(this.config.default_values[this.field.slug].values, (index, data) => {
						this.value = data.value;
					});
				} else {
					this.value = DEFAULT_VALUE;
				}
			}
		},
		created() {
			this.setDefault();

			if (typeof this.config.current_values[this.field.slug] !== 'undefined') {
				if (jQuery.isArray(this.config.current_values[this.field.slug]) || typeof this.config.current_values[this.field.slug] === 'object') {
					jQuery.each(this.config.current_values[this.field.slug].values, (index, data) => {
						this.value = data.value;
					});
				} else {
					this.value = this.config.current_values[this.field.slug]
				}
			}

			window.MyHomeEventBus.$on('searchFormClear', () => {
				this.value = DEFAULT_VALUE;
				this.refresh();
			});
			window.MyHomeEventBus.$on('removeSearchFilterValue' + this.field.slug, () => {
				this.value = DEFAULT_VALUE;
				this.refresh();
			});

			if (this.field.parent_id !== 0) {
				window.MyHomeEventBus.$on('parentAttributeChange' + this.field.parent_id, (values) => {
					this.updateParentValues(values);
				});

				jQuery.each(this.config.default_values, (attributeSlug, data) => {
					if (data.id === this.field.parent_id) {
						this.updateParentValues(data.values);
					}
				});
			}
		},
		mounted() {
			this.refresh();
			this.flag = false;
		},
		watch   : {
			value(val) {
				if (val === DEFAULT_VALUE) {
					window.MyHomeEventBus.$emit('deleteSearchFilter', this.field.slug);
					window.MyHomeEventBus.$emit('parentAttributeChange' + this.field.id, []);
					return;
				}

				let name;
				if (this.field.is_number) {
					if (isNaN(val)) {
						return;
					}
					val = Number(val);
					name = this.field.name + ' ' + this.field.compare_operator + ' ' + val;
				} else {
					let currentOption;
					if (jQuery.isArray(this.options)) {
						jQuery.each(this.options, (index, option) => {
							if (option.slug === val) {
								currentOption = option;
								return false;
							}
						});
					} else {
						currentOption = this.options[val];
					}
					name = currentOption.name;
				}

				let values = [{name: name, value: val}];
				window.MyHomeEventBus.$emit('addSearchFilter', {
					slug    : this.field.slug,
					baseSlug: this.field.base_slug,
					key     : this.field.slug,
					units   : this.field.display_after,
					compare : this.field.compare_operator,
					values  : values
				});
				window.MyHomeEventBus.$emit('parentAttributeChange' + this.field.id, values);
			},
			parentValues() {
				if (this.value !== 'any') {
					return;
				}

				let values = [];
				jQuery.each(this.options, (index, option) => {
					values.push({name: option.name, value: option.slug});
				});

				window.MyHomeEventBus.$emit('parentAttributeChange' + this.field.id, values);
			}
		}
	}
</script>