<template>
	<div>
		<div v-show="showCompare" :class="compareClass" class="mh-compare">
			<div class="mh-compare__inner">
				<div class="position-relative">
					<div class="mh-compare__container">
						<div class="mh-compare__container__inner">
							<div class="mh-compare__text">
								<span class="mh-compare__container__text">
									{{ getString('compare') }}
									<strong> {{ estateIds.length }}</strong>
								</span>
								<button @click="changeView"
										class="mdl-button mdl-js-button mdl-button--primary-font">
									{{ changeViewButton }}
								</button>
								<button @click="clear" class="mdl-button mdl-js-button mdl-button--dark-font">
									{{ getString('clear') }}
								</button>
							</div>
							<div class="mh-compare__next-prev" v-if="showCarouselControls">
								<button
									class="owl-prev"
									@click="prevCarousel"
								>
									<i class="fa fa-chevron-left"></i>
								</button>
								<button
									class="owl-next"
									@click="nextCarousel"
								>
									<i class="fa fa-chevron-right"></i>
								</button>
							</div>
						</div>
					</div>
					<div v-if="showMore" class="owl-carousel owl-carousel--compare" :class="'owl-carousel--columns_'+estates.length"
						 :key="'showMore'+estates.length">
						<div v-for="estate in estates">
							<div class="mh-compare__estate-column">
								<article class="mh-compare__column">
									<div class="position-relative">
										<add-to-favorite v-if="showFavorite" :property-id="estate.id"></add-to-favorite>

										<a :href="estate.link" :title="estate.name" class="mh-thumbnail">
											<div class="mh-thumbnail__inner">
												<img
													v-if="estate.image_srcset && estate.image_srcset !== ''"
													:srcset="estate.image_srcset"
													data-sizes="auto"
													:alt="estate.name"
													class="lazyload"
												>
												<img
													v-else
													:src="estate.image"
													:alt="estate.name"
												>
											</div>
										</a>
										<button
											:data-estate-id="estate.id"
											class="mh-compare__close-button"
										></button>
									</div>
									<div class="mh-compare__column__content">
										<div class="mh-compare__column__content__top">
											<h3 class="mh-compare__title">
												<a :href="estate.link" :title="estate.name" v-html="estate.name"></a>
											</h3>
											<div v-if="estate.address" class="mh-compare__address">
												<i class="flaticon-pin"></i> {{ estate.address }}
											</div>
										</div>
										<div v-if="estate.has_price" class="mh-compare__price">
											<div
												v-for="priceObj in estate.price"
												:class="{'mh-price__range': priceObj.is_range}"
											>
												{{ priceObj.price }}
											</div>
										</div>
										<div class="mh-compare__list">
											<div v-for="(attribute, key) in estate.attributes" v-if="attribute.show && attribute.values.length > 0"
												 class="mh-compare__list__element">
												<strong v-if="!hasIcon(attribute)">{{ attribute.name }}:</strong>
												<strong v-if="hasIcon(attribute)"><i :class="attribute.icon"></i></strong>
												<span v-for="(element, key) in attribute.values">
													<span v-if="key">,</span>
														<a v-if="attribute.has_archive" :href="element.link" :title="element.name">
															{{ element.name }}
														</a>
														<span v-else>
															{{ element.name }}
														</span>
												</span>
											</div>
										</div>

										<div v-for="tag in estate.tags">
											<div class="mh-compare__heading">
												<h3 class="mh-compare__heading__text">
													{{ tag.name }}
												</h3>
											</div>
											<ul class="mh-compare__feature-list">
												<li v-for="(element, key) in tag.elements">
													<a :href="element.link" :title="element.name">
														{{ element.name }}
													</a>
												</li>
											</ul>
										</div>
										<div class="mh-compare__heading">
											<h3 class="mh-compare__heading__text">
												<a :href="estate.link" :title="estate.name">
													{{ getString('details') }}
												</a>
											</h3>
										</div>
										<div class="mh-compare__description" v-html="estate.excerpt">
										</div>
										<div v-if="showDate" class="mh-compare__date">
											{{ estate.days_ago }}
										</div>
										<div class="mh-compare__button-details">
											<a :href="estate.link" :title="estate.name"
											   class="mdl-button mdl-js-button mdl-button--raised mdl-button--primary-ghost mdl-button--half">
												{{ getString('more') }}
												<span class="mdl-button__icon-right"><i class="fa fa-angle-right"></i></span>
											</a>
										</div>
									</div>
								</article>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<script>
	import AddToFavorite from '../favorite/AddToFavorite.vue'

	export default {
		data() {
			return {
				isVisible           : false,
				estates             : [],
				estateIds           : [],
				showMore            : false,
				carousel            : false,
				isCompareOpen       : false,
				showCarouselControls: false
			}
		},
		components: {AddToFavorite},
		computed  : {
			showFavorite() {
				return window.MyHome.show_favorite;
			},
			showDate() {
				return window.MyHome.show_date === 'true'
			},
			compareClass() {
				return {
					'mh-compare--open': this.isCompareOpen
				}
			},
			changeViewButton() {
				if (this.isCompareOpen) {
					return this.getString('hide')
				} else {
					return this.getString('show')
				}
			},
			showCompare() {
				return this.estateIds.length > 0 && this.isVisible
			}
		},
		methods   : {
			hasIcon(attribute) {
				return typeof attribute.icon !== 'undefined' && attribute.icon !== '';
			},
			showAttrUnits(attribute) {
				let displayAfter = attribute.display_after;
				return !(typeof displayAfter === 'undefined' || displayAfter === '' || displayAfter === null)
			},
			getAttributeClass(attributeKey) {
				let className = 'flaticon-';
				if (attributeKey === 'property_size') {
					className += 'plan'
				} else if (attributeKey === 'lot_size') {
					className += 'tiles'
				} else if (attributeKey === 'bedrooms') {
					className += 'bed'
				} else if (attributeKey === 'bathrooms') {
					className += 'bathtub'
				} else if (attributeKey === 'year') {
					className += 'wall'
				}

				return className
			},
			getString(key) {
				if (typeof window.MyHome.translations[key] !== 'undefined') {
					return window.MyHome.translations[key]
				} else {
					return ''
				}
			},
			changeView() {
				if (this.showMore) {
					jQuery('body').removeClass('overflow-hidden');
					jQuery('html').removeClass('overflow-hidden');
					this.isCompareOpen = false;
					this.showCarouselControls = false;
					setTimeout(() => {
						this.showMore = false
					}, 700);
				} else {
					jQuery('body').addClass('overflow-hidden');
					jQuery('html').addClass('overflow-hidden');
					this.isCompareOpen = true;
					this.showMore = true;
					this.$nextTick(() => {
						this.startCarousel();
					});
				}
			},
			nextCarousel() {
				this.carousel.trigger('next.owl.carousel', [300]);
			},
			prevCarousel() {
				this.carousel.trigger('prev.owl.carousel', [300]);
			},
			startCarousel() {
				let large = 3;
				let medium = 2;
				let mousedrag = true;
				if (this.estates.length === 2) {
					large = 2;
					mousedrag = false;
				}

				if (this.estates.length === 1) {
					medium = 1;
					large = 1;
					mousedrag = false;
				}

				let carousel = jQuery('.owl-carousel--compare');
				carousel.on('initialized.owl.carousel', () => {
					let removeEstate = this.removeEstate;
					jQuery('.mh-compare__close-button').on('click', function () {
						removeEstate(jQuery(this).data('estate-id'))
					});

					this.$nextTick(function () {
						this.showCarouselControls = this.estateIds.length > jQuery('.owl-carousel--compare .owl-item.active').length;

						window.picturefill();
						let height = 0;
						let elements = jQuery('.mh-compare__column__content__top');
						jQuery.each(elements, (i, element) => {
							let elementHeight = jQuery(element).height();
							if (elementHeight > height) {
								height = elementHeight
							}
						});
						elements.css('height', height + 'px')
					})
				});

				this.carousel = carousel.owlCarousel({
					rtl       : jQuery('html').attr('dir') === 'rtl',
					loop      : true,
					dots      : false,
					autoplay  : false,
					nav       : false,
					margin    : 12,
					mouseDrag : mousedrag,
					responsive: {
						0   : {
							items: 1
						},
						768 : {
							items: medium
						},
						1000: {
							items: large
						}
					}
				})
			},
			clear() {
				jQuery('body').removeClass('overflow-hidden');
				jQuery('html').removeClass('overflow-hidden');
				this.isCompareOpen = false;
				let properties = jQuery.extend({}, this.estates);
				jQuery.each(properties, function (i, estate) {
					window.MyHomeEventBus.$emit('removeFromCompare', estate.id)
				});

				this.showMore = false;
				this.estates = [];
				this.estateIds = [];
				this.setCookie('myhome_compare_estates', '', 300);
			},
			removeEstate(estateID) {
				jQuery.each(this.estates, function (index, estate) {
					if (estate.id === estateID) {
						this.estateIds.splice(index, 1);
						this.estates.splice(index, 1);
						window.MyHomeEventBus.$emit('removeFromCompare', estate.id);
						this.$nextTick(() => {
							this.startCarousel();
						});

						this.setCookie('myhome_compare_estates', JSON.stringify(this.estateIds), 300);

						if (this.estates.length === 0) {
							this.clear()
						}

						return false
					}
				}.bind(this))
			},
			addEstate(estate) {
				jQuery('.mh-compare__counter').addClass('mh-compare__animations');
				setTimeout(() => {
					jQuery('.mh-compare__counter').removeClass('mh-compare__animations')
				}, 800);
				this.estates.push(estate);
				this.estateIds.push(estate.id);
				this.setCookie('myhome_compare_estates', JSON.stringify(this.estateIds), 300);

				if (this.showCompare && this.showMore) {
					this.$nextTick(() => {
						this.carousel();
					});
				}
			},
			getCookie(cname) {
				let name = cname + '='
				let ca = document.cookie.split(';')
				for (let i = 0; i < ca.length; i++) {
					let c = ca[i]
					while (c.charAt(0) === ' ') {
						c = c.substring(1)
					}
					if (c.indexOf(name) === 0) {
						return c.substring(name.length, c.length)
					}
				}
				return ''
			},
			setCookie(cname, cvalue, exdays) {
				const d = new Date();
				d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
				const expires = 'expires=' + d.toUTCString();
				document.cookie = cname + '=' + cvalue + ';' + expires + ';path=/'
			}
		},
		created() {
			window.MyHomeEventBus.$on('addToCompare', (estate) => {
				this.addEstate(estate);
			});
			window.MyHomeEventBus.$on('removeFromCompare', (estateId) => {
				this.removeEstate(estateId);
			});

			let estateIdsCookie = this.getCookie('myhome_compare_estates');
			if (estateIdsCookie !== '') {
				let estateIds = JSON.parse(estateIdsCookie);

				this.$http.post(window.MyHome.api, {
					estates__in: estateIds,
					limit      : -1
				}, {emulateJSON: true}).then((response) => {
					jQuery.each(response.body.results, (index, estate) => {
						this.estateIds.push(estate.id);
						this.estates.push(estate);
					});
				}, (response) => {

				});
			}

			this.isVisible = true;
			this.$nextTick(() => {
				componentHandler.upgradeDom()
			})
		},
		watch     : {
			showMore() {
				this.$nextTick(() => {
					componentHandler.upgradeDom()
				})
			}
		}
	}
</script>