<template>
	<div>

		<div :class="mapClass">
			<div id="myhome-map"></div>

			<div v-show="showControls" class="mh-map-controls mh-layout">

				<div class="mh-map-controls__inner">

					<div v-show="!streetViewMode" class="mh-map-zoom">
						<div class="mh-map-zoom__element">
							<button @click="zoomIn" :disabled="disableZoomIn">
								<i class="fa fa-plus" aria-hidden="true"></i>
							</button>
						</div>
						<div class="mh-map-zoom__element">
							<button @click="zoomOut" :disabled="disableZoomOut">
								<i class="fa fa-minus" aria-hidden="true"></i>
							</button>
						</div>
					</div>

					<div class="mh-map-panel">

						<div v-show="!streetViewMode" class="mh-map-panel__element mh-map-panel__element--reset">
							<button @click="reset">{{ getString('reset') }}</button>
						</div>

						<div v-if="showStreetView" class="mh-map-panel__element">
							<button @click="setStreetView" :class="{'mh-button--active':streetViewMode}">
								<i class="fa fa-street-view" aria-hidden="true"></i> <span>{{ getString('street_view')
								}}</span>
							</button>
						</div>

						<div class="mh-map-panel__element">
							<button @click="changeScreenMode" :class="{'mh-button--active': isFullScreen}">
								<i class="fa fa-expand" aria-hidden="true"></i> <span>{{ getString('fullscreen')
								}}</span>
							</button>
						</div>

						<div v-if="hasMarkers && !streetViewMode" class="mh-map-panel__element">
							<button @click="prevMarker">
								<i class="fa fa-angle-left" aria-hidden="true"></i> <span>{{ getString('prev') }}</span>
							</button>
						</div>

						<div v-if="hasMarkers && !streetViewMode" class="mh-map-panel__element">
							<button @click="nextMarker">
								<span>{{ getString('next') }}</span>
								<i class="fa fa-angle-right" aria-hidden="true"></i>
							</button>
						</div>

					</div>

				</div>
			</div>

			<div v-show="showReload" class="mh-loader-wrapper-map">
				<div class="mh-loader"></div>
			</div>

			<div v-if="noResults" class="mh-map-wrapper__noresults">
				<div class="mh-map-wrapper__noresults__inner">
					{{ getString('no_results') }}
					<div class="margin-top-small">
						<button class="mdl-button mdl-js-button mdl-button--raised mdl-button--white mdl-button--lg"
								@click="onClear">
							{{ getString('clear_search') }}
						</button>
					</div>
				</div>
			</div>
		</div>
	</div>

</template>

<script>
	const MIN_ZOOM = 0;
	const MAX_ZOOM = 18;

	export default {
		data() {
			return {
				map                  : false,
				currentZoom          : 0,
				markerCluster        : false,
				markers              : [],
				currentMarker        : false,
				streetViewMode       : false,
				hasMarkers           : true,
				isStreetViewAvailable: false,
				isFullScreen         : false,
				sv                   : false,
				currentInfoBox       : false,
			}
		},
		props   : {
			config    : Object,
			reloadFlag: Boolean,
			estates   : Array,
			center    : false,
			zoom      : Number
		},
		computed: {
			showStreetView() {
				return this.isStreetViewAvailable && parseInt(window.MyHome.street);
			},
			target() {
				let openNewWindow = typeof window.MyHome.property_link_new_tab !== 'undefined' && parseInt(window.MyHome.property_link_new_tab);
				return openNewWindow ? '_blank' : '_self';
			},
			noResults() {
				return this.estates.length === 0;
			},
			disableZoomOut() {
				return MIN_ZOOM === this.currentZoom;
			},
			disableZoomIn() {
				return MAX_ZOOM === this.currentZoom;
			},
			mapClass() {
				return {
					'mh-map-placeholder'          : true,
					'mh-map-placeholder--standard': this.config.map_height === 'height-standard',
					'mh-map-height-tall'          : this.config.map_height === 'height-tall',
					'mh-map-wrapper--fullscreen'  : this.isFullScreen
				}
			},
			showReload() {
				return this.reloadFlag
			},
		},
		methods : {
			getString(string) {
				return window.MyHome.translations[string]
			},
			showControls() {
				return !this.reloadFlag
			},
			reset() {
				this.isStreetViewAvailable = false;
				if (this.streetViewMode) {
					this.setStreetView()
				}

				if (this.currentInfoBox !== false) {
					this.currentInfoBox.close();
					this.currentInfoBox = false
				}

				if (typeof this.center !== 'undefined' && this.center !== false && typeof this.zoom !== 'undefined' && this.zoom !== 0) {
					this.map.setCenter(this.center);
					this.map.setZoom(this.zoom);
				} else if (typeof window.MyHome.map !== 'undefined') {
					this.map.setCenter(window.MyHome.map.position);
					this.map.setZoom(window.MyHome.map.zoom);
				} else if (this.bounds !== false) {
					this.map.fitBounds(this.bounds)
				}
			},
			changeScreenMode() {
				this.isFullScreen = !this.isFullScreen;

				if (this.isFullScreen) {
					jQuery('body').addClass('overflow-hidden');
					jQuery('html').addClass('overflow-hidden')
				} else {
					jQuery('body').removeClass('overflow-hidden');
					jQuery('html').removeClass('overflow-hidden')
				}

				this.$nextTick(function () {
					google.maps.event.trigger(this.map, 'resize')
				}.bind(this))
			},
			prevMarker() {
				if (this.streetViewMode) {
					this.setStreetView()
				}

				if (this.currentMarker === 0) {
					this.currentMarker = this.markers.length - 1
				} else {
					this.currentMarker--
				}
				this.changeMarker()
			},
			nextMarker() {
				if (this.streetViewMode) {
					this.setStreetView()
				}

				if (this.currentMarker === (this.markers.length - 1)) {
					this.currentMarker = 0
				} else {
					this.currentMarker++
				}
				this.changeMarker()
			},
			changeMarker() {
				let mapCenter = {
					lat: this.markers[this.currentMarker].position.lat(),
					lng: this.markers[this.currentMarker].position.lng()
				};
				if (this.currentZoom < 15) {
					this.map.setZoom(15);
				}
				this.map.setCenter(mapCenter);
				this.updateMapOffset();
				this.createInfoBox(this.markers[this.currentMarker]);
				this.sv.getPanorama({location: mapCenter}, function (streetViewPanoramaData, status) {
					this.isStreetViewAvailable = status === google.maps.StreetViewStatus.OK
				}.bind(this))
			},
			createInfoBox(marker) {
				let boxText = document.createElement('div');
				let estate = this.estates[marker.estateIndex];
				let innerHTML = '<div class="mh-map-infobox"><a href="' + estate.link + '" title="' + estate.name + '" target="' + this.target + '">';
				if (estate.image) {
					innerHTML += '<div class="mh-map-infobox__img-wrapper"><img src="' + estate.image + '" alt="' + estate.name + '">';
					innerHTML += '</div>'
				}
				innerHTML += '<h4 class="mh-map-infobox__name">' + estate.name + '</h4>';

				if (estate.price.length) {
					jQuery.each(estate.price, (index, priceObj) => {
						innerHTML += '<h3 class="mh-map-infobox__price">' + priceObj.price + '</h3>'
						return false;
					});
				}
				innerHTML += '</a></div>';
				boxText.innerHTML = innerHTML;

				let myOptions = {
					content               : boxText,
					disableAutoPan        : false,
					maxWidth              : 0,
					alignBottom           : true,
					pixelOffset           : new google.maps.Size(-160, -25),
					zIndex                : 6,
					boxStyle              : {
						opacity: 1,
						width  : '320px'
					},
					closeBoxURL           : window.MyHome.theme_url + '/assets/images/close.png',
					infoBoxClearance      : new google.maps.Size(1, 1),
					isHidden              : false,
					pane                  : 'floatPane',
					enableEventPropagation: false
				};

				let ib = new InfoBox(myOptions);

				if (this.currentInfoBox !== false) {
					this.currentInfoBox.close()
				}
				this.currentInfoBox = ib;
				this.currentInfoBox.open(this.map, marker)
			},
			updateMapOffset() {
				let offsetX = 0;
				let offsetY = -150;
				let scale = Math.pow(2, this.map.getZoom());

				let worldCoordinateCenter = this.map.getProjection().fromLatLngToPoint(this.markers[this.currentMarker].position);
				let pixelOffset = new google.maps.Point((offsetX / scale) || 0, (offsetY / scale) || 0);

				let worldCoordinateNewCenter = new google.maps.Point(
					worldCoordinateCenter.x - pixelOffset.x,
					worldCoordinateCenter.y + pixelOffset.y
				);
				let newCenter = this.map.getProjection().fromPointToLatLng(worldCoordinateNewCenter);
				this.map.setCenter(newCenter)
			},
			setStreetView() {
				this.streetViewMode = !this.streetViewMode;
				if (this.streetViewMode) {
					this.map.getStreetView().setOptions({
						visible          : true,
						position         : this.markers[this.currentMarker].position,
						zoomControl      : false,
						fullscreenControl: false,
						enableCloseButton: false,
						addressControl   : false
					})
				} else {
					this.map.getStreetView().setOptions({visible: false})
				}
			},
			zoomIn() {
				if (this.currentZoom < MAX_ZOOM) {
					this.currentZoom++;
					this.map.setZoom(this.currentZoom);
				}
			},
			zoomOut() {
				if (this.currentZoom > MIN_ZOOM) {
					this.currentZoom--;
					this.map.setZoom(this.currentZoom);
				}
			},
			initMap() {
				this.sv = new google.maps.StreetViewService();
				this.map = new google.maps.Map(document.getElementById('myhome-map'), {
					disableDefaultUI      : true,
					zoomControl           : false,
					scaleControl          : false,
					draggable             : true,
					disableDoubleClickZoom: false,
					scrollwheel           : false,
					gestureHandling       : 'cooperative'
				});

				if (this.config.map_style !== 'google') {
					if (this.config.map_style === 'gray') {
						let grayStyle = [{
							featureType: "administrative",
							elementType: "labels.text.fill",
							stylers    : [{color: "#444444"}]
						}, {
							featureType: "landscape",
							elementType: "all",
							stylers    : [{color: "#f2f2f2"}]
						}, {featureType: "poi", elementType: "all", stylers: [{visibility: "off"}]}, {
							featureType: "road",
							elementType: "all",
							stylers    : [{saturation: -100}, {lightness: 45}]
						}, {
							featureType: "road.highway",
							elementType: "all",
							stylers    : [{visibility: "simplified"}]
						}, {
							featureType: "road.arterial",
							elementType: "labels.icon",
							stylers    : [{visibility: "off"}]
						}, {
							featureType: "transit",
							elementType: "all",
							stylers    : [{visibility: "off"}]
						}, {
							featureType: "water",
							elementType: "all",
							stylers    : [{color: "#d7e1f2"}, {visibility: "on"}]
						}];
						this.map.mapTypes.set('styled_map', new google.maps.StyledMapType(grayStyle));
					} else {
						this.map.mapTypes.set('styled_map', new google.maps.StyledMapType(window.MyHomeMapStyle));
					}
					this.map.setMapTypeId('styled_map')

				} else {
					this.map.setMapTypeId(window.MyHome.mapType);
				}

				this.map.addListener('zoom_changed', () => {
					this.currentZoom = this.map.getZoom()
				});

				jQuery(window).trigger('mhMapInitiated', [this.map, this]);

				this.setMarkers()
			},
			setMarkers() {
				if (!window.MyHome.clustering) {
					jQuery.each(this.markers, (index, marker) => {
						marker.setMap(null);
					});
				}

				this.markers.splice(0, this.markers.length);
				if (this.estates.length === 0) {
					this.$parent.reloadFlag = false;
					return
				}

				if (window.MyHome.clustering) {
					if (this.markerCluster !== false) {
						this.markerCluster.clearMarkers();
					}
				}

				let checkMarkers = [];
				let markerIndex = 0;
				let bounds = new google.maps.LatLngBounds();
				this.markers = this.estates.map((estate, i) => {
					let currentCheck = parseFloat(estate.position.lat) + ':' + parseFloat(estate.position.lng);
					while (jQuery.inArray(currentCheck, checkMarkers) !== -1) {
						estate.position.lat = estate.position.lat + (Math.random() - .5) / 1500;
						estate.position.lng = estate.position.lng + (Math.random() - .5) / 1500;
						currentCheck = parseFloat(estate.position.lat) + ':' + parseFloat(estate.position.lng);
					}
					checkMarkers.push(currentCheck);

					let marker = new RichMarker({
						position   : new google.maps.LatLng(estate.position.lat, estate.position.lng),
						title      : estate.name,
						estateIndex: i,
						shadow     : 'none',
						index      : markerIndex,
						content    : '<div class="mh-map-pin"><i class="flaticon-pin"></i></div>'
					});
					markerIndex++;
					bounds.extend(marker.position);

					google.maps.event.addListener(marker, 'click', () => {
						this.currentMarker = marker.index;
						this.changeMarker()
					});

					if (!window.MyHome.clustering) {
						marker.setMap(this.map);
					}

					return marker
				});

				this.bounds = bounds;
				if (typeof this.center !== 'undefined' && this.center !== false && typeof this.zoom !== 'undefined' && this.zoom !== 0) {
					this.map.setCenter(this.center);
					this.map.setZoom(this.zoom);
				} else if (typeof window.MyHome.map !== 'undefined') {
					this.map.setCenter(window.MyHome.map.position);
					this.map.setZoom(window.MyHome.map.zoom);
				} else {
					this.map.fitBounds(bounds);
				}
				if (window.MyHome.clustering) {
					this.markerCluster = new MarkerClusterer(this.map, this.markers,
						{
							styles: [
								{
									textColor: 'white',
									url      : window.MyHome.theme_url + '/assets/images/map/cluster1.png',
									width    : 82,
									height   : 82
								},
								{
									textColor: 'white',
									url      : window.MyHome.theme_url + '/assets/images/map/cluster2.png',
									width    : 82,
									height   : 82
								}
							]
						}
					);
					this.markerCluster.setMaxZoom(14);
				}
				this.currentMarker = 0;

				if (this.currentInfoBox !== false) {
					this.currentInfoBox.close();
					this.currentInfoBox = false
				}

				this.$nextTick(() => {
					this.$parent.reloadFlag = false;
				})
			},
			onClear() {
				window.MyHomeEventBus.$emit('searchFormClear');
			}
		},
		created() {
			window.MyHomeEventBus.$on('mapReload', this.setMarkers)
		},
		mounted() {
			window.onload = () => {
				let timer = setInterval(() => {
					if (typeof google !== 'undefined') {
						clearInterval(timer);
						this.initMap()
					}
				}, 100)
			}
		}
	}
</script>