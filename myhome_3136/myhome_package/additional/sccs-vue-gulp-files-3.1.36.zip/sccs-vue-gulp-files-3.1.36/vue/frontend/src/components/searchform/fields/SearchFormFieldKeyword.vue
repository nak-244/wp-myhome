<template>
    <div>

        <div class="mh-search__panel" :class="fieldClass">
            <input :id="fieldKey" v-model="value" type="text" :placeholder="placeholder">
        </div>

    </div>
</template>

<script>
    const DEFAULT_VALUE = '';

    export default {
        data() {
            return {
                value: DEFAULT_VALUE,
                timer: 0,
                disableTimer: false,
                suggestSlug: '',
                suggestValue: '',
                suggestAttribute: '',
                flag: false,
            }
        },
        props: {
            field: Object,
            position: String,
            config: Object,
            isStatic: {
                type: Boolean,
                default: false
            }
        },
        computed: {
            fieldKey() {
                return 'field-' + this.field.slug
            },
            fieldClass() {
                return {
                    'mh-active-input': this.isActive,
                    'awesomplete': this.field.suggestions
                }
            },
            placeholder() {
                return this.field.placeholder === '' ? this.field.name : this.field.placeholder
            },
            isActive() {
                return this.value !== DEFAULT_VALUE
            }
        },
        methods: {
            setDefault() {
                if (typeof this.config.default_values[this.field.slug] !== 'undefined') {
                    this.value = this.config.default_values[this.field.slug]
                } else {
                    this.value = DEFAULT_VALUE
                }
            },
            newValue(val) {
                if (this.flag) {
                    return;
                }

                let timer = 600;

                if (this.disableTimer || this.isStatic) {
                    timer = 0;
                    this.disableTimer = false;
                }

                clearTimeout(this.timer);
                this.timer = setTimeout(() => {
                    if (val === DEFAULT_VALUE) {
                        window.MyHomeEventBus.$emit('deleteSearchFilter', this.field.slug);
                        return
                    }

                    let slug;
                    let baseSlug;
                    let value;
                    if (this.value === this.suggestValue) {
                        window.MyHomeEventBus.$emit('deleteSearchFilter', this.field.slug);
                        slug = this.suggestAttribute;
                        baseSlug = '';
                        value = this.suggestSlug;

                        window.MyHomeEventBus.$on('searchFormClear', () => {
                            this.value = DEFAULT_VALUE;
                            jQuery('#' + this.fieldKey).typeahead('val', this.value);
                            window.MyHomeEventBus.$emit('deleteSearchFilter', this.suggestAttribute);
                        });
                        window.MyHomeEventBus.$on('removeSearchFilterValue' + this.suggestAttribute, () => {
                            this.value = DEFAULT_VALUE;
                            jQuery('#' + this.fieldKey).typeahead('val', this.value);
                            window.MyHomeEventBus.$emit('deleteSearchFilter', this.suggestAttribute);
                        });
                    } else {
                        if (this.suggestAttribute !== '') {
                            window.MyHomeEventBus.$emit('deleteSearchFilter', this.suggestAttribute);
                            this.suggestAttribute = '';
                            this.suggestSlug = '';
                            this.suggestValue = '';
                        }
                        slug = this.field.slug;
                        baseSlug = this.field.base_slug;
                        value = this.value;
                    }

                    this.$nextTick(() => {
                        window.MyHomeEventBus.$emit('addSearchFilter', {
                            slug: slug,
                            baseSlug: baseSlug,
                            key: slug,
                            units: this.field.display_after,
                            compare: this.field.compare_operator,
                            values: [
                                {name: val, value: value}
                            ]
                        })
                    });
                }, timer);
            }
        },
        created() {
            this.setDefault();

            if (typeof this.config.current_values[this.field.slug] !== 'undefined') {
                jQuery.each(this.config.current_values[this.field.slug].values, (index, data) => {
                    this.value = data.value;
                });
            }

            window.MyHomeEventBus.$on('searchFormClear', this.setDefault);
            window.MyHomeEventBus.$on('removeSearchFilterValue' + this.field.slug, () => {
                this.value = DEFAULT_VALUE
            });
        },
        mounted() {
            if (this.field.suggestions) {
                let dataSets = [];
                let minNumber = 2;

                if (typeof this.field.local.data_set !== 'undefined' && this.field.local.data_set.length) {
                    minNumber = 0;
                    let localSource = new Bloodhound({
                        datumTokenizer: Bloodhound.tokenizers.obj.whitespace('name'),
                        queryTokenizer: Bloodhound.tokenizers.whitespace,
                        local: this.field.local.data_set
                    });

                    dataSets.push({
                        name: this.field.local.slug,
                        displayKey: 'name',
                        source: (q, sync) => {
                            if (q === '') {
                                sync(localSource.index.all());
                            } else {
                                localSource.search(q, sync);
                            }
                        },
                        templates: {
                            header: '<h3>' + this.field.local.label + '</h3>'
                        }
                    });
                }

                jQuery.each(this.field.data_sets, (index, dataSet) => {
                    dataSets.push({
                        name: dataSet.slug,
                        displayKey: 'name',
                        source: new Bloodhound({
                            datumTokenizer: Bloodhound.tokenizers.obj.whitespace('name'),
                            queryTokenizer: Bloodhound.tokenizers.whitespace,
                            remote: {
                                url: this.field.api_endpoint + '-attributes?slug=' + dataSet.slug + '&query=%QUERY',
                                wildcard: '%QUERY'
                            }
                        }),
                        templates: {
                            header: '<h3>' + dataSet.label + '</h3>'
                        }
                    });
                });

                let input = jQuery('#' + this.fieldKey);
                input.typeahead({
                    hint: false,
                    highlight: true,
                    minLength: minNumber,
                    display: 'name'
                }, dataSets);

                input.bind('typeahead:select', (ev, suggestion) => {
                    this.disableTimer = true;
                    if (this.field.redirect && this.field.redirect_new_tab) {
                        window.open(suggestion.link);
                    } else if (this.field.redirect) {
                        window.location.href = suggestion.link;
                    } else {
                        this.suggestSlug = suggestion.slug;
                        this.suggestValue = suggestion.name;
                        this.suggestAttribute = suggestion.attribute_slug;
                        this.value = suggestion.name;
                        this.newValue(this.value)
                    }
                });
            }
        },
        watch: {
            value(val) {
                this.newValue(val)
            }
        }
    }
</script>