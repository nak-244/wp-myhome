<template>
	<div>

		<div :id="fieldKey" class="mh-search__panel mh-search__panel--checkbox">
			<div>

                <span v-for="option in options" :key="checkboxKey(option.slug)"
					  class="mh-search__panel__checkbox">

                    <label :id="checkboxKey(option.slug)" class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect">
                        <input
							type="checkbox"
							class="mdl-checkbox__input"
							:value="option.slug"
							@click="modifySelected(option.slug)"
							:checked="isSelected(option.slug)"
						>
                        <span class="mdl-checkbox__label">{{ option.name }}</span>
                    </label>

                </span>

			</div>
		</div>

	</div>
</template>

<script>
	export default {
		data() {
			return {
				selected      : [],
				parentValues  : [],
				currentOptions: {}
			}
		},
		props   : {
			field   : Object,
			position: String,
			config  : Object
		},
		computed: {
			options() {
				let options = [];
				for (let key in this.currentOptions) {
					options.push(this.currentOptions[key])
				}

				if (typeof this.field.checkbox_move === 'undefined' || this.field.checkbox_move) {
					options.sort((a, b) => {
						if (this.selected.indexOf(a.slug) !== -1 && this.selected.indexOf(b.slug) === -1) {
							return -1
						}
						if (this.selected.indexOf(b.slug) !== -1 && this.selected.indexOf(a.slug) === -1) {
							return 1
						}

						let aName = a.name.toLowerCase();
						let bName = b.name.toLowerCase();
						if (aName > bName) {
							return 1
						}
						if (bName > aName) {
							return -1
						}
						return 0
					});
				}
				return options
			},
			fieldKey() {
				return 'field-' + this.field.slug
			}
		},
		methods : {
			checkboxKey(slug) {
				return this.fieldKey + '_' + slug
			},
			setCurrentOptions() {
				for (let key in this.currentOptions) {
					this.$delete(this.currentOptions, this.currentOptions[key].slug)
				}

				if (this.field.parent_id === 0) {
					this.field.values['any'].forEach((value) => {
						this.$set(this.currentOptions, value.slug, value);
					});
					this.refresh();
					return
				}

				if (this.parentValues.length === 0) {
					this.field.values['any'].forEach((value) => {
						this.$set(this.currentOptions, value.slug, value);
					});
					this.refresh();
					return
				}

				if (this.field.parent_type === 'manual') {
					let parents = [];
					jQuery.each(this.parentValues, (index, value) => {
						parents.push(value.value);
					});

					jQuery.each(this.field.values['any'], (index, option) => {
						if (parents.indexOf(option.options.parent_term) !== -1) {
							this.$set(this.currentOptions, option.slug, option);
						}
					});
					this.refresh();
					return
				}

				let options = {};
				jQuery.each(this.parentValues, (index, v) => {
					if (typeof this.field.values[v.value] !== 'undefined') {
						this.field.values[v.value].forEach((value) => {
							options[value.slug] = value;
						});
					}
				});

				for (let key in this.currentOptions) {
					if (!options.hasOwnProperty(this.currentOptions[key].slug)) {
						this.$delete(this.currentOptions, this.currentOptions[key].slug)
					}
				}

				for (let key in options) {
					let value = options[key];
					if (!this.currentOptions.hasOwnProperty(value.slug)) {
						this.$set(this.currentOptions, value.slug, value)
					}
				}

				this.selected = this.selected.filter((value) => {
					return this.currentOptions.hasOwnProperty(value)
				});

				this.refresh()
			},
			isSelected(slug) {
				return this.selected.indexOf(slug) !== -1
			},
			modifySelected(slug) {
				if (this.isSelected(slug)) {
					let index = this.selected.indexOf(slug);
					this.selected.splice(index, 1)
				} else {
					this.selected.push(slug)
				}
			},
			removeValue(value) {
				let index = this.selected.indexOf(value);
				if (index === -1) {
					return
				}
				let id = this.checkboxKey(value);
				if (jQuery('#' + id).length) {
					document.getElementById(this.checkboxKey(value)).MaterialCheckbox.uncheck();
				}
				this.selected.splice(index, 1)
			},
			refresh() {
				this.$nextTick(() => {
					componentHandler.upgradeElements(document.getElementById(this.fieldKey))
				})
			},
			updateParentValues(values) {
				this.parentValues.splice(0, this.parentValues.length);
				this.parentValues = values;
				this.setCurrentOptions()
			},
			reset() {
				this.selected.splice(0, this.selected.length);
				let elements = document.getElementById(this.fieldKey).getElementsByClassName('mdl-js-checkbox');
				Array.prototype.forEach.call(elements, (element) => {
					if (typeof element.MaterialCheckbox !== 'undefined') {
						element.MaterialCheckbox.uncheck();
					}
				});
				this.refresh();
			}
		},
		created() {
			this.setCurrentOptions();

			if (typeof this.config.default_values[this.field.slug] !== 'undefined') {
				this.selected.splice(0, this.selected.length);
				jQuery.each(this.config.default_values[this.field.slug].values, (index, data) => {
					this.selected.push(data.value);
				});
			}

			if (typeof this.config.current_values[this.field.slug] !== 'undefined') {
				this.selected.splice(0, this.selected.length);
				jQuery.each(this.config.current_values[this.field.slug].values, (index, data) => {
					this.selected.push(data.value);
				});
			}

			window.MyHomeEventBus.$on('searchFormClear', this.reset);
			window.MyHomeEventBus.$on('removeSearchFilterValue' + this.field.slug, (value) => {
				this.removeValue(value);
			});
			if (this.field.parent_id !== 0) {
				window.MyHomeEventBus.$on('parentAttributeChange' + this.field.parent_id, (values) => {
					this.updateParentValues(values)
				});

				jQuery.each(this.config.default_values, (attributeSlug, data) => {
					if (data.id === this.field.parent_id) {
						this.updateParentValues(data.values);
					}
				});
			}
		},
		mounted() {
			this.refresh()
		},
		watch   : {
			selected(val) {
				if (val.length === 0) {
					window.MyHomeEventBus.$emit('deleteSearchFilter', this.field.slug);
					window.MyHomeEventBus.$emit('parentAttributeChange' + this.field.id, []);
					return
				}

				let values = [];
				this.selected.forEach((value) => {
					values.push({name: this.currentOptions[value].name, value: value})
				});

				window.MyHomeEventBus.$emit('addSearchFilter', {
					slug    : this.field.slug,
					baseSlug: this.field.base_slug,
					key     : this.field.slug,
					units   : this.field.display_after,
					compare : this.field.compare_operator,
					values  : values
				});
				window.MyHomeEventBus.$emit('parentAttributeChange' + this.field.id, values);
			},
			parentValues() {
				if (this.selected.length > 0) {
					return;
				}

				let values = [];

				jQuery.each(this.options, (index, option) => {
					values.push({name: option.name, value: option.slug});
				});

				window.MyHomeEventBus.$emit('parentAttributeChange' + this.field.id, values)
			}
		}
	}
</script>