<template>
	<div>
		<template v-if="hasPanelUrl">
			<div v-if="!isLogged" @click.prevent="onNotLoggedClick" class="mh-top-bar-user-panel__user-info">
				<a :href="panelUrl" class="mh-top-bar-user-panel__main-link">
					{{ label }}
				</a>
			</div>

			<div v-if="isLogged" class="mh-top-bar-user-panel__user-info">
				<a :href="panelUrl" class="mh-top-bar-user-panel__main-link">
					<img v-if="hasImage" :src="user.image_url"> {{ user.display_name }}
				</a>
				<ul class="mh-top-bar-user-panel__user-menu">
					<li v-if="showSubmitProperty">
						<a :href="panelUrl + '#/submit-property'" @click="onSubmitProperty">
							<i aria-hidden="true" class="fa fa-plus-circle"></i> {{ getString('submit_property') }}
						</a>
					</li>
					<li v-if="showSubmitProperty">
						<a :href="panelUrl + '#/dashboard/properties'" @click="onChangeContext('/dashboard/properties')">
							<i aria-hidden="true" class="fa fa-home"></i> {{ getString('my_properties') }}
						</a>
					</li>
					<li v-if="showAgents">
						<a :href="panelUrl + '#/dashboard/agents'" @click="onChangeContext('/dashboard/agents')">
							<i aria-hidden="true" class="fa fa-users"></i> {{ getString('agents') }}
						</a>
					</li>
					<li v-if="showFavorite">
						<a :href="panelUrl + '#/dashboard/favorite'" @click="onChangeContext('/dashboard/favorite')">
							<i aria-hidden="true" class="fa fa-heart"></i> {{ getString('favorite') }}
						</a>
					</li>
					<li v-if="showSaveSearch">
						<a :href="panelUrl + '#/dashboard/searches'" @click="onChangeContext('/dashboard/searches')">
							<i aria-hidden="true" class="fa fa-search"></i> {{ getString('saved_searches') }}
						</a>
					</li>
					<li>
						<a :href="panelUrl + '#/dashboard/profile'" @click="onChangeContext('/dashboard/profile')">
							<i aria-hidden="true" class="fa fa-pencil"></i> {{ getString('edit_profile') }}
						</a>
					</li>
					<li v-if="showMyProfile">
						<a :href="user.link">
							<i aria-hidden="true" class="fa fa-user"></i> {{ getString('view_profile') }}
						</a>
					</li>
					<li>
						<button @click="onLogout">
							<i aria-hidden="true" class="fa fa-sign-out"></i> {{ getString('log_out') }}
						</button>
					</li>
				</ul>
			</div>
		</template>

		<template v-else>
			<a href="#" target="_blank">
				{{ getString('configure_panel') }}
			</a>
		</template>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				user: false
			}
		},
		computed: {
			showSaveSearch() {
				return window.MyHome.show_save_search;
			},
			showFavorite() {
				return window.MyHome.show_favorite;
			},
			showSubmitProperty() {
				return jQuery.inArray('buyer', this.user.roles) === -1 || window.MyHome.buyer_can_submit_property;
			},
			showMyProfile() {
				return jQuery.inArray('buyer', this.user.roles) === -1 || window.MyHome.buyer_can_submit_property;
			},
			showAgents() {
				return jQuery.inArray('agency', this.user.roles) !== -1;
			},
			showSuperAgents() {
				return jQuery.inArray('super_agent', this.user.roles) !== -1 || jQuery.inArray('administrator', this.user.roles) !== -1;
			},
			label() {
				if (typeof window.MyHome.user_bar_label !== 'undefined' && window.MyHome.user_bar_label !== '') {
					return window.MyHome.user_bar_label;
				} else if (this.isRegistrationOpen) {
					return this.getString('login') + ' / ' + this.getString('register');
				} else {
					return this.getString('login')
				}
			},
			isRegistrationOpen() {
				return window.MyHome.is_register_open;
			},
			hasImage() {
				return this.user !== false && typeof this.user.image_url !== 'undefined' && this.user.image_url !== '';
			},
			hasPanelUrl() {
				return typeof window.MyHome.panelUrl !== 'undefined' && window.MyHome.panelUrl !== '';
			},
			panelUrl() {
				return window.MyHome.panelUrl;
			},
			isLogged() {
				return this.user !== false;
			}
		},
		methods : {
			onNotLoggedClick() {
				if (window.MyHome.notLoggedPopup) {
					window.MyHomeEventBus.$emit('myhomeAccount')
				} else {
					window.location.href = this.panelUrl
				}
			},
			onSubmitProperty() {
				if (typeof window.MyHomePanelEventBus !== 'undefined') {
					window.MyHomePanelEventBus.$emit('onSubmitProperty');
				}
			},
			getString(key) {
				return window.MyHome.translations[key];
			},
			onLogout() {
				if (typeof window.MyHomePanelEventBus !== 'undefined') {
					window.MyHomePanelEventBus.$emit('onUserLogout');
					return;
				}

				this.$http.post(window.MyHome.requestUrl, {action: 'myhome_user_panel_logout'}, {emulateJSON: true}).then((response) => {
					window.location.reload();
				}, () => {

				});
			},
			onChangeContext(context) {
				if (typeof window.MyHomePanelEventBus !== 'undefined') {
					window.MyHomePanelEventBus.$emit('changeContext', context);
				}
			}
		},
		created() {
			if (typeof window.MyHome.user !== 'undefined') {
				this.user = window.MyHome.user;
			}

			if (typeof window.MyHomeEventBus !== 'undefined') {
				window.MyHomeEventBus.$on('updateAgent', (agent) => {
					this.user = agent;
				});
			}
		},
		mounted() {
			if (typeof window.MyHomeEventBus !== 'undefined') {
				window.MyHomeEventBus.$on('panelInitiated', () => {
					window.MyHomePanelEventBus.$on('userLogin', (user) => {
						this.user = user;
					});

					window.MyHomePanelEventBus.$on('userLogout', () => {
						this.user = false;
					});
				});
			}
		}
	}
</script>