<template>
	<div v-show="show" class="mh-search__element" :class="[fieldClasses, fieldTypeClass]">

		<h5 class="mh-search__label">
			{{ field.name }}
			<span v-if="showUnits">({{ field.display_after }})</span>

			<SearchFormFieldCurrency
				v-if="showCurrencies"
				:currencies="config.currencies"
				:default-currency="config.current_currency"
				:position="position"
			></SearchFormFieldCurrency>
		</h5>

		<SearchFormFieldText
			v-if="isText"
			v-model="show"
			:field="field"
			:config="config"
			:position="position"
		>
		</SearchFormFieldText>

		<SearchFormFieldTextRange
			v-if="isTextRange"
			v-model="show"
			:field="field"
			:config="config"
			:position="position"
            :is-static="isStatic"
        >
		</SearchFormFieldTextRange>

		<SearchFormFieldKeyword
			v-if="isKeyword"
			v-model="show"
			:field="field"
			:config="config"
			:position="position"
			:is-static="isStatic"
		>
		</SearchFormFieldKeyword>

		<SearchFormFieldID
			v-if="isID"
			v-model="show"
			:field="field"
			:config="config"
			:position="position"
		>
		</SearchFormFieldID>

		<SearchFormFieldSelect
			v-if="isSelect"
			v-model="show"
			:field="field"
			:config="config"
			:position="position"
		>
		</SearchFormFieldSelect>

		<SearchFormFieldSelectRange
			v-if="isSelectRange"
			v-model="show"
			:field="field"
			:config="config"
			:position="position"
		>
		</SearchFormFieldSelectRange>

		<SearchFormFieldSelectMultiple
			v-if="isSelectMultiple"
			v-model="show"
			:field="field"
			:config="config"
			:position="position"
		>
		</SearchFormFieldSelectMultiple>

		<SearchFormFieldRadioButton
			v-if="isRadioButton"
			v-model="show"
			:field="field"
			:config="config"
			:position="position"
		>
		</SearchFormFieldRadioButton>

		<SearchFormFieldCheckbox
			v-if="isCheckbox"
			v-model="show"
			:field="field"
			:config="config"
			:position="position"
		>
		</SearchFormFieldCheckbox>

	</div>

</template>

<script>
	import SearchFormFieldText from './fields/SearchFormFieldText.vue'
	import SearchFormFieldTextRange from './fields/SearchFormFieldTextRange.vue'
	import SearchFormFieldSelect from './fields/SearchFormFieldSelect.vue'
	import SearchFormFieldSelectRange from './fields/SearchFormFieldSelectRange.vue'
	import SearchFormFieldSelectMultiple from './fields/SearchFormFieldSelectMultiple.vue'
	import SearchFormFieldKeyword from './fields/SearchFormFieldKeyword.vue'
	import SearchFormFieldCheckbox from './fields/SearchFormFieldCheckbox.vue'
	import SearchFormFieldRadioButton from './fields/SearchFormFieldRadioButton.vue'
	import SearchFormFieldCurrency from './fields/SearchFormFieldCurrency.vue'
	import SearchFormFieldID from './fields/SearchFormFieldID.vue'

	export default {
		components: {
			SearchFormFieldText, SearchFormFieldTextRange, SearchFormFieldSelect, SearchFormFieldSelectRange,
			SearchFormFieldSelectMultiple, SearchFormFieldKeyword, SearchFormFieldCheckbox, SearchFormFieldRadioButton,
			SearchFormFieldCurrency, SearchFormFieldID
		},
		data() {
			return {
				show: true
			}
		},
		props     : {
			field   : Object,
			position: String,
			config  : Object,
			isStatic: {
				type   : Boolean,
				default: false
			}
		},
		computed  : {
			fieldTypeClass() {
				return 'mh-search__panel--' + this.field.type
			},
			fieldClasses() {
				let classes = {
					'mh-attribute'                 : true,
					'mh-search__element--fullwidth': this.field.full_width,
				};

				classes['mh-search__panel--' + this.field.type] = true;
				classes['mh-attribute__' + this.field.slug] = true;

				return classes;
			},
			showCurrencies() {
				return this.field.base_slug === 'price' && this.config.currencies.length > 1;
			},
			showUnits() {
				return this.field.display_after !== '' && !this.showCurrencies;
			},
			isText() {
				return this.field.type === 'text'
			},
			isTextRange() {
				return this.field.type === 'text_range'
			},
			isKeyword() {
				return this.field.type === 'keyword'
			},
			isID() {
				return this.field.type === 'id'
			},
			isSelect() {
				return this.field.type === 'select' || (this.field.type === 'radio_button' && this.position === 'top-bottom')
			},
			isSelectRange() {
				return this.field.type === 'select_range'
			},
			isSelectMultiple() {
				return this.field.type === 'select_multiple'
			},
			isRadioButton() {
				return this.field.type === 'radio_button' && this.position === 'left-right'
			},
			isCheckbox() {
				return this.field.type === 'checkbox'
			}
		}
	}
</script>