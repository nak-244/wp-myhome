<template>
	<div class="mh-search-form-basic" @keydown.enter="onSearch">
		<div class="mh-search-form-basic__inner">
			<div class="mh-search-form-basic__buttons">

				<div class="mh-search-form-basic__buttons__single" v-for="value in primaryFieldValues">
					<button
						@click="setPrimaryValue(value.slug)"
						:class="{'is-active': primaryValue === value.slug}"
					>
						{{ value.name }}
					</button>
				</div>
			</div>

			<div id="myhome-search-form-submit" class="mh-search-form-basic__form">

				<SearchFormField
					v-for="field in fields"
					:config="config"
					:field="field"
					:key="field.slug"
					position="top-bottom"
					:is-static="true"
				>
				</SearchFormField>

				<div class="mh-search__element">
					<button
						class="mdl-button mdl-button--lg mdl-js-button mdl-button--raised mdl-button--primary"
						@click="onSearch"
					>
						{{ search_label }}
					</button>
				</div>
			</div>

		</div>
	</div>
</template>

<script>
	import SearchFormField from './SearchFormField.vue'

	export default {
		data() {
			return {
				config      : {
					default_values: {},
					current_values: {},
					currencies    : []
				},
				primaryValue: '',
				filters     : {},
				url         : '',
				search_label: ''
			}
		},
		name      : "search-form-basic",
		components: {SearchFormField},
		props     : {
			configKey: String
		},
		computed  : {
			fields() {
				return window[this.configKey].fields;
			},
			primaryField() {
				return window[this.configKey].primary_selector;
			},
			hasPrimaryField() {
				return this.primaryField !== '';
			},
			primaryFieldValues() {
				return this.primaryField.values.any;
			}
		},
		methods   : {
			onSearch() {
			    setTimeout(() => {
                    let params = {};
                    jQuery.each(this.filters, (key, filter) => {
                        if (filter.values.length === 1) {
                            params[filter.slug] = filter.values[0].value
                        } else {
                            params[filter.slug] = [];
                            filter.values.forEach((v) => {
                                params[filter.slug].push(v.value)
                            })
                        }
                    });

                    let url = this.url;
                    if (Object.keys(params).length > 0) {
                        url += '?' + jQuery.param(params);
                    }

                    console.log('test')

                    window.location.href = url;
                }, 700)
			},
			setPrimaryValue(value) {
				this.primaryValue = value;
				let values = [{name: value, value: value}];
				window.MyHomeEventBus.$emit('addSearchFilter', {
					slug    : this.primaryField.slug,
					baseSlug: this.primaryField.base_slug,
					key     : this.primaryField.slug,
					units   : this.primaryField.display_after,
					compare : this.primaryField.compare_operator,
					values  : values
				});
				window.MyHomeEventBus.$emit('parentAttributeChange' + this.primaryField.id, values);
			}
		},
		created() {
			this.setPrimaryValue(window[this.configKey].primary_selector_value);
			this.url = window[this.configKey].listing_page_url;
			this.search_label = window[this.configKey].search_label;
		},
		mounted() {
			window.MyHomeEventBus.$on('addSearchFilter', (filter) => {
				this.$set(this.filters, filter.slug, filter);
				if (filter.baseSlug === 'property_type') {
					window.MyHomeEventBus.$emit('propertyTypeChange', filter.values);
				}
			});
			window.MyHomeEventBus.$on('deleteSearchFilter', (filterSlug) => {
				if (typeof this.filters[filterSlug] !== 'undefined' && this.filters[filterSlug].baseSlug === 'property_type') {
					window.MyHomeEventBus.$emit('propertyTypeChange', []);
				}
				this.$delete(this.filters, filterSlug);
			});
		}
	}
</script>
