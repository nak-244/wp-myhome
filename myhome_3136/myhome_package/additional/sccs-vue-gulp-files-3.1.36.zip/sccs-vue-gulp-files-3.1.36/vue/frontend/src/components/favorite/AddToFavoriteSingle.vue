<template>
	<button @click="onClick" class="mh-estate__add-to__favorite" :class="{'mh-estate__add-to__favorite--active': isFavorite}">
		<i class="fa" :class="{'fa-heart': isFavorite, 'fa-heart-o': !isFavorite}"></i>
		<span v-if="isFavorite">{{ translations.added_to_favorite }}</span>
		<span v-if="!isFavorite">{{ translations.add_to_favorite }}</span>
	</button>
</template>

<script>
	export default {
		name   : "AddToFavoriteSingle",
		data() {
			return {
				isFavorite: false
			}
		},
		props  : {
			propertyId: false
		},
        computed: {
            translations() {
                return window.MyHome.translations
            },
        },
		methods: {
			onClick() {
				if (typeof window.MyHome.user !== 'undefined') {
					this.isFavorite = !this.isFavorite;
					let data = {
						propertyID: this.propertyId,
						isFavorite: this.isFavorite,
						action    : 'myhome_add_to_favorite'
					};
					this.$http.post(window.MyHome.requestUrl, data, {emulateJSON: true}).then((response) => {
					}, (response) => {
					});
				} else {
					this.onNotLogged();
				}
			},
			onNotLogged() {
				window.MyHomeEventBus.$emit('myhomeAccount');
			}
		},
		created() {
			if (typeof window.MyHome.favorite !== 'undefined') {
				jQuery.each(window.MyHome.favorite, (index, value) => {
					if (value === this.propertyId) {
						this.isFavorite = true;
						return false;
					}
				});
			}
		}
	}
</script>
