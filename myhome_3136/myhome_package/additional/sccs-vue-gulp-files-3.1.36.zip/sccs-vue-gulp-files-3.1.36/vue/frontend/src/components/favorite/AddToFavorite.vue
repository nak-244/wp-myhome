<template>
	<div class="mh-favorite-card">
		<div v-if="showRemoved" class="mh-favorite-card__added-removed">
			<span>{{ translations.removed }}</span>
		</div>
		<div v-if="showAdded" class="mh-favorite-card__added-removed">
			<span>{{ translations.added }}</span>
		</div>
		<div :class="{'is-favorite': isFavorite}" @click="onClick">
			<button v-if="!isFavorite"><i class="fa fa-heart-o"></i></button>
			<button v-if="isFavorite"><i class="fa fa-heart"></i></button>
		</div>
	</div>
</template>

<script>
	export default {
		name   : "AddToFavorite",
		data() {
			return {
				showAdded  : false,
				showRemoved: false,
				isFavorite : false,
				isDisabled : false
			}
		},
		props  : {
			propertyId: false
		},
        computed: {
            translations() {
                return window.MyHome.translations
            },
        },
		methods: {
			onClick() {
				if (this.isDisabled) {
					return;
				}
				this.isDisabled = true;

				if (typeof window.MyHome.user !== 'undefined') {
					this.isFavorite = !this.isFavorite;

					if (this.isFavorite) {
						this.showAdded = true;
						setTimeout(() => {
							this.showAdded = false;
							this.isDisabled = false;
						}, 1500);
					} else {
						this.showRemoved = true;
						setTimeout(() => {
							this.showRemoved = false;
							this.isDisabled = false;
						}, 1500);
					}

					let data = {
						propertyID: this.propertyId,
						isFavorite: this.isFavorite,
						action    : 'myhome_add_to_favorite'
					};
					this.$http.post(window.MyHome.requestUrl, data, {emulateJSON: true}).then((response) => {
					}, (response) => {
					});
				} else {
					this.isDisabled = false;
					this.onNotLogged();
				}
			},
			onNotLogged() {
				window.MyHomeEventBus.$emit('myhomeAccount');
			}
		},
		created() {
			if (typeof window.MyHome.favorite !== 'undefined') {
				jQuery.each(window.MyHome.favorite, (index, value) => {
					if (value === this.propertyId) {
						this.isFavorite = true;
						return false;
					}
				});
			}
		}
	}
</script>
