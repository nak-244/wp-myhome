<template>
    <div v-show="showAccount" :class="{'mh-account_overlay': showAccount}">
        <div id="myhome-account__inner">
            <div class="mh-popup-login">
                <div class="mh-popup-login__inner">
                    <button @click="onClose" class="mh-popup-login__exit">×</button>

                    <div v-if="loginSuccess" class="mh-popup-login__inner__body mh-popup-login__inner__body--hello">
                        <div class="mh-popup-login__info">
                            <p>{{ translations.hello }} {{ userName }} <span>{{ translations.exclamation_mark }}</span>
                            </p>
                        </div>
                    </div>

                    <div v-if="registerSuccess"
                         class="mh-popup-login__inner__body mh-popup-login__inner__body--thank-you-registration">
                        <div class="mh-popup-login__info">{{ translations.reg_completed }}<br><br>
                            {{ translations.hello }} <strong>{{ userName }}</strong>
                        </div>
                    </div>

                    <div v-if="registerLinkSuccess"
                         class="mh-popup-login__inner__body mh-popup-login__inner__body--thank-you-registration-email">
                        <div class="mh-popup-login__info">
                            <p>{{ translations.reg_completed }}</p>
                            <p>{{ translations.check_email }}</p>
                            <button class="mdl-button mdl-button--primary mdl-button--lg mdl-js-button mdl-button--raised"
                                    @click="onClose">{{ translations.ok }}
                            </button>
                        </div>
                    </div>

                    <div v-if="resetPassword" class="mh-popup-login__inner__body mh-popup-login__inner__body--reset">
                        <div class="mh-popup-login__reset-password-heading">{{ translations.reset_password }}</div>
                        <div class="mh-popup-login__reset-info">{{ translations.enter_email }}</div>
                        <input class="mh-popup-login__reset-input" type="text" v-model="resetEmail">
                        <div class="mh-popup-login__reset-error" v-if="this.resetEmail === '' && checkResetEmail">{{
                            translations.email_required }}
                        </div>
                        <div class="mh-popup-login__back-wrapper">
                            <button @click="resetPassword = false"
                                    class="mdl-button login-pop-up-reset__back mdl-button--lg mdl-js-button mdl-button--raised">
                                <i class="fa fa-chevron-left"></i> {{ translations.back }}
                            </button>
                        </div>
                        <div class="mh-popup-login__reset-wrapper">
                            <button @click="onResetPassword"
                                    class="mdl-button login-pop-up-reset__reset mdl-button--lg mdl-js-button mdl-button--raised mdl-button--primary">
                                {{ translations.reset }}
                            </button>
                        </div>
                    </div>

                    <div v-if="resetPasswordSuccess" class="mh-popup-window-new mh-popup-window-new--error">
                        <p class="mh-popup-login__no-registered-user">{{ translations.no_user }}</p>
                        <button class="mdl-button mdl-button--primary mdl-button--lg mdl-js-button mdl-button--raised"
                                @click="resetPasswordSuccess = false">{{ translations.ok }}
                        </button>
                    </div>

                    <template v-if="showMain">

                        <div v-if="registerOpen" class="tabs">
                            <button
                                    class="mh-popup-login__tab-button"
                                    :class="{'active': currentTab === 'login'}"
                                    @click.stop="setTab('login')"
                            >
                                {{ translations.login }}
                            </button>
                            <button
                                    class="mh-popup-login__tab-button"
                                    :class="{'active': currentTab === 'register'}"
                                    @click.stop="setTab('register')"
                            >
                                {{ translations.register }}
                            </button>
                        </div>

                        <div class="mh-popup-login__inner__body mh-popup-login__inner__body--in-progress">
                            <div class="mh-popup-top-msg-error" v-if="message !== ''" v-html="message"></div>

                            <div v-if="inProgress" class="mh-popup-top-info">
                                <i class="fa fa-spinner fa-spin"></i>
                            </div>

                            <div v-show="currentTab === 'login'">
                                <form @submit.prevent="onLogin">

                                    <div v-if="!registerOpen" class="mh-popup-login__login-solo-heading">{{
                                        translations.login }}
                                    </div>

                                    <div class="mh-popup-login-fields">
                                        <div class="mh-popup-login-field mh-popup-login-field--login">
                                            <div class="mh-register-login-field__label">{{ translations.login }}</div>
                                            <input type="text" v-model="user.email">
                                        </div>
                                        <div class="mh-popup-login-field mh-popup-login-field--password">
                                            <div class="mh-register-login-field__label">{{ translations.password }}
                                            </div>
                                            <input type="password" v-model="user.password">
                                        </div>
                                    </div>

                                    <div v-if="captchaEnabled" class="mh-popup-login-fields-login-captcha">
                                        <div id="mh-login-captcha"></div>
                                    </div>

                                    <button
                                            type="submit"
                                            class="mdl-button mdl-button--popup-login mdl-button--lg mdl-js-button mdl-button--raised mdl-button--primary"
                                            :disabled="isDisabled"
                                    >
                                        {{ translations.login }}
                                    </button>

                                </form>
                            </div>

                            <div v-if="registerOpen" v-show="currentTab === 'register'">
                                <form @submit.prevent="onRegister">
                                    <div class="mh-register-fields">
                                        <div class="mh-register-field mh-register-field--login">
                                            <div class="mh-register-login-field__label">{{ translations.login }}</div>
                                            <input type="text" v-model="register.login">
                                        </div>
                                        <div class="mh-register-field mh-register-field--email">
                                            <div class="mh-register-login-field__label">{{ translations.email }}</div>
                                            <input type="text" v-model="register.email">
                                        </div>
                                        <div class="mh-register-field mh-register-field--password">
                                            <div class="mh-register-login-field__label">{{ translations.password }}
                                            </div>
                                            <input type="password" v-model="register.password">
                                        </div>
                                        <div class="mh-register-field mh-register-field--repassword">
                                            <div class="mh-register-login-field__label">{{ translations.repeat_password
                                                }}
                                            </div>
                                            <input type="password" v-model="register.password2">
                                        </div>
                                        <div
                                                v-if="showPasswordMismatch"
                                                class="mh-register-field__password-mismatch"
                                        >
                                            {{ translations.password_mismatch }}

                                        </div>

                                        <div v-for="field in userFields">
                                            <div class="mh-register-field mh-register-field--email">
                                                <div class="mh-register-login-field__label">{{ field.name }}</div>
                                                <input type="text" v-model="register[field.slug]">
                                            </div>
                                        </div>

                                        <div class="mh-register-field mh-register-field--account-type">
                                            <template v-if="showAccountTypes">
                                                <div class="mh-register-login-field__label">{{ translations.account_type
                                                    }}
                                                </div>
                                                <select
                                                        v-if="showAccountTypes"
                                                        id="myhome-account_types"
                                                        v-model="register.account_type"
                                                        data-container="body"
                                                        data-dropup-auto="false"
                                                        class="mh-popup-login__select-role selectpicker"
                                                >
                                                    <option
                                                            v-for="type in accountTypes"
                                                            :value="type.value"
                                                    >
                                                        {{ type.name }}
                                                    </option>
                                                </select>
                                            </template>
                                        </div>
                                        <div v-if="showRules" class="mh-register-field mh-register-field__terms">
                                            <div class="mh-register-field__terms__box">
                                                <input type="checkbox" v-model="acceptRules">
                                            </div>
                                            <div class="mh-register-field__terms__text">
                                                <span>{{ translations.accept }}</span>
                                                <a :href="rulesLink" target="_blank">{{ translations.terms_of_service
                                                    }}</a>
                                            </div>
                                        </div>
                                    </div>

                                    <div v-if="captchaEnabled" class="mh-popup-login-fields-register-captcha">
                                        <div id="mh-register-captcha"></div>
                                    </div>

                                    <button
                                            class="mdl-button mdl-button--popup-register mdl-button--lg mdl-js-button mdl-button--raised mdl-button--primary"
                                            type="submit"
                                            :disabled="isDisabled"
                                    >
                                        {{ translations.register }}
                                    </button>
                                </form>
                            </div>

                            <div class="mh-panel-login-social-buttons" v-if="socialLogin.length">
                                <div class="mh-panel-login-social-buttons__heading">{{ translations.connect_with }}
                                </div>
                                <div class="mh-panel-login-social-buttons__all-buttons">
                                    <div v-for="social in socialLogin">
                                        <button
                                                type="button"
                                                class="btn btn--depressed"
                                                :data-name="social.key"
                                                @click="onSocialLogin(social)"
                                        >
                                            <div class="btn__content">
                                                {{ social.name }}
                                            </div>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <button v-if="currentTab !== 'register'" class="login-pop-up-reset-button"
                                    @click.stop="resetPassword = true">
                                {{ translations.retrieve_password }}
                            </button>

                        </div>
                    </template>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "Account",
        data() {
            return {
                acceptRules: false,
                showAccount: false,
                currentTab: 'login',
                user: {
                    email: '',
                    password: '',
                },
                register: {
                    login: '',
                    email: '',
                    password: '',
                    password2: '',
                    account_type: ''
                },
                message: '',
                inProgress: false,
                captchaId: {
                    login: false,
                    register: false
                },
                registerOpen: true,
                loginSuccess: false,
                registerSuccess: false,
                registerLinkSuccess: false,
                resetPasswordSuccess: false,
                resetPassword: false,
                userName: '',
                resetEmail: '',
                checkResetEmail: false,
                captcha: {
                    login: false,
                    register: false
                },
                captchaChecked: false
            }
        },
        computed: {
            userFields() {
                return window.MyHome.user_fields
            },
            showRules() {
                return window.MyHome.show_rules
            },
            rulesLink() {
                return window.MyHome.rules_link
            },
            isDisabled() {
                if (this.currentTab === 'register' && this.showRules && !this.acceptRules) {
                    return true;
                }

                if (!this.captchaEnabled) {
                    return false;
                }

                return !this.captchaChecked;
            },
            showPasswordMismatch() {
                return this.register.password !== this.register.password2 && this.register.password2 !== ''
                    && this.register.password !== ''
            },
            showMain() {
                return !this.loginSuccess && !this.registerSuccess && !this.registerLinkSuccess && !this.resetPassword
                    && !this.resetPasswordSuccess
            },
            showAccountTypes() {
                return parseInt(window.MyHome.user_select_type);
            },
            accountTypes() {
                let types = [];

                jQuery.each(window.MyHome.account_types, (value, name) => {
                    types.push({name: name, value: value});
                });

                return types;
            },
            resetPasswordLink() {
                return window.MyHome.panelUrl + '#password-reset-new';
            },
            captchaEnabled() {
                return window.MyHome.captcha_enabled;
            },
            socialLogin() {
                if (typeof window.MyHome.social_login === 'undefined') {
                    return [];
                }

                return window.MyHome.social_login;
            },
            translations() {
                return window.MyHome.translations;
            }
        },
        methods: {
            onResetPassword() {
                this.checkResetEmail = true;
                if (this.resetEmail === '') {
                    return false;
                }

                let data = {
                    action: 'myhome_user_panel_reset_password',
                    email: this.resetEmail,
                    _wpnonce: window.MyHome.nonce
                };
                this.$http.post(window.MyHome.requestUrl, data, {emulateJSON: true}).then(() => {
                    this.resetPassword = false;
                    this.resetPasswordSuccess = true;
                    this.resetEmail = '';
                    this.checkResetEmail = false;
                }, () => {
                    this.resetEmail = '';
                    this.checkResetEmail = false;
                });
            },
            initiateRegister() {
                this.$nextTick(() => {
                    jQuery('#myhome-account_types').selectpicker('refresh');
                });
            },
            onClose() {
                this.userName = '';
                this.loginSuccess = false;
                this.registerLinkSuccess = false;
                this.registerSuccess = false;
                this.showAccount = false;
                this.resetPasswordSuccess = false;
                this.resetPassword = false;
            },
            setTab(tab) {
                this.currentTab = tab;

                if (this.currentTab === 'register' && this.showAccountTypes) {
                    this.initiateRegister();
                }

                if (this.captchaEnabled) {
                    if (this.captchaId[this.currentTab] !== false) {
                        grecaptcha.reset(this.captchaId[this.currentTab]);
                    }

                    this.$nextTick(() => {
                        this.initiateCaptcha();
                    });
                }
            },
            onLogin() {
                this.message = '';

                if (this.user.email === '' && this.user.password === '') {
                    return false;
                }
                this.inProgress = true;

                let data = {
                    credentials: {
                        login: this.user.email,
                        password: this.user.password
                    },
                    action: 'myhome_user_panel_login',
                    rememberMe: true,
                    _wpnonce: window.MyHome.nonce
                };

                if (this.captchaEnabled) {
                    data['captcha'] = grecaptcha.getResponse(this.captchaId[this.currentTab]);
                }

                this.$http.post(window.MyHome.requestUrl, data, {emulateJSON: true}).then((response) => {
                    if (this.captchaEnabled) {
                        grecaptcha.reset(this.captchaId[this.currentTab]);
                    }

                    this.inProgress = false;
                    let data = response.body;
                    if (data.success === true) {
                        window.MyHome.user = data.user;
                        window.MyHomeEventBus.$emit('updateAgent', data.user);
                        this.userName = data.user.display_name;
                        this.loginSuccess = true;
                        setTimeout(() => {
                            this.onClose();
                            this.loginSuccess = false;
                            this.$nextTick(() => {
                                window.location.reload();
                            });
                        }, 2000);
                        this.$set(this, 'user', {email: '', password: ''});
                    } else {
                        if (typeof data.text !== 'undefined') {
                            this.message = data.text;
                        }
                    }
                }, (response) => {
                    if (this.captchaEnabled) {
                        grecaptcha.reset(this.captchaId[this.currentTab]);
                    }

                    this.inProgress = false;
                });
            },
            onRegister() {
                this.message = '';

                if (this.register.login === '' || this.register.password === '' || this.register.email === ''
                    || this.register.password !== this.register.password2) {
                    return false;
                }

                this.inProgress = true;
                let data = {
                    user: this.register,
                    _wpnonce: window.MyHome.nonce,
                    action: 'myhome_user_panel_register'
                };

                if (this.captchaEnabled) {
                    data['captcha'] = grecaptcha.getResponse(this.captchaId[this.currentTab]);
                }

                this.$http.post(window.MyHome.requestUrl, data, {emulateJSON: true}).then((response) => {
                    if (this.captchaEnabled) {
                        grecaptcha.reset(this.captchaId[this.currentTab]);
                    }

                    this.inProgress = false;
                    let data = response.body;
                    if (data.success === true) {
                        if (data.user !== false) {
                            window.location.reload();
                            this.userName = data.user.display_name;
                            this.registerSuccess = true;
                            window.MyHomeEventBus.$emit('updateAgent', data.user);
                            setTimeout(() => {
                                this.onClose();
                            }, 2000);
                        } else {
                            this.registerLinkSuccess = true;
                        }
                        this.$set(this, 'register', {login: '', email: '', password: '', password2: ''});
                    } else {
                        if (typeof data.message !== 'undefined') {
                            this.message = data.message;
                        }
                    }
                }, (response) => {
                    if (this.captchaEnabled) {
                        grecaptcha.reset(this.captchaId[this.currentTab]);
                    }
                    this.inProgress = false;
                });
            },
            onSocialLogin(social) {
                window.location.href = social.login_link;
            },
            initiateCaptcha() {
                if (this.captcha[this.currentTab]) {
                    return;
                }

                let timer = setInterval(() => {
                    if (window.grecaptcha) {
                        clearInterval(timer);
                        this.captchaChecked = false;
                        this.captchaId[this.currentTab] = grecaptcha.render(document.getElementById('mh-' + this.currentTab + '-captcha'), {
                            'sitekey': window.MyHome.captcha_site_key,
                            'callback': () => {
                                this.captchaChecked = true;
                            },
                            'expired-callback': () => {
                                this.captchaChecked = false;
                            }
                        });
                        this.captcha[this.currentTab] = true;
                    }
                }, 100);
            },
        },
        created() {
            this.registerOpen = window.MyHome.account_register_open;
            if (this.registerOpen) {
                this.currentTab = window.MyHome.account_active_tab;
            }

            this.$set(this.register, 'account_type', window.MyHome.account_type);
        },
        mounted() {
            window.MyHomeEventBus.$on('myhomeAccount', () => {
                this.showAccount = true;
                if (this.captchaEnabled) {
                    this.$nextTick(() => {
                        this.initiateCaptcha();
                    });
                }
            });
        }
    }
</script>