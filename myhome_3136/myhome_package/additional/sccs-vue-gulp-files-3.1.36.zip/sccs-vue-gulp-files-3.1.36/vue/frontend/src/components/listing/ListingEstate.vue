<template>
	<div :class="estateClass">

		<article
			:id="'mh-property__' + estate.id"
			v-if="isRow"
			class="mh-estate-horizontal"
			:class="articleClass"
		>

			<div class="mh-estate-horizontal__inner">

				<div class="mh-estate-horizontal__left">

					<add-to-favorite v-if="showFavorite" :property-id="estate.id"></add-to-favorite>

					<ListingEstateGallery
						v-if="hasGallery"
						:estate="estate"
					></ListingEstateGallery>

					<template v-if="!hasGallery">
						<a
							:href="estate.link"
							:title="estate.name"
							class="mh-thumbnail"
							:target="target"
						>
							<div class="mh-thumbnail__inner" :class="{'mh-thumbnail__inner--no_image': !hasImage && estate.image_srcset}">
								<img
									v-if="hasImage && estate.image_srcset"
									:data-srcset="estate.image_srcset"
									data-parent-fit="contain"
									data-sizes="auto"
									:alt="estate.name"
									:class="imgClass"
								>
								<img
									v-if="hasImage && !estate.image_srcset"
									:src="estate.image"
									:alt="estate.name"
								>
								<div v-if="!hasImage" class="mh-thumbnail__inner--no_image__icon">
									<svg enable-background="new 0 0 512 512" version="1.1" viewBox="0 0 512 512" xml:space="preserve" xmlns="http://www.w3.org/2000/svg">
										<path d="m343.87 49.688h-172.4l-35.645 75.612h-18.626v-37.806h-91.815v37.806h-25.384v335.39h24.304v-16.203h-8.101v-223.59h124.76v-16.203h-124.76v-63.19h129.9l35.646-75.612h151.65l21.912 48.694 14.776-6.649-26.21-58.247zm-242.88 75.612h-59.41v-21.603h59.409v21.603z" />
										<polygon points="408.3 125.3 408.3 141.5 495.8 141.5 495.8 204.69 372.66 204.69 372.66 220.9 495.8 220.9 495.8 444.49 97.215 444.49 97.215 460.69 512 460.69 512 125.3" />
										<rect x="186.33" y="125.3" width="139.34" height="16.203" />
										<rect x="204.15" y="83.173" width="103.7" height="16.203" />
										<rect x="434.23" y="285.7" width="16.203" height="16.203" />
										<rect x="401.82" y="285.7" width="16.203" height="16.203" />
										<rect x="63.19" y="285.7" width="16.203" height="16.203" />
										<rect x="95.595" y="285.7" width="14.582" height="16.203" />
										<path d="m338.07 206.17l-10.482 12.355c24.868 21.098 39.13 51.884 39.13 84.464 0 61.05-49.667 110.72-110.72 110.72-33.823 0-65.355-15.168-86.51-41.612l-12.653 10.12c24.248 30.311 60.39 47.695 99.163 47.695 69.984 0 126.92-56.936 126.92-126.92 0-37.347-16.347-72.637-44.851-96.819z" />
										<path d="m256 176.07c-69.984 0-126.92 56.936-126.92 126.92 0 15.401 2.73 30.453 8.113 44.743l15.162-5.713c-4.693-12.455-7.073-25.587-7.073-39.03 0-61.05 49.667-110.72 110.72-110.72 9.203 0 18.349 1.13 27.184 3.359l3.964-15.711c-10.129-2.555-20.609-3.851-31.147-3.851z" />
										<path d="m220.16 221.4c-5.7 2.507-11.17 5.642-16.259 9.314l9.483 13.137c4.165-3.006 8.64-5.57 13.3-7.621l-6.524-14.83z" />
										<path d="m190.38 242.73c-14.605 15.884-22.94 36.492-23.471 58.032l16.198 0.398c0.434-17.614 7.253-34.47 19.2-47.464l-11.927-10.966z" />
										<path d="m313.22 234.67l-10.41 12.415c16.586 13.906 26.099 34.281 26.099 55.902 0 40.204-32.708 72.911-72.911 72.911-23.123 0-45.11-11.144-58.815-29.81l-13.06 9.589c16.746 22.809 43.615 36.424 71.875 36.424 49.138 0 89.114-39.977 89.114-89.114 0-26.425-11.624-51.326-31.892-68.317z" />
										<path d="m237.65 215.78l3.323 15.859c4.933-1.035 9.989-1.559 15.028-1.559v-16.203c-6.153 0-12.327 0.641-18.351 1.903z" />
										<path d="m291.1 302.99c0 19.358-15.749 35.105-35.105 35.105v16.203c28.291 0 51.308-23.017 51.308-51.308h-16.203z" />
										<rect transform="matrix(.7071 -.7071 .7071 .7071 -106.04 256)" x="-95.348" y="247.9" width="702.69" height="16.202" />
									</svg>
								</div>
								<div v-if="hasOfferType" class="mh-caption">
									<div
										v-for="offerType in estate.offer_type"
										v-if="offerType.options.has_label"
										class="mh-caption__inner"
										:class="'mh-label__' + offerType.slug"
										:style="{background: offerType.options.bg_color, color: offerType.options.color}"
									>
										{{ offerType.name }}
									</div>
								</div>
							</div>

							<div v-if="estate.is_featured" class="mh-thumbnail__featured">
								<i class="fa fa-star"></i>
							</div>
						</a>
					</template>

				</div>

				<div class="mh-estate-horizontal__right">

					<div class="mh-estate-horizontal__right__content">

						<h3 class="mh-estate-horizontal__heading">
							<a
								:href="estate.link"
								:title="estate.name"
								:target="target"
							>
								<span v-html="estate.name"></span>
							</a>
						</h3>

						<address v-if="hasAddress" class="mh-estate-horizontal__subheading">
							<i class="flaticon-pin"></i> {{ estate.address }}
						</address>

						<div class="mh-estate-horizontal__primary">
							<div
								v-if="estate.has_price"
								v-for="priceObj in estate.price"
								:class="{'mh-price__range': priceObj.is_range}"
							>
								{{ priceObj.price }}
							</div>

							<div v-if="!estate.has_price">
								{{ contactForPriceLabel }}
							</div>
						</div>

						<div class="mh-estate-horizontal__excerpt">
							{{ estate.excerpt }}
						</div>

						<div>
							<div
								v-for="attribute in estate.attributes"
								v-if="attribute.card_show && attribute.values.length > 0"
								class="mh-estate-vertical__more-info"
                                :class="'mh-attribute__' + attribute.slug"
							>
								<strong v-if="!hasIcon(attribute)">{{ attribute.name }}:</strong>
								<strong v-if="hasIcon(attribute)"><i :class="attribute.icon"></i></strong>
								<template v-for="(value, index) in attribute.values">
									<template v-if="index">,</template>
									{{ value.name }}
								</template>
							</div>
						</div>

						<div class="mh-estate-horizontal__bottom">

							<div class="mh-estate-horizontal__bottom__inner">
								<div v-if="showDate" class="mh-estate-horizontal__date">
									{{ estate.days_ago }}
								</div>

								<div class="mh-estate-horizontal__buttons">
									<div v-if="showCompare" class="mh-estate-horizontal__buttons__single">
										<CompareButton :estate="estate"></CompareButton>
									</div>

									<div class="mh-estate-horizontal__buttons__single">
										<a
											class="mdl-button mdl-js-button mdl-button--raised mdl-button--primary-ghost"
											:href="estate.link"
											:title="estate.name"
											:target="target"
										>
											{{ detailsLabel }}
											<span class="mdl-button__icon-right">
                                                <i class="fa fa-angle-right"></i>
                                            </span>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</article>

		<article
			v-if="!isRow"
			:id="'mh-property__' + estate.id"
			class="mh-estate-vertical"
			:class="estate.attribute_classes"
		>
			<add-to-favorite v-if="showFavorite" :property-id="estate.id"></add-to-favorite>

			<ListingEstateGallery
				v-if="hasGallery"
				:estate="estate"
			></ListingEstateGallery>

			<template v-if="!hasGallery">
				<a
					:href="estate.link"
					:title="estate.name"
					class="mh-thumbnail"
					:target="target"
				>
					<div class="mh-thumbnail__inner" :class="{'mh-thumbnail__inner--no_image': !hasImage}">
						<img
							v-if="hasImage && estate.image_srcset"
							:data-srcset="estate.image_srcset"
							data-parent-fit="contain"
							data-sizes="auto"
							:alt="estate.name"
							class="lazyload"
						>
						<img
							v-if="hasImage && !estate.image_srcset"
							:src="estate.image"
							:alt="estate.name"
						>
						<div v-if="!hasImage" class="mh-thumbnail__inner--no_image__icon">
							<svg enable-background="new 0 0 512 512" version="1.1" viewBox="0 0 512 512" xml:space="preserve" xmlns="http://www.w3.org/2000/svg">
										<path d="m343.87 49.688h-172.4l-35.645 75.612h-18.626v-37.806h-91.815v37.806h-25.384v335.39h24.304v-16.203h-8.101v-223.59h124.76v-16.203h-124.76v-63.19h129.9l35.646-75.612h151.65l21.912 48.694 14.776-6.649-26.21-58.247zm-242.88 75.612h-59.41v-21.603h59.409v21.603z" />
								<polygon points="408.3 125.3 408.3 141.5 495.8 141.5 495.8 204.69 372.66 204.69 372.66 220.9 495.8 220.9 495.8 444.49 97.215 444.49 97.215 460.69 512 460.69 512 125.3" />
								<rect x="186.33" y="125.3" width="139.34" height="16.203" />
								<rect x="204.15" y="83.173" width="103.7" height="16.203" />
								<rect x="434.23" y="285.7" width="16.203" height="16.203" />
								<rect x="401.82" y="285.7" width="16.203" height="16.203" />
								<rect x="63.19" y="285.7" width="16.203" height="16.203" />
								<rect x="95.595" y="285.7" width="14.582" height="16.203" />
								<path d="m338.07 206.17l-10.482 12.355c24.868 21.098 39.13 51.884 39.13 84.464 0 61.05-49.667 110.72-110.72 110.72-33.823 0-65.355-15.168-86.51-41.612l-12.653 10.12c24.248 30.311 60.39 47.695 99.163 47.695 69.984 0 126.92-56.936 126.92-126.92 0-37.347-16.347-72.637-44.851-96.819z" />
								<path d="m256 176.07c-69.984 0-126.92 56.936-126.92 126.92 0 15.401 2.73 30.453 8.113 44.743l15.162-5.713c-4.693-12.455-7.073-25.587-7.073-39.03 0-61.05 49.667-110.72 110.72-110.72 9.203 0 18.349 1.13 27.184 3.359l3.964-15.711c-10.129-2.555-20.609-3.851-31.147-3.851z" />
								<path d="m220.16 221.4c-5.7 2.507-11.17 5.642-16.259 9.314l9.483 13.137c4.165-3.006 8.64-5.57 13.3-7.621l-6.524-14.83z" />
								<path d="m190.38 242.73c-14.605 15.884-22.94 36.492-23.471 58.032l16.198 0.398c0.434-17.614 7.253-34.47 19.2-47.464l-11.927-10.966z" />
								<path d="m313.22 234.67l-10.41 12.415c16.586 13.906 26.099 34.281 26.099 55.902 0 40.204-32.708 72.911-72.911 72.911-23.123 0-45.11-11.144-58.815-29.81l-13.06 9.589c16.746 22.809 43.615 36.424 71.875 36.424 49.138 0 89.114-39.977 89.114-89.114 0-26.425-11.624-51.326-31.892-68.317z" />
								<path d="m237.65 215.78l3.323 15.859c4.933-1.035 9.989-1.559 15.028-1.559v-16.203c-6.153 0-12.327 0.641-18.351 1.903z" />
								<path d="m291.1 302.99c0 19.358-15.749 35.105-35.105 35.105v16.203c28.291 0 51.308-23.017 51.308-51.308h-16.203z" />
								<rect transform="matrix(.7071 -.7071 .7071 .7071 -106.04 256)" x="-95.348" y="247.9" width="702.69" height="16.202" />
									</svg>
						</div>
						<div v-if="hasOfferType" class="mh-caption">
							<div
								v-for="offerType in estate.offer_type"
								v-if="offerType.options.has_label"
								class="mh-caption__inner"
								:class="'mh-label__' + offerType.slug"
								:style="{background: offerType.options.bg_color, color: offerType.options.color}"
							>
								{{ offerType.name }}
							</div>
						</div>
					</div>

					<div v-if="hasExcerpt" class="mh-estate-vertical__text">
						<div class="mh-estate-vertical__text__inner">
							{{ estate.excerpt }}
						</div>
					</div>

					<div v-if="estate.is_featured" class="mh-thumbnail__featured">
						<i class="fa fa-star"></i>
					</div>

				</a>
			</template>

			<div class="mh-estate-vertical__content">

				<h3 class="mh-estate-vertical__heading">
					<a
						:href="estate.link"
						:title="estate.name"
						:target="target"
					>
						<span v-html="estate.name"></span>
					</a>
				</h3>

				<address v-if="hasAddress" class="mh-estate-vertical__subheading">
					<i class="flaticon-pin"></i> {{ estate.address }}
				</address>

				<div class="mh-estate-vertical__primary">
					<div
						v-if="estate.has_price"
						v-for="priceObj in estate.price"
						:class="{'mh-price__range': priceObj.is_range}"
					>
						{{ priceObj.price }}
					</div>

					<div v-if="!estate.has_price">
						{{ contactForPriceLabel }}
					</div>
				</div>

				<div>
					<span
						v-for="attribute in estate.attributes"
						v-if="attribute.card_show && attribute.values.length > 0"
						class="mh-estate-vertical__more-info"
                        :class="'mh-attribute__' + attribute.slug"
					>
						<strong v-if="!hasIcon(attribute)">{{ attribute.name }}:</strong>
						<strong v-if="hasIcon(attribute)"><i :class="attribute.icon"></i></strong>
						<template v-for="(value, index) in attribute.values"><span v-if="index">, </span>{{ value.name }}</template>
					</span>
				</div>

			</div>

			<div class="mh-estate-vertical__bottom">

				<div class="mh-estate-vertical__bottom__inner">

					<div v-if="showDate" class="mh-estate-vertical__date">
						{{ estate.days_ago }}
					</div>

					<div class="mh-estate-vertical__buttons-wrapper">

						<div class="mh-estate-vertical__buttons">

							<div v-if="showCompare" class="mh-estate-vertical__buttons__single">
								<CompareButton :estate="estate"></CompareButton>
							</div>

							<div class="mh-estate-vertical__buttons__single">
								<a
									:href="estate.link"
									:title="estate.name"
									class="mdl-button mdl-js-button mdl-button--raised mdl-button--primary-ghost"
									:target="target"
								>
									{{ detailsLabel }}
									<span class="mdl-button__icon-right"><i class="fa fa-angle-right"></i></span>
								</a>
							</div>

						</div>

					</div>

				</div>

			</div>

		</article>
	</div>
</template>

<script>
	import CompareButton from '../compare/CompareButton.vue'
	import ListingEstateGallery from './ListingEstateGallery.vue'
	import AddToFavorite from '../favorite/AddToFavorite.vue'

	export default {
		data() {
			return {
				imgClass: {
					lazyload: false
				}
			}
		},
		components: {CompareButton, ListingEstateGallery, AddToFavorite},
		props     : {
			estate     : Object,
			view       : String,
			showGallery: Number,
			showDate   : Number
		},
		computed  : {
			showFavorite() {
				return window.MyHome.show_favorite;
			},
			contactForPriceLabel() {
				return window.MyHome.contact_price_label;
			},
			articleClass() {
				let classes = this.estate.attribute_classes;

				if (this.showGallery) {
					classes += ' mh-estate-horizontal--gallery';
				}

				return classes;
			},
			showCompare() {
				return window.MyHome.compare === '1';
			},
			hasOfferType() {
				return this.estate.offer_type.length > 0
			},
			offerType() {
				let offerType = '';
				for (let i = 0; i < this.estate.offer_type.length; i++) {
					let name = this.estate.offer_type[i].name;
					offerType += i === 0 ? name : ', ' + name;
				}
				return offerType
			},
			detailsLabel() {
				return window.MyHome.translations.details
			},
			hasGallery() {
				return typeof this.estate.gallery !== 'undefined' && this.estate.gallery.length && this.showGallery;
			},
			hasImage() {
				return (!this.hasGallery || typeof this.hasGallery === 'undefined') && (
					(typeof this.estate.image_srcset !== 'undefined' && this.estate.image_srcset !== '' && this.estate.image_srcset !== false)
					|| (this.estate.image && this.estate.image !== '')
				)
			},
			hasExcerpt() {
				return this.estate.excerpt !== ''
			},
			hasAddress() {
				return this.estate.address !== ''
			},
			estateClass() {
				if (this.view === 'colTwo') {
					return 'mh-grid__1of2'
				} else if (this.view === 'row') {
					return 'mh-grid__1of1'
				} else if (this.view === 'colThree') {
					return 'mh-grid__1of3'
				}
			},
			isRow() {
				return this.view === 'row'
			},
			target() {
				let openNewWindow = typeof window.MyHome.property_link_new_tab !== 'undefined' && parseInt(window.MyHome.property_link_new_tab);
				return openNewWindow ? '_blank' : '_self';
			}
		},
		methods   : {
			hasIcon(attribute) {
				return typeof attribute.icon !== 'undefined' && attribute.icon;
			}
		},
		mounted() {
			this.$nextTick(() => {
				this.$set(this.imgClass, 'lazyload', true);
			});
		}
	}
</script>