<template>
    <div>

        <div class="mh-search__panel">
            <div class="mh-search__2-col">

                <div
                        :class="{'mh-active-input':isFromActive, 'awesomplete': field.suggestions}"
                        class="mh-search__2-col__left"
                >
                    <input :id="fieldKeyFrom" v-model="valueFrom" type="text" :placeholder="placeholderFrom">
                </div>

                <div
                        :class="{'mh-active-input':isToActive, 'awesomplete': field.suggestions}"
                        class="mh-search__2-col__right"
                >
                    <input :id="fieldKeyTo" v-model="valueTo" type="text" :placeholder="placeholderTo">
                </div>

            </div>
        </div>

    </div>
</template>

<script>
    const DEFAULT_VALUE = '';
    const DELAY = 600;

    export default {
        data() {
            return {
                valueFrom: DEFAULT_VALUE,
                valueTo: DEFAULT_VALUE,
                awesompleteFrom: false,
                awesompleteTo: false,
                timerFrom: 0,
                timerTo: 0,
                flag: true
            }
        },
        props: {
            field: Object,
            position: String,
            config: Object,
            isStatic: {
                type: Boolean,
                default: false
            }
        },
        computed: {
            fieldKeyFrom() {
                return 'field-' + this.field.slug + '_from'
            },
            fieldKeyTo() {
                return 'field-' + this.field.slug + '_to'
            },
            placeholderFrom() {
                if (this.field.placeholder_from === '') {
                    return window.MyHome.translations.from
                } else {
                    return this.field.placeholder_from
                }
            },
            placeholderTo() {
                if (this.field.placeholder_to === '') {
                    return window.MyHome.translations.to
                } else {
                    return this.field.placeholder_to
                }
            },
            isFromActive() {
                return this.valueFrom !== DEFAULT_VALUE
            },
            isToActive() {
                return this.valueTo !== DEFAULT_VALUE
            }
        },
        methods: {
            getOptionsFrom() {
                let options = [];
                this.field.values['any'].forEach((option) => {
                    options.push({label: option.name, value: option.slug});
                });
                return options
            },
            getOptionsTo() {
                let options = [];
                this.field.values['any'].forEach((option) => {
                    options.push({label: option.name, value: option.slug})
                });
                return options
            },
            setDefault() {
                if (typeof this.config.default_values[this.field.slug + '_from'] !== 'undefined') {
                    jQuery.each(this.config.default_values[this.field.slug + '_from'].values, (index, data) => {
                        this.valueFrom = data.value;
                    });
                } else {
                    this.valueFrom = DEFAULT_VALUE
                }

                if (typeof this.config.default_values[this.field.slug + '_to'] !== 'undefined') {
                    jQuery.each(this.config.default_values[this.field.slug + '_to'].values, (index, data) => {
                        this.valueTo = data.value;
                    });
                } else {
                    this.valueTo = DEFAULT_VALUE
                }
            }
        },
        created() {
            this.setDefault();

            if (typeof this.config.current_values[this.field.slug + '_from'] !== 'undefined') {
                jQuery.each(this.config.current_values[this.field.slug + '_from'].values, (index, data) => {
                    this.valueFrom = data.value;
                });
            }

            if (typeof this.config.current_values[this.field.slug + '_to'] !== 'undefined') {
                jQuery.each(this.config.current_values[this.field.slug + '_to'].values, (index, data) => {
                    this.valueTo = data.value;
                });
            }

            window.MyHomeEventBus.$on('searchFormClear', () => {
                this.valueFrom = DEFAULT_VALUE;
                this.valueTo = DEFAULT_VALUE;
            });
            window.MyHomeEventBus.$on('removeSearchFilterValue' + this.field.slug + '_from', () => {
                this.valueFrom = DEFAULT_VALUE;
            });
            window.MyHomeEventBus.$on('removeSearchFilterValue' + this.field.slug + '_to', () => {
                this.valueTo = DEFAULT_VALUE;
            });
        },
        mounted() {
            if (this.field.suggestions) {
                let fieldFrom = document.getElementById(this.fieldKeyFrom);
                this.awesompleteFrom = new Awesomplete(fieldFrom, {
                    list: this.getOptionsFrom(),
                    minChars: 1,
                    filter: function (text, input) {
                        return text.value.indexOf(input) === 0
                    }.bind(this)
                });
                fieldFrom.addEventListener('awesomplete-selectcomplete', () => {
                    this.valueFrom = fieldFrom.value
                });
                let fieldTo = document.getElementById(this.fieldKeyTo);
                this.awesompleteTo = new Awesomplete(fieldTo, {
                    list: this.getOptionsTo(),
                    minChars: 1,
                    filter: function (text, input) {
                        return text.value.indexOf(input) === 0
                    }.bind(this)
                });
                fieldTo.addEventListener('awesomplete-selectcomplete', () => {
                    this.valueTo = fieldTo.value;
                })
            }
            this.flag = false;
        },
        watch: {
            parentValues() {
                if (!this.field.suggestions) {
                    return
                }
                this.awesompleteFrom.list = this.getOptionsFrom();
                this.awesompleteFrom.evaluate();
                this.awesompleteFrom.close();
                this.awesompleteTo.list = this.getOptionsTo();
                this.awesompleteTo.evaluate();
                this.awesompleteTo.close();
            },
            valueFrom(val) {
                if (this.flag) {
                    return;
                }

                let slug = this.field.slug + '_from';

                if (isNaN(val)) {
                    return;
                }

                let delay = 0
                if (!this.isStatic) {
                    delay = DELAY
                }

                clearTimeout(this.timerFrom);
                this.timerFrom = setTimeout(() => {
                    if (val === DEFAULT_VALUE) {
                        window.MyHomeEventBus.$emit('deleteSearchFilter', slug);
                        return
                    }
                    val = Number(val);

                    window.MyHomeEventBus.$emit('addSearchFilter', {
                        slug: slug,
                        key: this.field.slug,
                        units: this.field.display_after,
                        compare: '>=',
                        values: [
                            {name: this.field.name + ' > ' + val, value: val}
                        ]
                    })
                }, delay)
            },
            valueTo(val) {
                if (this.flag) {
                    return;
                }

                let slug = this.field.slug + '_to';

                if (isNaN(val)) {
                    return
                }

                let delay = 0
                if (!this.isStatic) {
                    delay = DELAY
                }

                clearTimeout(this.timerTo);
                this.timerTo = setTimeout(() => {
                    if (val === DEFAULT_VALUE) {
                        window.MyHomeEventBus.$emit('deleteSearchFilter', slug);
                        return
                    }
                    val = Number(val);

                    window.MyHomeEventBus.$emit('addSearchFilter', {
                        slug: slug,
                        baseSlug: this.field.base_slug,
                        key: this.field.slug,
                        units: this.field.display_after,
                        compare: '<=',
                        values: [
                            {name: this.field.name + ' < ' + val, value: val}
                        ]
                    })
                }, delay)
            }
        }
    }
</script>