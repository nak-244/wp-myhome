<template>
	<div class="mh-map-wrapper" :class="mapWrapperClass">

		<div :class="searchFormWrapperClass">

			<SearchForm
				v-if="showSearchFormTop"
				:config="config"
			></SearchForm>

			<ListingMapBox
				v-if="!hideSearchForm"
				:config="config"
				:reloadFlag="reloadFlag"
				:estates="estates"
				:center="center"
				:zoom="zoom"
			></ListingMapBox>

			<SearchForm
				v-if="showSearchFormBottom"
				:config="config"
			></SearchForm>

			<div v-if="hideSearchForm" class="mh-search-hide">
				<ListingMapBox
					:config="config"
					:reloadFlag="reloadFlag"
					:estates="estates"
					:center="center"
					:zoom="zoom"
				></ListingMapBox>
			</div>

		</div>

	</div>

</template>

<script>
	import ListingMapBox from './ListingMapBox.vue'
	import SearchForm from '../searchform/SearchForm.vue'

	export default {
		components: {ListingMapBox, SearchForm},
		data() {
			return {
				filters             : {},
				estates             : [],
				reloadResults       : false,
				reloadFlag          : true,
				queryFlag           : true,
				currency            : 'any',
				ignoreDefaultFilters: [],
				config              : {},
			}
		},
		props     : {
			configKey: String,
			center   : false,
			zoom     : 0
		},
		computed  : {
			searchFormWrapperClass() {
				return {
					'mh-search-map-top'   : this.config.search_form_position === 'top',
					'mh-search-map-bottom': this.config.search_form_position === 'bottom',
					'mh-search-wide'      : this.config.search_form_wide
				}
			},
			showSearchFormTop() {
				return this.config.search_form_position === 'top'
			},
			showSearchFormBottom() {
				return this.config.search_form_position === 'bottom'
			},
			hideSearchForm() {
				return !this.showSearchFormTop && !this.showSearchFormBottom
			}
		},
		methods   : {
			onReset() {
				this.queryFlag = true;
				for (let key in this.filters) {
					this.$delete(this.filters, key)
				}
				this.queryFlag = false;
				this.query()
			},
			query() {
				if (this.queryFlag) {
					return false
				}

				this.reloadFlag = true;

				let filters = jQuery.extend({}, this.filters);

				jQuery.each(this.config.default_values, (key, data) => {
					if (!filters.hasOwnProperty(key) && this.ignoreDefaultFilters.indexOf(key) === -1) {
						filters[key] = {
							compare: '=',
							key    : key,
							slug   : key,
							values : data.values
						}
					}
				});

				clearTimeout(this.timer);
				this.timer = setTimeout(() => {
					let queryUrl = this.config.api_endpoint + '?currency=' + this.currency;
					let requestData = {
						data    : filters,
						map     : true,
						currency: this.currency
					};

					if (typeof this.config.lang !== 'undefined') {
						requestData.lang = this.config.lang;
						queryUrl += '&mh_lang=' + this.config.lang;
					}

					this.$http.post(queryUrl, requestData, {emulateJSON: true}).then(response => {
						this.estates.splice(0, this.estates.length);
						response.body.results.forEach((estate) => {
							this.estates.push(estate);
						});
						window.MyHomeEventBus.$emit('mapReload');
					}, response => {
					})
				}, 300)
			}
		},
		created() {
			this.config = window[this.configKey];
			this.estates = this.config.results.estates;
			this.config.search_form_advanced_number = parseInt(this.config.search_form_advanced_number);
			this.config.show_advanced = parseInt(this.config.show_advanced);
			this.config.show_clear = parseInt(this.config.show_clear);

			window.MyHomeEventBus.$on('listingReset', this.onReset);
			window.MyHomeEventBus.$on('addSearchFilter', (filter) => {
				if (this.ignoreDefaultFilters.indexOf(filter.slug) === -1) {
					this.ignoreDefaultFilters.push(filter.slug);
				}

				this.$set(this.filters, filter.slug, filter);
				if (filter.baseSlug === 'property_type') {
					window.MyHomeEventBus.$emit('propertyTypeChange', filter.values)
				}
				this.query()
			});
			window.MyHomeEventBus.$on('deleteSearchFilter', (filterSlug) => {
				if (typeof this.filters[filterSlug] !== 'undefined' && this.filters[filterSlug].baseSlug === 'property_type') {
					window.MyHomeEventBus.$emit('propertyTypeChange', []);
				}
				this.$delete(this.filters, filterSlug);
				this.query();
			});
			window.MyHomeEventBus.$on('setCurrency', (currency) => {
				this.currency = currency;
				this.query();
			});
		},
		mounted() {
			setTimeout(() => {
				this.queryFlag = false;
			}, 500);
		}
	}
</script>