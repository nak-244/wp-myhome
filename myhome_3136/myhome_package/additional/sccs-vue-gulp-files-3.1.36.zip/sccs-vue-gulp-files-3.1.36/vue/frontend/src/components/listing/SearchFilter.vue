<template>
	<li v-show="show">

        <span class="mh-results-multiple">
            <span v-for="filterValue in filter.values" :key="filterValue.value">
                {{ filterValue.name }} <span v-if="showUnits">({{ units }})</span>
                <button
					@click="onClick(filterValue.value)"
					class="mh-search__results__button-delete"
				>
                    X
                </button>
            </span>
        </span>

	</li>
</template>

<script>
	export default {
		data() {
			return {
				show: true
			}
		},
		props   : {
			filter  : Object,
			currency: Object
		},
		computed: {
			showUnits() {
				return (!jQuery.isEmptyObject(this.currency) && this.filter.key === 'price') || (typeof this.units !== 'undefined' && this.units !== '');
			},
			units() {
				if (this.filter.key === 'price' && this.currency !== false && !jQuery.isEmptyObject(this.currency)) {
					return this.currency.sign;
				} else if (this.filter.key === 'price') {
					return '';
				}

				return this.filter.units;
			}
		},
		methods : {
			onClick(value) {
				if (this.filter.values.length === 1) {
					this.show = false;
				}
				window.MyHomeEventBus.$emit('removeSearchFilterValue' + this.filter.slug, value)
			}
		}
	}
</script>