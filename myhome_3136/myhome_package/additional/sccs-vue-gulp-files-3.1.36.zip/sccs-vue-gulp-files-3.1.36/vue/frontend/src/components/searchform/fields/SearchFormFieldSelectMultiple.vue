<template>
	<div>

		<div :class="{'mh-active-input': isActive}" class="mh-search__panel">
			<select
				:id="fieldKey"
				multiple
				v-model="values"
				class="selectpicker"
				:title="placeholder"
				data-container="body"
				data-dropup-auto="false"
			>
				<option v-for="option in options" :value="option.slug">{{ option.name }}</option>
			</select>
		</div>

	</div>
</template>

<script>
	export default {
		data() {
			return {
				values      : [],
				parentValues: []
			}
		},
		props   : {
			field   : Object,
			position: String,
			config  : Object
		},
		computed: {
			fieldKey() {
				return 'field-' + this.field.slug
			},
			placeholder() {
				return this.field.placeholder === '' ? this.field.name : this.field.placeholder
			},
			isActive() {
				return this.values.length > 0
			},
			options() {
				let options = {};
				if (this.field.parent_id === 0 || this.parentValues.length === 0) {
					if (typeof this.field.values['any'] === 'undefined') {
						return options;
					}

					this.field.values['any'].forEach((value) => {
						options[value.slug] = value
					});
				} else if (this.field.parent_type === 'manual') {
					jQuery.each(this.field.values['any'], (index, option) => {
						if (this.parentValues.indexOf(option.options.parent_term) !== -1) {
							options[option.slug] = option;
						}
					});
				} else {
					this.parentValues.forEach((slug) => {
						if (typeof this.field.values[slug] !== 'undefined') {
							this.field.values[slug].forEach((value) => {
								options[value.slug] = value
							});
						}
					});
				}

				this.refresh();

				return options
			}
		},
		methods : {
			removeValue(value) {
				let index = this.values.indexOf(value);
				if (index === -1) {
					return;
				}
				this.values.splice(index, 1);
				this.refresh();
			},
			refresh() {
				this.$nextTick(function () {
					jQuery('#' + this.fieldKey).selectpicker('refresh');
				});
			},
			updateParentValues(values) {
				this.parentValues.splice(0, this.parentValues.length);

				values.forEach((v) => {
					this.parentValues.push(v.value);
				});

				this.values.forEach((value, index) => {
					if (!this.options.hasOwnProperty(value)) {
						this.values.splice(index, 1)
					}
					this.refresh()
				})
			},
			setDefault() {
				if (typeof this.config.default_values[this.field.slug] !== 'undefined') {
					this.values.splice(0, this.values.length);
					jQuery.each(this.config.default_values[this.field.slug].values, (index, data) => {
						this.values.push(data.value);
					});
				}
			}
		},
		created() {
			this.setDefault();

			if (typeof this.config.current_values[this.field.slug] !== 'undefined') {
				if (jQuery.isArray(this.config.current_values[this.field.slug]) || typeof this.config.current_values[this.field.slug] === 'object') {
					this.values.splice(0, this.values.length);
					jQuery.each(this.config.current_values[this.field.slug].values, (index, data) => {
						this.values.push(data.value);
					});
				} else {
					this.values.push(this.config.current_values[this.field.slug])
				}
			}

			window.MyHomeEventBus.$on('searchFormClear', () => {
				this.values.splice(0, this.values.length);
				this.refresh();
			});
			window.MyHomeEventBus.$on('removeSearchFilterValue' + this.field.slug, (value) => {
				this.removeValue(value)
			});
			if (this.field.parent_id !== 0) {
				window.MyHomeEventBus.$on('parentAttributeChange' + this.field.parent_id, (values) => {
					this.updateParentValues(values)
				});

				jQuery.each(this.config.default_values, (attributeSlug, data) => {
					if (data.id === this.field.parent_id) {
						this.updateParentValues(data.values);
					}
				});
			}
		},
		mounted() {
			this.refresh();
		},
		watch   : {
			values(val) {
				if (val.length === 0) {
					window.MyHomeEventBus.$emit('deleteSearchFilter', this.field.slug);
					window.MyHomeEventBus.$emit('parentAttributeChange' + this.field.id, []);
					return;
				}

				let values = [];
				val.forEach((slug) => {
					values.push({name: this.options[slug].name, value: slug});
				});

				window.MyHomeEventBus.$emit('addSearchFilter', {
					slug    : this.field.slug,
					baseSlug: this.field.base_slug,
					key     : this.field.slug,
					units   : this.field.display_after,
					compare : this.field.compare_operator,
					values  : values
				});
				window.MyHomeEventBus.$emit('parentAttributeChange' + this.field.id, values);
			},
			parentValues() {
				if (this.values.length !== 0) {
					return;
				}

				let values = [];
				jQuery.each(this.options, (slug, option) => {
					values.push({name: option.name, value: option.slug});
				});

				window.MyHomeEventBus.$emit('parentAttributeChange' + this.field.id, values);
			}
		}
	}
</script>