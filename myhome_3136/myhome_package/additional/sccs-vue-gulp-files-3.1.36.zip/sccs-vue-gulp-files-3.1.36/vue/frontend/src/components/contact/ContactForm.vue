<template>
	<div>
		<div class="mh-form-container" v-if="state == 'form'">
			<form class="contact" method="post" @submit.prevent>
				<div v-if="!validateEmail" class="mh-form-container__info">
					{{ getString('email_invalid') }}
				</div>
				<input v-model.lazy="email" @focusout="showEmailErrors()" type="text" :placeholder="getString('email')">
				<input v-model="phone" type="text" :placeholder="getString('phone')">
				<div v-if="!validateMessage" class="mh-form-container__info">
					{{ getString('msg_to_short') }}
				</div>
				<textarea v-model.lazy="message" type="text" :placeholder="getString('message')"
						  class="mh-form-container__textarea" @focusout="showMessageErrors()"></textarea>
				<div class="mh-form-container__submit">
					<button class="mdl-button mdl-js-button mdl-button--raised mdl-button--primary mdl-button--half"
							@click="send">{{ getString('send') }}</button>
				</div>
			</form>
		</div>
		<div v-if="state == 'sending'" class="mh-form-container__sending">
			{{ getString('sending') }}
		</div>
		<div v-if="state == 'success'" class="mh-form-container__success">
			{{ getString('msg_success') }}
		</div>
		<div v-if="state == 'error'" class="mh-form-container__error">
			{{ getString('msg_error') }}
		</div>
	</div>
</template>
<script>
	export default{
		data() {
			return {
				email: '',
				phone: '',
				message: '',
				emailErrors: false,
				messageErrors: false,
				state: 'form'
			}
		},
		props: {
			translations: {
				type: Object
			},
			estateId: {
				type: Number
			}
		},
		methods: {
			send() {
				this.emailErrors = true;
				this.messageErrors = true;

				if (this.validateEmail && this.validateMessage) {
					this.state = 'sending';

					jQuery.ajax({
						type: 'POST',
						dataType: 'json',
						url: window.MyHome.requestUrl,
						data: {
							action: 'myhome_contact_form_send',
							email: this.email,
							phone: this.phone,
							message: this.message,
							estate_id: this.estateId
						},
						cache: false,
						success: function () {
							this.state = 'success';
						}.bind(this),
						error: function () {
							this.state = 'error';
						}.bind(this)
					})
				}
			},
			showEmailErrors() {
				this.emailErrors = true
			},
			showMessageErrors() {
				this.messageErrors = true
			},
			getString(key) {
				if (typeof this.translations[key] !== 'undefined') {
					return this.translations[key]
				} else {
					return ''
				}
			}
		},
		computed: {
			validateEmail() {
				if (!this.emailErrors) {
					return true
				}

				let email = this.email
				let re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
				return re.test(email)
			},
			validateMessage() {
				if (!this.messageErrors) {
					return true
				}
				return this.message.length > 5
			}
		},
		created() {
			this.$nextTick(function () {
				componentHandler.upgradeDom()
			})
		}
	}
</script>
