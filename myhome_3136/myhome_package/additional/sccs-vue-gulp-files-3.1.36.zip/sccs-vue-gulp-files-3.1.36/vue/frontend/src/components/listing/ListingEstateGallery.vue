<template>
	<div :id="swiperID" class="swiper-container">

		<div v-if="hasOfferType" class="mh-caption">
			<div
				v-for="offerType in estate.offer_type"
				v-if="offerType.options.has_label"
				class="mh-caption__inner"
				:class="'mh-label__' + offerType.slug"
				:style="{background: offerType.options.bg_color, color: offerType.options.color}"
			>
				{{ offerType.name }}
			</div>
		</div>

		<a :href="estate.link" :target="target" :title="estate.name" class="swiper-wrapper">

			<div class="swiper-slide" :key="estate.id + '-' + key" v-for="(image, key) in estate.gallery">
				<img :data-src="image.image" :alt="image.alt" class="swiper-lazy">
			</div>

		</a>

		<div class="swiper-pagination swiper-pagination-white" :class="swiperPaginationClass"></div>

		<div class="swiper-button-prev swiper-button-white" :class="swiperButtonPrevClass"></div>
		<div class="swiper-button-next swiper-button-white" :class="swiperButtonNextClass"></div>

		<div v-if="estate.is_featured" class="mh-thumbnail__featured">
			<i class="fa fa-star"></i>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				swiper: false
			}
		},
		computed: {
			hasOfferType() {
				return this.estate.offer_type.length > 0
			},
			swiperID() {
				return 'swiper-' + this.estate.id;
			},
			swiperPaginationClass() {
				return 'swiper-pagination-' + this.estate.id;
			},
			swiperButtonNextClass() {
				return 'swiper-button-next-' + this.estate.id;
			},
			swiperButtonPrevClass() {
				return 'swiper-button-prev-' + this.estate.id;
			},
			target() {
				let openNewWindow = typeof window.MyHome.property_link_new_tab !== 'undefined' && parseInt(window.MyHome.property_link_new_tab);
				return openNewWindow ? '_blank' : '_self';
			}
		},
		props   : {
			estate: Object
		},
		mounted() {
			this.swiper = new Swiper('#' + this.swiperID, {
				preloadImages: false,
				lazy         : {
					loadPrevNext: true
				},
                shortSwipes: false,
                touchRatio: 0,
				pagination   : {
					el            : '.' + this.swiperPaginationClass,
					dynamicBullets: true,
				},
				navigation   : {
					nextEl: '.' + this.swiperButtonNextClass,
					prevEl: '.' + this.swiperButtonPrevClass,
				},
				loop         : true
			});

			window.MyHomeEventBus.$on('listingViewChanged', () => {
				this.$nextTick(() => {
					this.swiper.update();
				});
			});
		}
	}
</script>