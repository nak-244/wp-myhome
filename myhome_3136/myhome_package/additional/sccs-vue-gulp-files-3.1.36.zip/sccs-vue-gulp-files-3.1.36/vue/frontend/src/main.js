"use strict";

import Vue from 'vue'
import VueResource from 'vue-resource'
import infiniteScroll from 'vue-infinite-scroll'
import ListingGrid from './components/listing/ListingGrid.vue'
import ListingMap from './components/listing/ListingMap.vue'
import SearchFormSubmit from './components/searchform/SearchFormSubmit.vue'
import CompareArea from './components/compare/CompareArea.vue'
import CompareButton from './components/compare/CompareButton.vue'
import EstateMap from './components/map/EstateMap.vue'
import ContactForm from './components/contact/ContactForm.vue'
import UserBar from './components/userbar/UserBar.vue'
import SearchFormBasic from './components/searchform/SearchFormBasic.vue'
import AddToFavorite from './components/favorite/AddToFavorite.vue'
import Account from './components/account/Account.vue'
import SaveSearch from './components/searches/SaveSearch.vue'
import AddToFavoriteSingle from './components/favorite/AddToFavoriteSingle.vue'
import CompareButtonSingle from './components/compare/CompareButtonSingle.vue'

Vue.use(infiniteScroll);
Vue.use(VueResource);

window.MyHomeEventBus = new Vue();

if (document.querySelector('#myhome-listing-grid')) {
	new Vue({
		el        : '#myhome-listing-grid',
		components: {ListingGrid}
	})
}

if (document.getElementsByClassName('myhome-add-to-favorite-single').length > 0) {
	Array.prototype.forEach.call(document.getElementsByClassName('myhome-add-to-favorite-single'), function (el) {
		new Vue({
			el        : el,
			components: {AddToFavoriteSingle}
		})
	})
}

if (document.getElementsByClassName('myhome-compare-button-single').length > 0) {
	Array.prototype.forEach.call(document.getElementsByClassName('myhome-compare-button-single'), function (el) {
		new Vue({
			el        : el,
			components: {CompareButtonSingle}
		})
	})
}

if (document.querySelector('#myhome-account')) {
	new Vue({
		el        : '#myhome-account',
		components: {Account}
	})
}

if (document.querySelector('#myhome-save-search')) {
	new Vue({
		el        : '#myhome-save-search',
		components: {SaveSearch}
	})
}

if (document.querySelector('#myhome-listing-map')) {
	new Vue({
		el        : '#myhome-listing-map',
		components: {ListingMap}
	})
}

if (document.querySelector('#myhome-search-form-submit')) {
	new Vue({
		el        : '#myhome-search-form-submit',
		components: {SearchFormSubmit}
	})
}

if (document.querySelector('#myhome-search-form-basic')) {
	new Vue({
		el        : '#myhome-search-form-basic',
		components: {SearchFormBasic}
	})
}

if (document.querySelector('#myhome-user-bar')) {
	new Vue({
		el        : '#myhome-user-bar',
		components: {UserBar}
	})
}

if (document.querySelector('#myhome-compare-area')) {
	new Vue({
		el        : '#myhome-compare-area',
		components: {CompareArea}
	})
}

if (document.querySelector('#myhome-contact-form')) {
	new Vue({
		el        : '#myhome-contact-form',
		components: {ContactForm}
	})
}

if (document.querySelector('#myhome-estate-map')) {
	new Vue({
		el        : '#myhome-estate-map',
		components: {EstateMap}
	})
}

if (document.getElementsByClassName('myhome-compare-button').length > 0) {
	let carousel = jQuery('.owl-properties');
	if (carousel.hasClass('owl-loaded')) {
		Array.prototype.forEach.call(document.getElementsByClassName('myhome-compare-button'), function (el) {
			new Vue({
				el        : el,
				components: {CompareButton}
			})
		})
	}
	carousel.on('initialized.owl.carousel', function () {
		jQuery.each(jQuery(this).find('.myhome-compare-button'), (index, el) => {
			new Vue({
				el        : el,
				components: {CompareButton}
			})
		});
	})

	jQuery.each(jQuery('.myhome-compare-button-list'), (index, el) => {
		new Vue({
			el        : el,
			components: {CompareButton}
		})
	});
}

if (document.getElementsByClassName('myhome-add-to-favorite').length > 0) {
	Array.prototype.forEach.call(document.getElementsByClassName('myhome-add-to-favorite'), function (el) {
		new Vue({
			el        : el,
			components: {AddToFavorite}
		})
	})
}

jQuery(window).load(function () {
	if (!jQuery('.compose-mode').length) {
		return false;
	}

	let listing, listingMap, estateMap, searchFormSubmit, userBar, searchFormBasic;
	let listingFlag = false;
	let listingMapFlag = false;
	let estateMapFlag = false;
	let searchFormSubmitFlag = false;
	let userBarFlag = false;
	let searchFormBasicFlag = false;

	setInterval(function () {
		if ($('.owl-properties .myhome-compare-button').length > $('.owl-properties .myhome-compare-button.mh-vc').length) {
			$.each($('.owl-properties .myhome-compare-button').not('.mh-vc'), function () {
				$(this).addClass('mh-vc');
				new Vue({
					el        : $(this).get(0),
					components: {CompareButton}
				});
			});
		}

		if ($('.myhome-add-to-favorite').length > $('.myhome-add-to-favorite.mh-vc').length) {
			$.each($('.myhome-add-to-favorite').not('.mh-vc'), function () {
				$(this).addClass('mh-vc');
				new Vue({
					el        : $(this).get(0),
					components: {AddToFavorite}
				});
			});
		}

		let mhListing = $('#myhome-listing-grid');

		if (mhListing.length > $('#myhome-listing-grid.mh-vc').length) {
			mhListing.addClass('mh-vc');
			listing = new Vue({
				el        : '#myhome-listing-grid',
				components: {ListingGrid}
			});
			listingFlag = true
		}

		if (mhListing.length === 0 && listingFlag) {
			listing.$destroy();
			listingFlag = false;
		}

		let mhBasicSearchForm = $('#myhome-search-form-basic');

		if (mhBasicSearchForm.length > $('#myhome-search-form-basic.mh-vc').length) {
			mhBasicSearchForm.addClass('mh-vc');
			searchFormBasic = new Vue({
				el        : '#myhome-search-form-basic',
				components: {SearchFormBasic}
			});
			searchFormBasicFlag = true

		}

		if (mhBasicSearchForm.length === 0 && searchFormBasicFlag) {
			searchFormBasic.$destroy();
			searchFormBasicFlag = false;
		}

		let mhUserBar = $('#myhome-user-bar');

		if (mhUserBar.length > $('#myhome-user-bar.mh-vc').length) {
			mhUserBar.addClass('mh-vc');
			userBar = new Vue({
				el        : '#myhome-user-bar',
				components: {UserBar}
			});
			userBarFlag = true
		}

		if (mhUserBar.length === 0 && userBarFlag) {
			userBar.$destroy();
			userBarFlag = false;
		}

		let mhSearchFormSubmit = $('#myhome-search-form-submit');

		if (mhSearchFormSubmit.length > $('#myhome-search-form-submit.mh-vc').length) {
			mhSearchFormSubmit.addClass('mh-vc');
			searchFormSubmit = new Vue({
				el        : '#myhome-search-form-submit',
				components: {SearchFormSubmit}
			});
			searchFormSubmitFlag = true
		}

		if (mhSearchFormSubmit.length === 0 && searchFormSubmitFlag) {
			searchFormSubmit.$destroy();
			searchFormSubmitFlag = false;
		}

		let mhListingMap = $('#myhome-listing-map');
		if (mhListingMap.length > $('#myhome-listing-map.mh-vc').length) {
			mhListingMap.addClass('mh-vc');
			listingMap = new Vue({
				el        : '#myhome-listing-map',
				components: {ListingMap}
			});
			listingMapFlag = true;
		}

		if (mhListingMap.length === 0 && listingMapFlag) {
			listingMap.$destroy();
			listingMapFlag = false;
		}

		let mhEstateMap = $('#myhome-estate-map');

		if (mhEstateMap.length > $('#myhome-estate-map.mh-vc').length) {
			mhEstateMap.addClass('mh-vc');
			estateMap = new Vue({
				el        : '#myhome-estate-map',
				components: {EstateMap}
			});
			estateMapFlag = true
		}

		if (mhEstateMap.length === 0 && estateMapFlag) {
			estateMap.$destroy();
			estateMapFlag = false;
		}
	}, 1200);
});