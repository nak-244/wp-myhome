<template>
	<button @click="onClick" class="mh-estate__add-to__compare" :class="{'mh-estate__add-to__compare--active': !compare}">
		<i class="fa" :class="{'fa-check': !compare, 'fa-files-o': compare}"></i>
		<span>{{ label }}</span>
	</button>
</template>

<script>
	export default {
		name    : "CompareButtonSingle",
		data() {
			return {
				compare: true
			}
		},
		props   : {
			estate: {
				type: Object
			}
		},
		computed: {
            label() {
                return this.compare ? window.MyHome.translations.add_to_compare : window.MyHome.translations.added_to_compare
            }
		},
		methods : {
			onClick() {
				this.compare = !this.compare;

				if (this.compare) {
					window.MyHomeEventBus.$emit('removeFromCompare', this.estate.id);
				} else {
					window.MyHomeEventBus.$emit('addToCompare', this.estate);
				}
			},
			getCookie(cname) {
				let name = cname + '=';
				let ca = document.cookie.split(';');
				for (let i = 0; i < ca.length; i++) {
					let c = ca[i];
					while (c.charAt(0) === ' ') {
						c = c.substring(1);
					}
					if (c.indexOf(name) === 0) {
						return c.substring(name.length, c.length);
					}
				}
				return ''
			}
		},
		created() {
			window.MyHomeEventBus.$on('enableCompareButton', (estateId) => {
				if (this.estate.id === estateId) {
					this.compare = false;
				}
			});

			window.MyHomeEventBus.$on('removeFromCompare', (estateId) => {
				if (this.estate.id === estateId) {
					this.compare = true;
				}
			});

			window.MyHomeEventBus.$on('addToCompare', (estate) => {
				if (this.estate.id === estate.id) {
					this.compare = false;
				}
			});

			let estateIdsCookie = this.getCookie('myhome_compare_estates');
			if (estateIdsCookie !== '') {
				let estateIds = JSON.parse(estateIdsCookie);
				if (jQuery.inArray(this.estate.id, estateIds) > -1) {
					this.compare = false;
				}
			}
		}
	}
</script>