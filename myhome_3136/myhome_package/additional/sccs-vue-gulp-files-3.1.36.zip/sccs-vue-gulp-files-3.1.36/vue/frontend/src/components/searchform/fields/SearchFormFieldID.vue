<template>
	<div>

		<div class="mh-search__panel" :class="fieldClass">
			<input :id="fieldKey" v-model="value" type="text" :placeholder="placeholder">
		</div>

	</div>
</template>

<script>
	const DEFAULT_VALUE = '';

	export default {
		data() {
			return {
				value: DEFAULT_VALUE,
				timer: 0
			}
		},
		props: {
			field: Object,
			position: String,
			config: Object
		},
		computed: {
			fieldKey() {
				return 'field-' + this.field.slug
			},
			fieldClass() {
				return {
					'mh-active-input': this.isActive,
					'awesomplete': this.field.suggestions
				}
			},
			placeholder() {
				return this.field.placeholder === '' ? this.field.name : this.field.placeholder
			},
			isActive() {
				return this.value !== DEFAULT_VALUE
			}
		},
		methods: {
			setDefault() {
				if (typeof this.config.default_values[this.field.slug] !== 'undefined') {
					this.value = this.config.default_values[this.field.slug]
				} else {
					this.value = DEFAULT_VALUE
				}
			}
		},
		created() {
			this.setDefault();

			if (typeof this.config.current_values[this.field.slug] !== 'undefined') {
				jQuery.each(this.config.current_values[this.field.slug].values, (index, data) => {
					this.value = data.value;
				});
			}

			window.MyHomeEventBus.$on('searchFormClear', this.setDefault);
			window.MyHomeEventBus.$on('removeSearchFilterValue' + this.field.slug, () => {
				this.value = DEFAULT_VALUE;
			});
		},
		watch: {
			value(val) {
				clearTimeout(this.timer);
				this.timer = setTimeout(() => {
					if (val === DEFAULT_VALUE) {
						window.MyHomeEventBus.$emit('deleteSearchFilter', this.field.slug);
						return;
					}

					window.MyHomeEventBus.$emit('addSearchFilter', {
						slug: this.field.slug,
						baseSlug: this.field.base_slug,
						key: this.field.slug,
						units: this.field.display_after,
						compare: this.field.compare_operator,
						values: [
							{name: val, value: val}
						]
					})
				}, 600);
			}
		}
	}
</script>