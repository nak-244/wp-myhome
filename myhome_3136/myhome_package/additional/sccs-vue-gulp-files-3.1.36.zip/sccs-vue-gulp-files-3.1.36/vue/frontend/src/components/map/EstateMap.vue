<template>
	<div class="mh-map-wrapper" :class="{'mh-map-wrapper--fullscreen': isFullScreen}">
		<div id="map" :class="mapTypeClass"></div>
		<div class="mh-map-controls mh-layout">
			<div class="mh-map-controls__inner">
				<div v-if="!streetViewMode" class="mh-map-zoom">
					<div class="mh-map-zoom__element">
						<button @click="zoomIn" :disabled="disableZoomIn">
							<i class="fa fa-plus" aria-hidden="true"></i>
						</button>
					</div>
					<div class="mh-map-zoom__element">
						<button @click="zoomOut" :disabled="disableZoomOut">
							<i class="fa fa-minus" aria-hidden="true"></i>
						</button>
					</div>
				</div>
				<div class="mh-map-panel">
					<div v-if="isStreetViewAvailable" class="mh-map-panel__element">
						<button @click="setStreetView" :class="{'mh-button--active': streetViewMode}">
							<i class="fa fa-street-view" aria-hidden="true"></i>
							<span>{{ getString('street_view') }}</span>
						</button>
					</div>
					<div class="mh-map-panel__element">
						<button @click="changeScreenMode" :class="{'mh-button--active': isFullScreen}">
							<i class="fa fa-expand" aria-hidden="true"></i> <span>{{ getString('fullscreen') }}</span>
						</button>
					</div>
					<div v-if="!streetViewMode && !showCurrentLocation" class="mh-map-panel__element">
						<button @click="showLocation">
							{{ getString('show_location') }}
						</button>
					</div>
					<div v-if="displayNear" class="mh-map-panel__element">
						<button @click="showNear" :class="{'mh-button--active': showNearFlag}">{{ getString('near') }}</button>
					</div>
					<div v-if="showNextPrev" class="mh-map-panel__element">
						<button @click="prevMarker">
							<i class="fa fa-angle-left" aria-hidden="true"></i> <span>{{ getString('prev') }}</span>
						</button>
					</div>
					<div v-if="showNextPrev" class="mh-map-panel__element">
						<button @click="nextMarker">
							<span>{{ getString('next') }}</span> <i class="fa fa-angle-right" aria-hidden="true"></i>
						</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				estateCenter         : false,
				currentCenter        : false,
				isFullScreen         : false,
				isStreetViewAvailable: false,
				sv                   : false,
				streetViewMode       : false,
				estateMarker         : false,
				markers              : false,
				map                  : false,
				nearMarkers          : [],
				currentMarker        : false,
				currentMarkerIndex   : 1,
				currentInfoBox       : false,
				currentZoom          : 15,
				currentWidth         : 0,
				minZoom              : 0,
				maxZoom              : 18,
				showNearFlag         : false,
				markerCluster        : false,
			}
		},
		props   : {
			config: Object,
			zoom  : Number
		},
		computed: {
			setZoom() {
				return typeof this.zoom !== 'undefined' ? this.zoom : 15
			},
			target() {
				let openNewWindow = typeof window.MyHome.property_link_new_tab !== 'undefined' && parseInt(window.MyHome.property_link_new_tab);
				return openNewWindow ? '_blank' : '_self';
			},
			mapTypeClass() {
				return {
					'mh-map-single-estate'      : typeof this.config.mapType === 'undefined' || this.config.mapType !== 'small',
					'mh-map-single-estate-small': typeof this.config.mapType !== 'undefined' && this.config.mapType === 'small'
				};
			},
			showCurrentLocation() {
				if (!this.currentCenter || !this.estateCenter) {
					return true
				}

				return this.currentCenter.lat() === this.estateCenter.lat() && this.currentCenter.lng() === this.estateCenter.lng()
			},
			nearLabel() {
				if (this.showNearFlag) {
					return this.getString('hide_near')
				} else {
					return this.getString('show_near')
				}
			},
			displayNear() {
				return this.config.estatesNear.length && !this.streetViewMode && this.currentWidth > 767
			},
			showNextPrev() {
				return this.showNearFlag && this.config.estatesNear.length && !this.streetViewMode
			},
			disableZoomIn() {
				return this.currentZoom === this.maxZoom && !this.streetViewMode
			},
			disableZoomOut() {
				return this.currentZoom === this.minZoom && !this.streetViewMode
			}
		},
		methods : {
			setEstateCenter() {
				let offsetX = 0;
				let offsetY = -150;
				let scale = Math.pow(2, this.map.getZoom());

				let worldCoordinateCenter = this.map.getProjection().fromLatLngToPoint(this.currentMarker.position);
				let pixelOffset = new google.maps.Point((offsetX / scale) || 0, (offsetY / scale) || 0);

				let worldCoordinateNewCenter = new google.maps.Point(
					worldCoordinateCenter.x - pixelOffset.x,
					worldCoordinateCenter.y + pixelOffset.y
				);
				this.estateCenter = this.map.getProjection().fromPointToLatLng(worldCoordinateNewCenter)
			},
			checkWidth() {
				this.$nextTick(function () {
					this.currentWidth = jQuery(window).width()
				}.bind(this))
			},
			changeScreenMode() {
				this.isFullScreen = !this.isFullScreen;

				if (this.isFullScreen) {
					jQuery('body').addClass('overflow-hidden');
					jQuery('html').addClass('overflow-hidden');
				} else {
					jQuery('body').removeClass('overflow-hidden');
					jQuery('html').removeClass('overflow-hidden');
				}

				this.$nextTick(() => {
					google.maps.event.trigger(this.map, 'resize');
				})
			},
			getString(key) {
				if (typeof window.MyHome.translations[key] !== 'undefined') {
					return window.MyHome.translations[key]
				} else {
					return key
				}
			},
			setEstateMarker() {
				let position = new google.maps.LatLng(this.config.estate.position.lat, this.config.estate.position.lng);
				this.estateMarker = new RichMarker({
					position: position,
					title   : this.config.estate.title,
					estate  : this.config.estate,
					map     : this.map,
					shadow  : 'none',
					content : '<div class="mh-map-pin"><i class="flaticon-pin"></i></div>'
				});
				this.currentMarker = this.estateMarker;

				google.maps.event.addListener(this.estateMarker, 'click', () => {
					this.currentMarker = this.estateMarker;
					this.changeMarker();
				});

				this.sv.getPanorama({location: position}, function (streetViewPanoramaData, status) {
					this.isStreetViewAvailable = status === google.maps.StreetViewStatus.OK && parseInt(window.MyHome.street);
				}.bind(this))
			},
			prevMarker() {
				if (this.streetViewMode) {
					this.setStreetView()
				}

				if (this.currentMarkerIndex === 0) {
					this.currentMarkerIndex = this.nearMarkers.length - 1
				} else {
					this.currentMarkerIndex--
				}
				this.currentMarker = this.nearMarkers[this.currentMarkerIndex]
				this.changeMarker()
			},
			nextMarker() {
				if (this.streetViewMode) {
					this.setStreetView()
				}

				if (this.currentMarkerIndex === (this.nearMarkers.length - 1)) {
					this.currentMarkerIndex = 0
				} else {
					this.currentMarkerIndex++
				}
				this.currentMarker = this.nearMarkers[this.currentMarkerIndex]
				this.changeMarker()
			},
			changeMarker() {
				let mapCenter = {
					lat: this.currentMarker.position.lat(),
					lng: this.currentMarker.position.lng()
				};
				if (this.currentZoom < 15) {
					this.map.setZoom(this.setZoom);
				}
				this.map.setCenter(mapCenter);
				this.updateMapOffset();
				this.createInfoBox(this.currentMarker);
				this.sv.getPanorama({location: mapCenter}, function (streetViewPanoramaData, status) {
					this.isStreetViewAvailable = status === google.maps.StreetViewStatus.OK && parseInt(window.MyHome.street);
				}.bind(this))
			},
			setStreetView() {
				if (this.streetViewMode) {
					this.map.getStreetView().setOptions({visible: false})
				} else {
					this.map.getStreetView().setOptions({
						visible          : true,
						position         : this.currentMarker.position,
						zoomControl      : false,
						fullscreenControl: false,
						enableCloseButton: false,
						addressControl   : false
					})
				}
				this.streetViewMode = !this.streetViewMode
			},
			zoomIn() {
				if (this.currentZoom < this.maxZoom) {
					this.currentZoom++;
					this.map.setZoom(this.currentZoom);
				}
			},
			zoomOut() {
				if (this.currentZoom > this.minZoom) {
					this.currentZoom--;
					this.map.setZoom(this.currentZoom);
				}
			},
			createInfoBox(marker) {
				let boxText = document.createElement('div');
				let estate = marker.estate;
				let height = 320;
				let innerHTML = '<div class="mh-map-infobox"><a href="' + estate.link + '" title="' + estate.name + '" target="' + this.target + '">';
				if (estate.image) {
					innerHTML += '<div class="mh-map-infobox__img-wrapper"><img src="' + estate.image + '" alt="' + estate.name + '">';
					innerHTML += '</div>';
				} else {
					height -= 144;
				}
				innerHTML += '<h4 class="mh-map-infobox__name">' + estate.name + '</h4>';

				if (estate.price) {
					jQuery.each(estate.price, (index, priceObj) => {
						innerHTML += '<h3 class="mh-map-infobox__price">' + priceObj.price + '</h3>';
						return false;
					});
				} else {
					height -= 34;
				}
				innerHTML += '</a></div>';
				boxText.innerHTML = innerHTML;

				let myOptions = {
					content               : boxText,
					disableAutoPan        : false,
					maxWidth              : 0,
					alignBottom           : true,
					pixelOffset           : new google.maps.Size(-160, -25),
					zIndex                : 6,
					boxStyle              : {
						opacity: 1,
						width  : '320px'
					},
					closeBoxURL           : window.MyHome.site + '/wp-content/themes/myhome/assets/images/close.png',
					infoBoxClearance      : new google.maps.Size(1, 1),
					isHidden              : false,
					pane                  : 'floatPane',
					enableEventPropagation: false
				};

				let ib = new InfoBox(myOptions);

				if (this.currentInfoBox !== false) {
					this.currentInfoBox.close();
				}
				this.currentInfoBox = ib;
				this.currentInfoBox.open(this.map, marker);
			},
			clearNear() {
				if (window.MyHome.clustering) {
					this.markerCluster.clearMarkers();
				} else {
					jQuery.each(this.nearMarkers, (index, marker) => {
						marker.setMap(null);
					});
				}

				this.nearMarkers = [];
				this.createInfoBox(this.estateMarker)
			},
			updateMapOffset() {
				let offsetX = 0;
				let offsetY = -150;
				let scale = Math.pow(2, this.map.getZoom());

				let worldCoordinateCenter = this.map.getProjection().fromLatLngToPoint(this.currentMarker.position);
				let pixelOffset = new google.maps.Point((offsetX / scale) || 0, (offsetY / scale) || 0);

				let worldCoordinateNewCenter = new google.maps.Point(
					worldCoordinateCenter.x - pixelOffset.x,
					worldCoordinateCenter.y + pixelOffset.y
				);
				let newCenter = this.map.getProjection().fromPointToLatLng(worldCoordinateNewCenter);
				this.map.setCenter(newCenter);
			},
			initMap() {
				this.sv = new google.maps.StreetViewService();

				let mapCenter = {
					lat: parseFloat(this.config.estate.position.lat),
					lng: parseFloat(this.config.estate.position.lng)
				};

				let map = new google.maps.Map(document.getElementById('map'), {
					zoom                  : this.setZoom,
					center                : mapCenter,
					disableDefaultUI      : true,
					zoomControl           : false,
					scaleControl          : false,
					draggable             : true,
					disableDoubleClickZoom: true,
					scrollwheel           : false,
					gestureHandling       : 'cooperative'
				});
				if (this.config.mapStyle !== 'google') {
					if (this.config.mapStyle === 'gray') {
						let grayStyle = [{
							featureType: "administrative",
							elementType: "labels.text.fill",
							stylers    : [{color: "#444444"}]
						}, {
							featureType: "landscape",
							elementType: "all",
							stylers    : [{color: "#f2f2f2"}]
						}, {featureType: "poi", elementType: "all", stylers: [{visibility: "off"}]}, {
							featureType: "road",
							elementType: "all",
							stylers    : [{saturation: -100}, {lightness: 45}]
						}, {
							featureType: "road.highway",
							elementType: "all",
							stylers    : [{visibility: "simplified"}]
						}, {
							featureType: "road.arterial",
							elementType: "labels.icon",
							stylers    : [{visibility: "off"}]
						}, {
							featureType: "transit",
							elementType: "all",
							stylers    : [{visibility: "off"}]
						}, {
							featureType: "water",
							elementType: "all",
							stylers    : [{color: "#d7e1f2"}, {visibility: "on"}]
						}];
						map.mapTypes.set('styled_map', new google.maps.StyledMapType(grayStyle));
					} else {
						map.mapTypes.set('styled_map', new google.maps.StyledMapType(window.MyHomeMapStyle));
					}
					map.setMapTypeId('styled_map')

				} else {
					map.setMapTypeId(window.MyHome.mapType);
				}
				this.map = map;
				this.map.addListener('zoom_changed', function () {
					this.currentZoom = this.map.getZoom();
				}.bind(this));

				this.map.addListener('center_changed', function () {
					this.currentCenter = this.map.getCenter()
				}.bind(this));

				jQuery(window).trigger('mhMapInitiated', [this.map]);

				this.setEstateMarker();
				google.maps.event.trigger(this.map, 'resize');
				this.createInfoBox(this.estateMarker);
				google.maps.event.addListenerOnce(this.map, 'idle', function () {
					this.updateMapOffset();
					this.estateCenter = this.map.getCenter();
					this.$nextTick(function () {
						if (this.config.estatesNearActive) {
							this.showNear();
						}
					}.bind(this));
				}.bind(this));
			},
			showLocation() {
				if (this.streetViewMode) {
					this.setStreetView();
				}

				this.currentMarker = this.estateMarker;
				this.changeMarker()
			},
			showNear() {
				if (this.config.estatesNear.length === 0) {
					return;
				}

				if (this.streetViewMode) {
					this.setStreetView();
				}

				if (this.showNearFlag) {
					this.clearNear();
					this.showLocation();
					this.showNearFlag = false;
					return;
				}
				this.showNearFlag = true;
				let bounds = new google.maps.LatLngBounds();
				bounds.extend(this.estateMarker.position);
				let checkMarkers = [];

				jQuery.each(this.config.estatesNear, function (i, estate) {
					let currentCheck = parseFloat(estate.position.lat) + ':' + parseFloat(estate.position.lng);
					if (jQuery.inArray(currentCheck, checkMarkers) !== -1) {
						estate.position.lat = estate.position.lat + (Math.random() - .5) / 1500;
						estate.position.lng = estate.position.lng + (Math.random() - .5) / 1500;
						currentCheck = parseFloat(estate.position.lat) + ':' + parseFloat(estate.position.lng);
					}
					checkMarkers.push(currentCheck);

					let position = new google.maps.LatLng(estate.position.lat, estate.position.lng);
					let marker = new RichMarker({
						position: position,
						title   : estate.name,
						estate  : estate,
						shadow  : 'none',
						content : '<div class="mh-map-pin mh-map-pin--dark"><i class="flaticon-pin"></i></div>'
					});
					bounds.extend(marker.position);

					if (!window.MyHome.clustering) {
						marker.setMap(this.map);
					}
					this.nearMarkers.push(marker);

					google.maps.event.addListener(marker, 'click', function () {
						this.currentMarker = marker;
						this.changeMarker();
					}.bind(this));
				}.bind(this));

				this.map.fitBounds(bounds);

				if (window.MyHome.clustering) {
					this.markerCluster = new MarkerClusterer(this.map, this.nearMarkers,
						{
							styles: [
								{
									textColor: 'white',
									url      : window.MyHome.site + '/wp-content/themes/myhome/assets/images/map/cluster1.png',
									width    : 82,
									height   : 82
								},
								{
									textColor: 'white',
									url      : window.MyHome.site + '/wp-content/themes/myhome/assets/images/map/cluster2.png',
									width    : 82,
									height   : 82
								}
							]
						}
					)
				}
			}
		},
		created() {
			this.estate = this.config.estate;
			this.estatesNear = this.config.estatesNear;
		},
		mounted() {
			this.checkWidth();
			window.onload = () => {
				let timer = setInterval(() => {
					if (typeof google !== 'undefined') {
						clearInterval(timer);
						this.initMap();
					}
				}, 100);
			}
		}
	}
</script>