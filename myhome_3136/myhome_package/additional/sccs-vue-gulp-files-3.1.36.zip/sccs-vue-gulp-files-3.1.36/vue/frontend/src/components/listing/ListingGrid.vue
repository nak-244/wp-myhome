<template>

	<div>
		<div class="mh-search-classic">
			<div v-if="showSearchForm" :class="searchFormClass">
				<SearchForm :config="config">
					<slot></slot>
				</SearchForm>
			</div>

			<div v-if="showInitialResults" :class="listingClass">
				<ListingNav :config="config"></ListingNav>

				<div class="mh-search__results-wrapper">

					<div v-if="showSaveSearch" class="mh-save-search-button">
						<button
							@click="onSaveSearch"
							class="mdl-button mdl-js-button mdl-button--raised mdl-button--primary"
						>
							{{ saveSearchText }}
						</button>
					</div>

					<div class="mh-search__results-filters">
						<ul>
							<li v-if="config.show_results_number" class="mh-search__results">
								{{ results }}
							</li>

							<SearchFilter
								v-for="filter in filters"
								:key="filter.slug"
								:filter="filter"
								:currency="currentCurrency"
							></SearchFilter>

						</ul>
					</div>
				</div>

				<div v-if="showLoading" class="mh-loader-wrapper" :class="{'mh-loader--mobile-searchform': reloadResults}">
					<div class="mh-loader"></div>
				</div>


				<div
					id="results"
					v-infinite-scroll="loadMore"
					infinite-scroll-disabled="lazyload"
					infinite-scroll-distance="10"
				>

					<div id="myhome-listing" class="mh-grid mh-listing-page mh-properties">

						<ListingEstate
							class="mh-property"
							v-for="estate in estates"
							:key="estate.slug"
							:view="view"
							:showGallery="config.show_gallery"
							:estate="estate"
							:show-date="config.show_date"
						></ListingEstate>

					</div>

				</div>

				<div v-if="showMoreButton" class="mh-search__more">
					<button
						class="mdl-button mdl-js-button mdl-button--raised mdl-button--primary mdl-button--lg"
						@click="onLoadMoreButton"
					>
						{{ config.load_more_button }}
					</button>
				</div>

				<div v-if="showBottomLoading" class="mh-loader-wrapper" :class="{'mh-loader--mobile-searchform': reloadResults}">
					<div class="mh-loader"></div>
				</div>

				<div v-if="showBottomResults" class="mh-search__end">
					<strong>{{ bottomResults }}</strong>
				</div>

				<Paginate
					v-if="hasPagination"
					v-show="showPagination"
					:initial-page="initialPage"
					:page-count="pages"
					:page-range="3"
					:margin-pages="2"
					:click-handler="onChangePageBottom"
					:prev-text="prevText"
					:next-text="nextText"
					:container-class="'mh-pagination mh-pagination--properties'"
					:page-class="'mh-pagination__item'"
					:force-page="currentPageIndex"
				>
				</Paginate>

			</div>

		</div>

	</div>

</template>

<script>
	import SearchForm from '../searchform/SearchForm.vue'
	import SearchFilter from './SearchFilter.vue'
	import ListingEstate from './ListingEstate.vue'
	import ListingNav from './ListingNav.vue'
	import Paginate from 'vuejs-paginate'

	export default {
		data() {
			return {
				showInitialResults  : true,
				init                : true,
				filters             : {},
				estates             : [],
				reloadResults       : false,
				totalResults        : 0,
				busy                : true,
				view                : 'colTwo',
				sortBy              : 'newest',
				currency            : 'any',
				page                : 1,
				lazyloadCurrent     : 0,
				timer               : 0,
				queryFlag           : true,
				ignoreDefaultFilters: [],
				config              : {},
				lazyLoadFlag        : true,
				hasPagination       : false,
				initialPage         : 0,
				queryInProgress     : false,
				queryKey            : '',
				initialSetup        : true,
				lastRequest         : false
			}
		},
		components: {ListingEstate, ListingNav, SearchForm, SearchFilter, Paginate},
		props     : {
			configKey: {
				type: String
			}
		},
		computed  : {
			showSaveSearch() {
				return window.MyHome.show_save_search && this.config.hide_save_search === '';
			},
			currentPageIndex() {
				return this.page - 1;
			},
			saveSearchText() {
				return window.MyHome.translations.save_this_search;
			},
			prevText() {
				return window.MyHome.translations.prev;
			},
			nextText() {
				return window.MyHome.translations.next;
			},
			showPagination() {
				return this.hasPagination && this.pages > 1;
			},
			pages() {
				return Math.ceil(parseInt(this.totalResults) / parseInt(this.config.estates_per_page));
			},
			currentCurrency() {
				let currentCurrency = {};
				if (this.config.currencies.length === 1) {
					return this.config.currencies[0];
				}

				jQuery.each(this.config.currencies, (index, currency) => {
					if (currency.key === this.currency) {
						currentCurrency = currency;
						return false;
					}
				});

				return currentCurrency;
			},
			showSearchForm() {
				return this.config.search_form_position !== 'hide';
			},
			searchFormClass() {
				return {
					'mh-layout__sidebar-left' : this.config.search_form_position === 'left',
					'mh-layout__sidebar-right': this.config.search_form_position === 'right',
				};
			},
			listingClass() {
				return {
					'mh-layout__content-right': this.config.search_form_position === 'left',
					'mh-layout__content-left' : this.config.search_form_position === 'right',
				};
			},
			showBottomResults() {
				return !this.hasPagination && this.estates.length === this.totalResults && this.config.show_results_number
			},
			showLoading() {
				return this.busy && !this.init && this.reloadResults;
			},
			showBottomLoading() {
				return !this.hasPagination && this.busy && !this.init && !this.reloadResults;
			},
			showMoreButton() {
				return !this.hasPagination && !this.busy && this.lazyload && this.estates.length < this.totalResults && !this.reloadResults
					&& this.totalResults > 0
			},
			lazyload() {
				return this.hasPagination || !(!this.lazyLoadFlag && !this.busy && this.lazyloadCurrent < this.config.lazy_loading_limit
					&& !this.showBottomResults)
			},
			results() {
				return this.totalResults + ' ' + window.MyHome.translations.found
			},
			bottomResults() {
				return this.totalResults + ' ' + window.MyHome.translations.results
			}
		},
		methods   : {
			onSaveSearch() {
				if (typeof window.MyHome.user !== 'undefined') {
					let requestData = this.getRequestData();
					window.MyHomeEventBus.$emit('saveSearch', requestData);
				} else {
					window.MyHomeEventBus.$emit('myhomeAccount');
				}
			},
			onChangePageBottom(pageNum) {
				window.scrollTo(0, jQuery('.mh-search__results-wrapper').offset().top);
				this.onChangePage(pageNum);
			},
			onChangePage(pageNum) {
				this.page = pageNum;
			},
			updateUrl() {
				let url = window.location.href;
				url = url.split('#')[0].split('?')[0];

				let checkString;
				url = url.split('mh/')[0];
				if (this.config.homepage) {
					checkString = 'mh/?'
				} else {
					checkString = '?'
				}

				if (url.indexOf(checkString) !== -1) {
					url = url.split(checkString)[0];
				}

				if (jQuery.isEmptyObject(this.filters)) {
					if (this.page !== 1) {
						url += '?current_page=' + this.page;
					}

					if (typeof this.config.estates__in !== 'undefined') {
						let propertyIds = 'property_ids=' + this.config.estates__in.join(',');
						url += url.indexOf('?') !== -1 ? '&' + propertyIds : '?' + propertyIds
					}

					if (this.sortBy !== 'newest') {
						url += url.indexOf('?') !== -1 ? '&sortBy=' + this.sortBy : checkString + 'sortBy=' + this.sortBy
					}

					window.history.replaceState({page: this.page}, null, url);
					setCookie('mh_results', url, 1);
					return;
				}

				let params = {};
				jQuery.each(this.filters, (key, filter) => {
					if (filter.values.length === 1) {
						params[filter.slug] = filter.values[0].value
					} else {
						params[filter.slug] = [];
						filter.values.forEach((v) => {
							params[filter.slug].push(v.value)
						})
					}
				});

				if (Object.keys(params).length > 0) {
					url += checkString;
					url += jQuery.param(params);
				}

				if (this.page !== 1) {
					url += '&current_page=' + this.page;
				}

				if (typeof this.config.estates__in !== 'undefined') {
					let propertyIds = 'property_ids=' + this.config.estates__in.join(',');
					url += url.indexOf('?') !== -1 ? '&' + propertyIds : '?' + propertyIds
				}

				if (this.sortBy !== 'newest') {
					url += url.indexOf('?') !== -1 ? '&sortBy=' + this.sortBy : checkString + 'sortBy=' + this.sortBy
				}

				setCookie('mh_results', url, 1);
				window.history.replaceState(params, null, url);
			},
			loadMore() {
				if (this.busy || this.hasPagination) {
					return false;
				}

				this.$nextTick(() => {
					if (this.totalResults === this.estates.length) {
						return false;
					}

					this.busy = true;
					this.lazyloadCurrent++;
					this.page++
				});
			},
			onLoadMoreButton() {
				this.lazyLoadFlag = false;
				this.busy = true;
				this.lazyloadCurrent = 1;
				this.page++
			},
			reload() {
				this.reloadResults = true;
				this.query();
			},
			getRequestData() {
				let filters = jQuery.extend({}, this.filters);

				jQuery.each(this.config.default_values, (key, data) => {
					if (!filters.hasOwnProperty(key) && this.ignoreDefaultFilters.indexOf(key) === -1) {
						filters[key] = {
							compare: '=',
							key    : key,
							slug   : key,
							values : data.values
						}
					}
				});

				let requestData = {
					data    : filters,
					currency: this.currency
				};

				if (typeof this.config.user_id !== 'undefined') {
					requestData.userId = this.config.user_id;
				}

				if (typeof this.config.users !== 'undefined') {
					requestData.users = this.config.users;
				}

				if (typeof this.config.featured !== 'undefined' && this.config.featured === true) {
					requestData.featured = true;
				}

				if (typeof this.config.lang !== 'undefined' && this.config.lang !== null) {
					requestData.lang = this.config.lang;
				}

				return requestData;
			},
			query() {
				if (this.initialSetup) {
					return;
				}

				let queryKey = new Date().getTime() + '_' + Math.random();
				this.queryKey = queryKey;
				let time = this.reloadResults ? 300 : 0;

				this.timer = setTimeout(() => {
					if (this.hasPagination || this.reloadResults) {
						let listing = jQuery('#myhome-listing');
						listing.css('height', listing.height() + 'px');
						this.estates.splice(0, this.estates.length);
					}

					if (this.reloadResults) {
						this.page = 1;
					}
					this.$nextTick(() => {
						this.busy = true;
						this.showInitialResults = true;
					});

					let filters = jQuery.extend({}, this.filters);

					jQuery.each(this.config.default_values, (key, data) => {
						if (!filters.hasOwnProperty(key) && this.ignoreDefaultFilters.indexOf(key) === -1) {
							filters[key] = {
								compare: '=',
								key    : key,
								slug   : key,
								values : data.values
							}
						}
					});

					let requestData = {
						data    : filters,
						page    : this.page,
						limit   : this.config.estates_per_page,
						sortBy  : this.sortBy,
						currency: this.currency
					};

					if (typeof this.config.user_id !== 'undefined') {
						requestData.userId = this.config.user_id;
					}

					if (typeof this.config.estates__in !== 'undefined') {
						requestData.estates__in = this.config.estates__in;
					}

					if (typeof this.config.users !== 'undefined') {
						requestData.users = this.config.users;
					}

					if (typeof this.config.featured !== 'undefined' && (this.config.featured === true) || this.config.featured === '1') {
						requestData.featured = true;
					}

					let queryUrl = this.config.api_endpoint + '?currency=' + this.currency;

					if (typeof this.config.lang !== 'undefined' && this.config.lang !== null) {
						requestData.lang = this.config.lang;
						queryUrl += '&mh_lang=' + this.config.lang;
					}

					this.$http.post(queryUrl, requestData, {
						emulateJSON: true,
						before(request) {
							if (this.lastRequest) {
								this.lastRequest.abort()
							}
							this.lastRequest = request
						}
					}).then(response => {
						if (this.queryKey !== queryKey) {
							return;
						}
						this.queryFlag = false;
						this.updateUrl();
						this.reloadResults = false;
						this.totalResults = response.body.found_results;
						this.addEstates(response.body.results);
						this.timer = false;
					}, response => {
						if (this.queryKey !== queryKey) {
							return;
						}
						this.queryFlag = false;
						this.reloadResults = false;
						this.timer = false;
						this.queryInProgress = false;
					})
				}, time)
			},
			addEstates(estates) {
				this.busy = false;

				estates.forEach((estate) => {
					this.estates.push(estate);
				});
				this.$nextTick(() => {
					jQuery('#myhome-listing').css('height', 'auto');
					this.setCardsHeight();
				});
				this.queryInProgress = false;
			},
			setCardsHeight() {
				let offsetTop = 0;
				let elements = [];
				let height = 0;
				let cards = jQuery('.mh-estate-vertical__content');

				cards.css('height', 'auto');

				this.$nextTick(() => {
					cards.each(function () {
						let offset = jQuery(this).offset();
						if (offset.top !== offsetTop) {
							offsetTop = offset.top;
							jQuery.each(elements, function () {
								jQuery(this).css('height', height + 'px');
							});
							elements.splice(0, elements.length);
							height = 0;
						}

						if (jQuery(this).height() > height) {
							height = jQuery(this).height();
						}
						elements.push(jQuery(this));
					});

					jQuery.each(elements, function () {
						jQuery(this).css('height', height + 'px');
					});
				});
			},
			onReset() {
				this.queryFlag = true;
				for (let key in this.filters) {
					this.$delete(this.filters, key);
				}

				if (typeof this.config.initial_results !== 'undefined' && !parseInt(this.config.initial_results)) {
					this.showInitialResults = false;
					this.totalResults = 0;
					this.estates = [];
				} else {
					this.$nextTick(() => {
						this.reload();
					});
				}
			}
		},
		created() {
			this.config = window[this.configKey];
			this.config.estates_per_page = parseInt(this.config.estates_per_page);
			this.view = this.config.listing_default_view;
			this.config.lazyLoadFlag = parseInt(this.config.lazy_loading);
			this.config.lazy_loading_limit = parseInt(this.config.lazy_loading_limit);
			this.config.search_form_advanced_number = parseInt(this.config.search_form_advanced_number);
			this.config.show_advanced = parseInt(this.config.show_advanced);
			this.config.show_clear = parseInt(this.config.show_clear);
			this.config.show_sort_by = parseInt(this.config.show_sort_by);
			this.config.show_view_types = parseInt(this.config.show_view_types);
			this.config.show_date = parseInt(this.config.show_date);
			this.config.show_gallery = parseInt(this.config.show_gallery);
			this.config.show_results_number = parseInt(this.config.show_results_number);
			this.config.show_sort_by_price_low_to_high = parseInt(this.config.show_sort_by_price_low_to_high);
			this.config.show_sort_by_price_high_to_low = parseInt(this.config.show_sort_by_price_high_to_low);
			this.config.show_sort_by_popular = parseInt(this.config.show_sort_by_popular);
			this.config.show_sort_by_newest = parseInt(this.config.show_sort_by_newest);
			this.config.show_sort_by_alphabetically = parseInt(this.config.show_sort_by_alphabetically);
			this.hasPagination = this.config.listing_type === 'pagination';

			if (typeof this.config.initial_results !== 'undefined' && !parseInt(this.config.initial_results)) {
				this.showInitialResults = false;
				this.totalResults = 0;
				this.estates = [];
			} else {
				this.totalResults = parseInt(this.config.results.totalResults);
				this.estates = this.config.results.estates;
			}

			if (typeof this.config.current_page !== 'undefined') {
				this.page = parseInt(this.config.current_page);
				this.initialPage = this.page - 1;
			}

			if (typeof this.config.listing_sort_by !== 'undefined' && this.config.listing_sort_by !== '') {
				this.sortBy = this.config.listing_sort_by;
			}

			window.MyHomeEventBus.$on('searchFormClear', this.onReset);
			window.MyHomeEventBus.$on('addSearchFilter', (filter) => {
				if (this.ignoreDefaultFilters.indexOf(filter.slug) === -1) {
					this.ignoreDefaultFilters.push(filter.slug);
				}
				this.$set(this.filters, filter.slug, filter);
				if (filter.baseSlug === 'property_type') {
					window.MyHomeEventBus.$emit('propertyTypeChange', filter.values);
				}
				this.reload();
			});
			window.MyHomeEventBus.$on('deleteSearchFilter', (filterSlug) => {
				if (this.queryFlag) {
					return;
				}
				if (typeof this.filters[filterSlug] !== 'undefined' && this.filters[filterSlug].baseSlug === 'property_type') {
					window.MyHomeEventBus.$emit('propertyTypeChange', []);
				}
				this.$delete(this.filters, filterSlug);
				this.reload();
			});
			window.MyHomeEventBus.$on('listingSortBy', (sortBy) => {
				this.sortBy = sortBy;
			});
			window.MyHomeEventBus.$on('setListingView', (view) => {
				this.view = view;
				this.$nextTick(() => {
					this.setCardsHeight();
				});
			});
			window.MyHomeEventBus.$on('setCurrency', (currency) => {
				this.currency = currency;
				this.reload();
			});
		},
		mounted() {
			window.addEventListener("load", () => {
				this.updateUrl();

				this.$nextTick(() => {
					this.initialSetup = false;
                    this.reloadResults = false;
                });
			})

			setTimeout(() => {
				this.queryFlag = false;
				this.reloadResults = false;
				this.busy = false;
				this.init = false;
			}, 500);

			this.$nextTick(() => {
				this.setCardsHeight();
			});
		},
		watch     : {
			sortBy() {
				this.reload();
			},
			page() {
				this.query();
			}
		}
	}
</script>