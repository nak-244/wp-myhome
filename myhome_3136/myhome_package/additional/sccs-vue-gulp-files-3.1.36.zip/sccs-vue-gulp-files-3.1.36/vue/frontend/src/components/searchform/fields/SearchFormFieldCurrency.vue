<template>

	<div id="mh-currency_field">
		<select
			v-model="currency"
			class="selectpicker mh-search-currency-picker"
			data-container="body"
			data-dropup-auto="false"
		>
			<option value="any">{{ currencyLabel }}</option>
			<option v-for="curr in currencies" :value="curr.key">{{ curr.sign }}</option>
		</select>
	</div>

</template>

<script>
	export default {
		data() {
			return {
				currency: 'any'
			}
		},
		computed: {
			currencyLabel() {
				return window.MyHome.translations.currency;
			},
			currentCurrency() {
				let currentCurrency = false;
				jQuery.each(this.currencies, (index, currency) => {
					if (currency.key === this.currency) {
						currentCurrency = currency;
					}
				});

				return currentCurrency;
			}
		},
		props   : {
			currencies     : Array,
			defaultCurrency: String
		},
		created() {
			window.MyHomeEventBus.$on('searchFormClear', () => {
				this.currency = 'any';
			});
		},
		created() {
			if (this.defaultCurrency !== 'any') {
				this.currency = this.defaultCurrency;
			}
		},
		mounted() {
			jQuery("#mh-currency_field").selectpicker('refresh');
		},
		watch   : {
			currency() {
				window.MyHomeEventBus.$emit('setCurrency', this.currency);
			}
		}
	}
</script>