<template>
    <div>

        <div class="mh-search__panel" :class="fieldClass">
            <input :id="fieldKey" v-model="value" type="text" :placeholder="placeholder">
        </div>

    </div>
</template>

<script>
    const DEFAULT_VALUE = '';

    export default {
        data() {
            return {
                value: DEFAULT_VALUE,
                parentValues: [],
                awesomplete: false,
                timer: 0
            }
        },
        props: {
            field: Object,
            position: String,
            config: Object
        },
        computed: {
            fieldKey() {
                return 'field-' + this.field.slug
            },
            fieldClass() {
                return {
                    'mh-active-input': this.isActive,
                    'awesomplete': this.field.suggestions
                }
            },
            placeholder() {
                return this.field.placeholder === '' ? this.field.name : this.field.placeholder
            },
            isActive() {
                return this.value !== DEFAULT_VALUE
            }
        },
        methods: {
            getOptions() {
                let options = [];
                let optionValueType = this.field.is_number ? 'slug' : 'name';

                if (typeof this.field.parent_type !== 'undefined' && this.field.parent_type === 'manual' && this.parentValues.length !== 0) {
                    jQuery.each(this.field.values['any'], (index, option) => {
                        let parents = [];
                        jQuery.each(this.parentValues, (index, option) => {
                            parents.push(option[optionValueType]);
                        });
                        if (parents.indexOf(option.options.parent_term) !== -1) {
                            options.push({label: option.name, value: option[optionValueType]});
                        }
                    });
                } else if (this.parentValues.length > 0) {
                    this.parentValues.forEach((v) => {
                        this.field.values[v.value].forEach((option) => {
                            options.push({label: option.name, value: option[optionValueType]})
                        })
                    })
                } else {
                    this.field.values['any'].forEach((option) => {
                        options.push({label: option.name, value: option[optionValueType]})
                    })
                }
                return options
            },
            setDefault() {
                if (typeof this.config.default_values[this.field.slug] !== 'undefined') {
                    jQuery.each(this.config.default_values[this.field.slug].values, (index, data) => {
                        this.value = this.field.is_text ? data.name : data.value;
                    });
                } else {
                    this.value = DEFAULT_VALUE
                }
            }
        },
        created() {
            this.setDefault();

            if (typeof this.config.current_values[this.field.slug] !== 'undefined') {
                jQuery.each(this.config.current_values[this.field.slug].values, (index, data) => {
                    this.value = this.field.is_text ? data.name : data.value;
                });
            }

            window.MyHomeEventBus.$on('searchFormClear', () => [
                this.value = DEFAULT_VALUE
            ]);
            window.MyHomeEventBus.$on('removeSearchFilterValue' + this.field.slug, () => {
                this.value = DEFAULT_VALUE
            });
            if (this.field.parent_id !== 0) {
                window.MyHomeEventBus.$on('parentAttributeChange' + this.field.parent_id, (values) => {
                    this.parentValues.splice(0, this.parentValues.length);
                    values.forEach((v) => {
                        this.parentValues.push(v)
                    })
                })
            }
        },
        mounted() {
            if (this.field.suggestions) {
                let field = document.getElementById(this.fieldKey)
                this.awesomplete = new Awesomplete(field, {
                    list: this.getOptions(),
                    minChars: 2,
                    filter: function (text, input) {
                        if (this.field.is_number) {
                            return text.value.indexOf(input) === 0
                        } else {
                            return text.label.toLowerCase().indexOf(input.toLowerCase()) === 0
                        }
                    }.bind(this)
                });
                field.addEventListener('awesomplete-selectcomplete', () => {
                    this.value = field.value
                })
            }
        },
        watch: {
            parentValues() {
                if (!this.field.suggestions) {
                    return;
                }
                this.awesomplete.list = this.getOptions();
                this.awesomplete.evaluate();
                this.awesomplete.close();
            },
            value(val) {
                let name;
                if (this.field.is_number) {
                    if (isNaN(val)) {
                        return;
                    }
                    val = Number(val);
                    name = this.field.name + ' ' + this.field.compare_operator + ' ' + val;
                } else {
                    name = val;
                }

                clearTimeout(this.timer);
                this.timer = setTimeout(() => {
                    if (val === DEFAULT_VALUE || val === 0) {
                        window.MyHomeEventBus.$emit('deleteSearchFilter', this.field.slug);
                        return;
                    }

                    window.MyHomeEventBus.$emit('addSearchFilter', {
                        slug: this.field.slug,
                        baseSlug: this.field.base_slug,
                        key: this.field.slug,
                        units: this.field.display_after,
                        compare: this.field.compare_operator,
                        values: [
                            {name: name, value: val}
                        ]
                    })
                }, 600);
            }
        }
    }
</script>

