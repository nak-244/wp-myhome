<template>
	<div>

		<form @keydown.enter.prevent="onSubmit" class="mh-search mh-search mh-search--button">

			<SearchFormField
				v-for="searchField in fields"
				v-show="searchField.show"
				:key="searchField.field.slug"
				:field="searchField.field"
				:config="config"
				position="top-bottom"
				:is-static="true"
			>
			</SearchFormField>

			<div class="mh-search__element">
				<button
					class="mdl-button mdl-button--lg mdl-js-button mdl-button--raised mdl-button--primary"
					@click.prevent="onSubmit"
				>
					{{ config.search_label }}
				</button>
			</div>

		</form>

	</div>
</template>

<script>
	import SearchFormField from './SearchFormField.vue'

	export default {
		data() {
			return {
				currency     : 'any',
				filters      : {},
				hiddenFields : [],
				propertyTypes: []
			}
		},
		components: {SearchFormField},
		props     : {
			config: Object
		},
		computed  : {
			fields() {
				let fields = [];
				this.config.fields.forEach((field) => {
					let show;
					if (this.propertyTypes.length === 0 || field.base_slug === 'property_type' || field.base_slug === 'keyword') {
						show = true;
					} else {
						show = this.propertyTypes.some((propertyType) => {
							return this.config.dependencies[field.slug][propertyType];
						});
					}

					let searchField = {field: field};
					searchField.show = show && this.hiddenFields.indexOf(field.slug) === -1;
					fields.push(searchField)
				});
				return fields
			},
		},
		methods   : {
			onSubmit() {
				let url = this.config.listing_page;

				if (url.indexOf('http') === -1) {
					url = this.config.site + this.config.listing_page;
				}

				if (jQuery.isEmptyObject(this.filters)) {
					console.log('empty')
					window.location.href = url;
					return;
				}

				let params = {};
				jQuery.each(this.filters, (key, filter) => {
					if (filter.values.length === 1) {
						params[filter.slug] = filter.values[0].value
					} else {
						params[filter.slug] = [];
						filter.values.forEach((v) => {
							params[filter.slug].push(v.value)
						})
					}
				});

				if (Object.keys(params).length > 0) {
					if (this.config.homepage) {
						url += 'mh/';
					}
					url += '?' + jQuery.param(params);
				}

				window.location.href = url;
			}
		},
		created() {
			window.MyHomeEventBus.$on('addSearchFilter', (filter) => {
				this.$set(this.filters, filter.slug, filter);
				if (filter.baseSlug === 'property_type') {
					window.MyHomeEventBus.$emit('propertyTypeChange', filter.values);
				}
			});
			window.MyHomeEventBus.$on('deleteSearchFilter', (filterSlug) => {
				this.$delete(this.filters, filterSlug);
				if (typeof this.filters[filterSlug] !== 'undefined' && this.filters[filterSlug].baseSlug === 'property_type') {
					window.MyHomeEventBus.$emit('propertyTypeChange', []);
				}
			});
			window.MyHomeEventBus.$on('setCurrency', (currency) => {
				this.currency = currency;
			});
		}
	}
</script>